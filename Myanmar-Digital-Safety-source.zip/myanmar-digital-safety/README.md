# Myanmar Digital Safety · မြန်မာ ဒစ်ဂျစ်တယ် လုံခြုံရေး

**Free, Burmese-first, offline Android app** teaching everyday scam awareness and account protection. A **different Android package** (`com.myanmardigitalsafety`) from Myanmar Hazard Guard; both can remain installed on the same phone.

## What is included

- Cozy sage/cream native Android UI, custom shield launcher icon, Myanmar text by default, optional English toggle.
- 10 complete Burmese/English lessons about phishing, OTP fraud, fake jobs, payments, impersonation, untrusted APKs, secure logins, misinformation, privacy, and responding to scams.
- 8-question interactive scenario quiz with explanations; best score saved on-device.
- 5 step-by-step incident guides: sent money, shared password, shared OTP, installed an untrusted APK, or being threatened.
- Educational scam-warning checklist (NOT an automated scam detector).
- All contents work with **no Internet connection**. Optional vetted educational links open a separate browser only when tapped.
- **No network/SMS/location/contacts/camera/storage/call permissions.** No analytics, ads, account, subscription, external translation, uploaded messages, or cloud backend. Progress is stored locally using private Android preferences; uninstalling the app removes it.

## Safety limitations

This app is educational: **not** an antivirus, live fraud detection tool, emergency hotline, legal adviser, or an official reporting authority. Its advice is general and may need localization. A benign message can still contain warning signs and a malicious message might have none. Avoid entering or pasting real passwords, private chats, identity documents or financial information anywhere in the app.

Fraud advice is based on established consumer digital-security guidance (paraphrased in Burmese and English). Have bilingual reviewers validate the Burmese copy before mass distribution, and repeat device testing including older Android phones and Myanmar fonts.

Sources for user-initiated further reading:
- FTC: https://consumer.ftc.gov/articles/how-recognize-avoid-phishing-scams
- Google Accounts: https://support.google.com/accounts/answer/6294825
- CISA: https://www.cisa.gov/secure-our-world

## Build

JDK 17, Android SDK API 35 and Gradle 8.11.1 (Android Gradle Plugin 8.9.1): `gradle :app:assembleDebug` from project root. See GitHub Actions build workflow in the host branch.

Do not distribute the debug APK as if signed for production. Keep a private, backed-up release signing key before publishing to Play Store or another app store.
