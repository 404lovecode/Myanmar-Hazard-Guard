package com.myanmardigitalsafety;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** Native offline-first Burmese digital safety education app; no network or sensitive permissions. */
public final class MainActivity extends Activity {
    private static final int BG=0xffF7F7F1, SURFACE=0xffFFFFFF, INK=0xff1C3936, MUTED=0xff60766F;
    private static final int DEEP=0xff183D3B, TEAL=0xff166F61, MINT=0xffDFF2E7, FAINT=0xffEEF5EF;
    private static final int CORAL=0xffA84D3B, PALE=0xffFFF0E8, GOLD=0xffE8AD63, LINE=0xffDEE8E0;
    private static final String PREFS="myanmar_digital_safety_v1";
    private SharedPreferences prefs;
    private boolean english=false;
    private LinearLayout root, body;
    private ScrollView scroller;
    private int page=0, currentLesson=-1, remedy=-1, quizIndex=0, quizChoice=-1, quizScore=0;
    private boolean quizFinished=false;
    private final boolean[] checkFlags=new boolean[5];
    private boolean checked=false;

    private int d(float dp){return Math.round(getResources().getDisplayMetrics().density*dp);}
    private String tr(String my,String en){return english?en:my;}
    private GradientDrawable bg(int fill,int radius){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(d(radius));return g;}
    private GradientDrawable outline(int fill,int radius,int stroke){GradientDrawable g=bg(fill,radius);g.setStroke(d(1),stroke);return g;}
    private TextView text(String str,float size,int color,boolean bold){
        TextView t=new TextView(this);t.setText(str);t.setTextSize(size);t.setTextColor(color);
        t.setLineSpacing(d(2),1.06f);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;
    }
    private LinearLayout v(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout h(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private void gap(LinearLayout parent,int size){View spacer=new View(this);parent.addView(spacer,new LinearLayout.LayoutParams(1,d(size)));}
    private LinearLayout panel(){
        LinearLayout c=v();c.setPadding(d(17),d(17),d(17),d(17));c.setBackground(outline(SURFACE,22,LINE));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=d(13);body.addView(c,p);return c;
    }
    private LinearLayout subPanel(LinearLayout parent,int color){
        LinearLayout c=v();c.setPadding(d(14),d(14),d(14),d(14));c.setBackground(bg(color,16));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=d(10);parent.addView(c,p);return c;
    }
    private TextView pill(String label,int fg,int bgColor){
        TextView t=text(label,11,fg,true);t.setPadding(d(11),d(6),d(11),d(6));t.setBackground(bg(bgColor,50));t.setGravity(Gravity.CENTER);return t;
    }
    private TextView button(String title,boolean primary){
        TextView t=text(title,14,primary?0xffFFFFFF:TEAL,true);
        t.setGravity(Gravity.CENTER);t.setMinHeight(d(48));t.setPadding(d(15),d(12),d(15),d(12));
        t.setBackground(primary?bg(TEAL,14):outline(FAINT,14,LINE));
        t.setClickable(true);t.setFocusable(true);return t;
    }
    private void section(String title,String small){
        LinearLayout wrap=v();wrap.setPadding(d(2),d(9),d(2),d(11));
        wrap.addView(text(title,20,INK,true));
        if(!small.isEmpty()){gap(wrap,3);wrap.addView(text(small,12,MUTED,false));}
        body.addView(wrap);
    }
    private void line(LinearLayout c){View v=new View(this);v.setBackgroundColor(LINE);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,d(1));p.topMargin=d(12);p.bottomMargin=d(12);c.addView(v,p);}
    private int completed(){int result=0;for(int i=0;i<LearnData.LESSONS.length;i++)if(prefs.getBoolean("lesson_done_"+i,false))result++;return result;}

    @Override public void onCreate(Bundle state){
        super.onCreate(state);prefs=getSharedPreferences(PREFS,MODE_PRIVATE);
        english=prefs.getBoolean("english",false);getWindow().setStatusBarColor(DEEP);
        getWindow().setNavigationBarColor(0xffFFFFFF);
        if(Build.VERSION.SDK_INT>=26)getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        render();
    }
    private void render(){
        root=v();root.setBackgroundColor(BG);
        if(Build.VERSION.SDK_INT>=35){
            getWindow().setDecorFitsSystemWindows(false);
            root.setOnApplyWindowInsetsListener((view,insets)->{
                android.graphics.Insets a=insets.getInsets(WindowInsets.Type.systemBars());
                view.setPadding(0,a.top,0,a.bottom);return insets;
            });
        }
        setContentView(root);
        header();
        scroller=new ScrollView(this);scroller.setFillViewport(true);scroller.setVerticalScrollBarEnabled(false);
        root.addView(scroller,new LinearLayout.LayoutParams(-1,0,1));
        body=v();body.setPadding(d(18),d(17),d(18),d(26));scroller.addView(body);
        if(currentLesson>=0)lessonPage();
        else if(remedy>=0)remedyPage();
        else if(page==0)homePage();
        else if(page==1)lessonsPage();
        else if(page==2)quizPage();
        else helpPage();
        bottomNav();
    }
    private void header(){
        LinearLayout box=v();box.setPadding(d(20),d(16),d(20),d(16));
        GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{DEEP,0xff24685B});
        box.setBackground(g);root.addView(box);
        LinearLayout line=h();ImageView icon=new ImageView(this);icon.setImageResource(R.drawable.ic_shield);
        icon.setContentDescription(tr("ဒစ်ဂျစ်တယ်လုံခြုံရေး","Shield symbol"));
        line.addView(icon,new LinearLayout.LayoutParams(d(42),d(42)));
        LinearLayout titles=v();titles.setPadding(d(10),0,0,0);
        titles.addView(text("MYANMAR",11,0xffB2EAD4,true));
        titles.addView(text("DIGITAL SAFETY",19,0xffFFFFFF,true));
        line.addView(titles,new LinearLayout.LayoutParams(0,-2,1));
        TextView lang=pill(english?"မြန်မာ":"ENGLISH",0xffFFFFFF,0xff3A786B);
        lang.setContentDescription(tr("English ဘာသာစကားပြောင်းရန်","Switch to Burmese"));
        lang.setMinHeight(d(43));lang.setOnClickListener(view->{
            english=!english;prefs.edit().putBoolean("english",english).apply();render();
        });line.addView(lang);box.addView(line);
        gap(box,13);
        box.addView(text(tr("သိမြင်ပါ • စစ်ဆေးပါ • လုံခြုံစွာနေပါ","Learn • Verify • Stay safe"),13,0xffD3E9DA,false));
    }
    private void bottomNav(){
        LinearLayout bar=h();bar.setPadding(d(5),d(8),d(5),d(8));bar.setBackgroundColor(SURFACE);
        final String[] icons={"⌂","▤","◎","✚"};
        final String[] labelsMy={"အိမ်","သင်ခန်းစာ","လေ့ကျင့်","အကူအညီ"};
        final String[] labelsEn={"Home","Learn","Practice","Help"};
        for(int i=0;i<4;i++){
            final int target=i;boolean active=page==i;
            LinearLayout c=v();c.setGravity(Gravity.CENTER);c.setPadding(d(2),d(6),d(2),d(5));
            if(active)c.setBackground(bg(MINT,12));
            TextView icon=text(icons[i],23,active?TEAL:MUTED,true);icon.setGravity(Gravity.CENTER);c.addView(icon);
            TextView label=text(english?labelsEn[i]:labelsMy[i],10,active?TEAL:MUTED,active);
            label.setGravity(Gravity.CENTER);label.setSingleLine(true);c.addView(label);
            c.setMinimumHeight(d(56));c.setContentDescription(label.getText());
            c.setOnClickListener(view->{page=target;currentLesson=-1;remedy=-1;render();});
            bar.addView(c,new LinearLayout.LayoutParams(0,-2,1));
        }
        root.addView(bar);
    }
    private void homePage(){
        LinearLayout hero=panel();hero.setBackground(bg(0xffE7F3E9,22));
        hero.addView(pill(tr("🔐  ကိုယ်ရေးကိုယ်တာအချက်အလက် အရင်ကာကွယ်","🔐  YOUR SECURITY MATTERS"),TEAL,0xffFFFFFF));
        gap(hero,13);
        hero.addView(text(tr("အွန်လိုင်းမှာ ပိုလုံခြုံတဲ့နေ့စဉ်ဘဝ","A safer everyday digital life"),25,INK,true));gap(hero,8);
        hero.addView(text(tr("လိမ်လည်မှုကို ခွဲခြားသိဖို့၊ အကောင့်ကာကွယ်ဖို့နဲ့ ပြဿနာကြုံရင် ဘာလုပ်ရမလဲဆိုတာ အခမဲ့လေ့လာပါ။",
            "Learn to spot scams, secure your accounts, and respond safely — free and offline."),14,MUTED,false));gap(hero,16);
        TextView start=button(tr("သင်ခန်းစာများ စတင်လေ့လာမယ်  →","Explore lessons  →"),true);
        start.setOnClickListener(view->{page=1;render();});hero.addView(start);
        section(tr("သင့်ရဲ့ လေ့လာမှု","Your learning journey"),tr("ဖုန်းအတွင်းမှာပဲ မှတ်သားထားပါတယ်","Progress stays on your device"));
        LinearLayout progress=panel();LinearLayout top=h();
        top.addView(text(tr("ပြီးဆုံးသည့် သင်ခန်းစာများ","Lessons completed"),13,MUTED,true),new LinearLayout.LayoutParams(0,-2,1));
        top.addView(text(completed()+" / "+LearnData.LESSONS.length,19,TEAL,true));progress.addView(top);gap(progress,12);
        LinearLayout track=h();track.setBackground(bg(FAINT,20));
        FrameLayout bar=new FrameLayout(this);bar.setBackground(bg(FAINT,10));
        View fill=new View(this);fill.setBackground(bg(TEAL,10));bar.addView(fill,new FrameLayout.LayoutParams(0,d(10)));
        progress.addView(bar,new LinearLayout.LayoutParams(-1,d(10)));
        bar.post(()->{if(bar.getWidth()>0){FrameLayout.LayoutParams a=new FrameLayout.LayoutParams(bar.getWidth()*completed()/LearnData.LESSONS.length,d(10));fill.setLayoutParams(a);}});
        gap(progress,10);progress.addView(text(tr("အကောင်းဆုံး စမ်းသပ်ချက်ရမှတ်","Best quiz score")+": "+prefs.getInt("quiz_best",0)+" / "+LearnData.QUIZ.length,12,MUTED,false));
        section(tr("အမြန်လေ့လာရန်","Start with these"),tr("အရေးကြီးဆုံးကာကွယ်ရေးအကြံပြုချက်များ","Essential everyday habits"));
        for(int index:new int[]{0,1,2})lessonRow(index);
        LinearLayout c=panel();c.setBackground(bg(PALE,20));
        c.addView(text("⚠  "+tr("မသေချာတဲ့မက်ဆေ့ချ် ရထားလား။","Got a suspicious message?"),18,CORAL,true));gap(c,7);
        c.addView(text(tr("လင့်ခ်မနှိပ်ပါနှင့်။ OTP မပေးပါနှင့်။ အခု သတိပေးလက္ခဏာတွေကို စစ်ကြည့်ပါ။",
            "Don't click or share a code. Review warning signs first."),13,INK,false));gap(c,12);
        TextView check=button(tr("လိမ်လည်မှု သတိပေးလက္ခဏာ စစ်မယ်","Check scam warning signs"),false);
        check.setOnClickListener(view->{page=3;render();});c.addView(check);
    }
    private void lessonRow(int index){
        LearnData.Lesson l=LearnData.LESSONS[index];LinearLayout row=panel();
        LinearLayout head=h();TextView ico=text(l.icon,24,TEAL,true);
        ico.setBackground(bg(MINT,13));ico.setPadding(d(12),d(8),d(12),d(8));head.addView(ico);
        LinearLayout content=v();content.setPadding(d(12),0,d(4),0);
        content.addView(text(english?l.categoryEn:l.categoryMy,10,MUTED,true));gap(content,5);
        content.addView(text(english?l.titleEn:l.titleMy,15,INK,true));
        head.addView(content,new LinearLayout.LayoutParams(0,-2,1));
        TextView arrow=text(prefs.getBoolean("lesson_done_"+index,false)?"✓":"›",23,TEAL,true);head.addView(arrow);
        row.addView(head);gap(row,9);row.addView(text(english?l.summaryEn:l.summaryMy,12,MUTED,false));
        row.setOnClickListener(view->{currentLesson=index;render();});row.setClickable(true);row.setFocusable(true);
    }
    private void lessonsPage(){
        section(tr("သင်ခန်းစာများ","Learning library"),tr("အင်တာနက်မလိုဘဲ ဖတ်ရှုနိုင်သော သင်ခန်းစာ ၁၀ ခု","10 complete lessons available offline"));
        for(int i=0;i<LearnData.LESSONS.length;i++)lessonRow(i);
        LinearLayout source=panel();source.addView(text("ⓘ  "+tr("သတိပြုရန်","Education, not a scanner"),15,INK,true));gap(source,8);
        source.addView(text(tr("ဒီအက်ပ်က မက်ဆေ့ချ်၊ ဖုန်းနံပါတ်၊ လင့်ခ်တွေကို အလိုအလျောက်စကင်မလုပ်ပါ။ သင်ယူမှုအတွက်သာ ဖြစ်ပါတယ်။",
            "This app teaches safe decisions. It does not scan your phone, links, messages or accounts."),12,MUTED,false));
    }
    private void lessonPage(){
        LearnData.Lesson l=LearnData.LESSONS[currentLesson];
        TextView back=button(tr("‹  သင်ခန်းစာများသို့ ပြန်မယ်","‹  Back to lessons"),false);
        back.setOnClickListener(view->{currentLesson=-1;page=1;render();});body.addView(back);gap(body,15);
        LinearLayout intro=panel();intro.addView(pill(l.icon+"  "+(english?l.categoryEn:l.categoryMy),TEAL,MINT));gap(intro,12);
        intro.addView(text(english?l.titleEn:l.titleMy,23,INK,true));gap(intro,9);
        intro.addView(text(english?l.summaryEn:l.summaryMy,14,MUTED,false));
        section(tr("ဥပမာ (ဖန်တီးထားသော စာသား)","Example (fictional)"),"");
        LinearLayout example=panel();example.setBackground(bg(PALE,18));
        example.addView(text(english?l.exampleEn:l.exampleMy,15,CORAL,true));
        section("⚠  "+tr("သတိပေးလက္ခဏာများ","Warning signs"),"");
        LinearLayout flags=panel();String[] red=english?l.redEn:l.redMy;
        for(int i=0;i<red.length;i++){flags.addView(text("•  "+red[i],14,INK,false));if(i<red.length-1)gap(flags,13);}
        section("✓  "+tr("လုံခြုံစွာ လုပ်ဆောင်ရန်","Safer actions"),"");
        LinearLayout steps=panel();String[] safe=english?l.safeEn:l.safeMy;
        for(int i=0;i<safe.length;i++){steps.addView(text((i+1)+".  "+safe[i],14,INK,false));if(i<safe.length-1)gap(steps,14);}
        TextView mark=button(prefs.getBoolean("lesson_done_"+currentLesson,false)?
            tr("✓  ပြီးဆုံးပြီးပါပြီ","✓  Lesson completed"):
            tr("✓  ဒီသင်ခန်းစာကို ပြီးဆုံးအဖြစ် မှတ်မယ်","Mark lesson complete"),true);
        final int idx=currentLesson;mark.setOnClickListener(view->{prefs.edit().putBoolean("lesson_done_"+idx,true).apply();currentLesson=-1;page=1;render();});body.addView(mark);gap(body,10);
        TextView practice=button(tr("သင်ယူမှုကို စမ်းသပ်မယ်  →","Test your knowledge  →"),false);
        practice.setOnClickListener(view->{page=2;currentLesson=-1;remedy=-1;render();});body.addView(practice);
    }
    private void quizPage(){
        if(quizFinished){quizResult();return;}
        LearnData.Question q=LearnData.QUIZ[quizIndex];
        section(tr("သိမြင်မှု စမ်းသပ်ချက်","Safety practice"),tr("ဖန်တီးထားသော လိမ်လည်မှုဥပမာများ","Practice with fictional scenarios"));
        LinearLayout counter=panel();counter.addView(text(tr("မေးခွန်း","Question")+" "+(quizIndex+1)+" / "+LearnData.QUIZ.length,12,TEAL,true));
        gap(counter,9);counter.addView(text(english?q.en:q.my,20,INK,true));gap(counter,15);
        String[] options=english?q.optionsEn:q.optionsMy;
        for(int i=0;i<options.length;i++) {
            final int choice=i;TextView opt=button((i+1)+".  "+options[i],false);
            opt.setGravity(Gravity.CENTER_VERTICAL);opt.setMinHeight(d(54));
            if(quizChoice>=0){
                boolean right=i==q.answer;opt.setBackground(outline(right?MINT:(choice==quizChoice?PALE:FAINT),14,right?TEAL:(choice==quizChoice?CORAL:LINE)));
            }
            opt.setOnClickListener(view->{if(quizChoice==-1){quizChoice=choice;if(choice==q.answer)quizScore++;render();}});
            counter.addView(opt);gap(counter,8);
        }
        if(quizChoice>=0){
            line(counter);counter.addView(text(quizChoice==q.answer?
                tr("✓  မှန်ပါတယ်!","✓  Correct!"):tr("အဖြေကို ပြန်လေ့လာကြည့်ပါ","Review the safer answer"),16,quizChoice==q.answer?TEAL:CORAL,true));
            gap(counter,8);counter.addView(text(english?q.explainEn:q.explainMy,13,INK,false));gap(counter,15);
            TextView next=button(quizIndex==LearnData.QUIZ.length-1?tr("ရလဒ်ကြည့်မယ်  →","See results  →"):
                tr("နောက်မေးခွန်း  →","Next question  →"),true);
            next.setOnClickListener(view->{if(quizIndex==LearnData.QUIZ.length-1){quizFinished=true;
                prefs.edit().putInt("quiz_best",Math.max(prefs.getInt("quiz_best",0),quizScore)).apply();}
                else{quizIndex++;quizChoice=-1;}render();});counter.addView(next);
        }else {
            counter.addView(text(tr("အကောင်းဆုံး အဖြေတစ်ခုကို ရွေးပါ။","Choose the safest response."),12,MUTED,false));
        }
        LinearLayout tip=panel();tip.setBackground(bg(FAINT,18));
        tip.addView(text(tr("ဤမေးခွန်းများသည် ပညာရေးအတွက်သာ ဖြစ်ပြီး အန္တရာယ်ကို အလိုအလျောက် မသတ်မှတ်ပေးပါ။",
            "These fictional scenarios are for learning, not real-time scam detection."),12,MUTED,false));
    }
    private void quizResult(){
        LinearLayout win=panel();win.setBackground(bg(MINT,24));
        win.addView(text("★  "+tr("လေ့ကျင့်မှု ပြီးဆုံးပါပြီ","Practice complete"),14,TEAL,true));gap(win,16);
        win.addView(text(quizScore+" / "+LearnData.QUIZ.length,36,INK,true));gap(win,10);
        win.addView(text(quizScore==LearnData.QUIZ.length?
            tr("အဖြေများကို ကောင်းစွာ နားလည်ထားပါပြီ။","You understood every scenario!"):
            tr("ထပ်လေ့ကျင့်ခြင်းဖြင့် ပိုမိုသိမြင်နိုင်ပါတယ်။","Practice again to build safer habits."),14,MUTED,false));gap(win,18);
        TextView again=button(tr("ပြန်လည်လေ့ကျင့်မယ်","Try again"),true);
        again.setOnClickListener(view->{quizIndex=0;quizChoice=-1;quizScore=0;quizFinished=false;render();});win.addView(again);gap(win,9);
        TextView more=button(tr("သင်ခန်းစာများသို့","Review lessons"),false);
        more.setOnClickListener(view->{page=1;render();});win.addView(more);
    }
    private void helpPage(){
        section(tr("လုံခြုံရေးအကူအညီ","Safety toolbox"),tr("မသေချာလျှင် စစ်ဆေးပြီးမှ ဆုံးဖြတ်ပါ","Pause, verify, then decide"));
        LinearLayout scan=panel();scan.setBackground(bg(PALE,20));
        scan.addView(text("⚑  "+tr("လိမ်လည်မှု သတိပေးလက္ခဏာ စစ်မယ်","Scam warning-sign checklist"),18,CORAL,true));gap(scan,8);
        scan.addView(text(tr("ဒီစာရင်းက သင်ကိုယ်တိုင် စဉ်းစားရန်သာ ဖြစ်သည်။ မက်ဆေ့ချ်များကို မဖတ်၊ မပို့၊ မစကင်ပါ။",
            "This is an educational checklist, not an automated scanner. Do not paste sensitive messages here."),12,INK,false));gap(scan,12);
        String[] flagsMy={"ချက်ချင်းလုပ်ရန် ဖိအားပေးသည်","OTP၊ password သို့မဟုတ် PIN တောင်းသည်","ငွေကြိုလွှဲရန် တောင်းသည်","မသေချာသော လင့်ခ်/APK ကို ဖွင့်ခိုင်းသည်","ပို့သူအမည် သို့မဟုတ် အကောင့်ကို အတည်မပြုနိုင်"};
        String[] flagsEn={"They pressure you to act immediately","They ask for OTP, password or PIN","They demand an advance payment","They push an unfamiliar link or APK","You cannot independently verify the sender"};
        for(int i=0;i<checkFlags.length;i++) {
            final int idx=i;
            CheckBox flag=new CheckBox(this);flag.setText(english?flagsEn[i]:flagsMy[i]);flag.setTextSize(13);flag.setTextColor(INK);
            flag.setButtonTintList(ColorStateList.valueOf(TEAL));flag.setChecked(checkFlags[i]);flag.setMinHeight(d(46));
            flag.setOnCheckedChangeListener((button,yes)->{checkFlags[idx]=yes;checked=false;});scan.addView(flag);
        }
        gap(scan,13);TextView result=button(tr("သတိပေးလက္ခဏာများ ကြည့်မယ်","Review warning signs"),true);
        result.setOnClickListener(view->{checked=true;showCheckResult();});scan.addView(result);
        if(checked){gap(scan,10);scan.addView(text(checkResult(),13,CORAL,true));}
        section(tr("ပြဿနာကြုံရင် ဘာလုပ်မလဲ","If something already happened"),tr("ချက်ချင်းလုပ်ဆောင်နိုင်သည့် အဆင့်များ","Practical recovery steps"));
        for(int i=0;i<LearnData.REMEDIES.length;i++){
            final int idx=i;LearnData.Remedy r=LearnData.REMEDIES[i];
            LinearLayout c=panel();c.addView(text(r.icon+"  "+(english?r.titleEn:r.titleMy)+"    ›",16,INK,true));gap(c,8);
            c.addView(text(english?r.subtitleEn:r.subtitleMy,12,MUTED,false));
            c.setOnClickListener(view->{remedy=idx;render();});
        }
        section(tr("ကိုယ်ရေးအချက်အလက် အာမခံချက်","Privacy by design"),"");
        LinearLayout privacy=panel();privacy.addView(text("✓  "+tr("အကောင့်ဖွင့်ရန် မလိုပါ","No account or sign-in"),13,INK,true));gap(privacy,10);
        privacy.addView(text("✓  "+tr("အင်တာနက်မလိုဘဲ သင်ယူနိုင်သည်","Lessons and quizzes work offline"),13,INK,true));gap(privacy,10);
        privacy.addView(text("✓  "+tr("တည်နေရာ၊ ဖုန်းစာရင်း၊ SMS၊ ကင်မရာ မတောင်းပါ","No location, contacts, SMS or camera permissions"),13,INK,true));gap(privacy,10);
        privacy.addView(text("✓  "+tr("လေ့လာမှုမှတ်တမ်းသည် ဖုန်းအတွင်းမှာသာ ရှိသည်","Learning progress is stored only on your device"),13,INK,true));
        section(tr("ယုံကြည်ရသော လမ်းညွှန်များ","Trusted guidance"),tr("ဤလင့်ခ်များကို နှိပ်မှသာ browser ဖွင့်သည်","Optional sources open in your browser"));
        resource("FTC — Avoid phishing", "https://consumer.ftc.gov/articles/how-recognize-avoid-phishing-scams");
        resource("Google — Recover compromised account", "https://support.google.com/accounts/answer/6294825");
        resource("CISA — Secure Our World", "https://www.cisa.gov/secure-our-world");
        LinearLayout note=panel();note.addView(text(tr("သတိပြုရန်","Important"),15,INK,true));gap(note,8);
        note.addView(text(tr("ဤအက်ပ်သည် သင်ယူမှုနှင့် သတိပေးအချက်အလက်များအတွက်သာ ဖြစ်ပြီး antivirus၊ တရားဝင်သတင်းပို့ဌာန သို့မဟုတ် အရေးပေါ်ဝန်ဆောင်မှု မဟုတ်ပါ။",
            "This is education, not an antivirus, a fraud reporting authority or an emergency service."),12,MUTED,false));
    }
    private void showCheckResult(){
        // Update one instructional result by re-rendering; selections remain in memory.
        render();
    }
    private String checkResult(){
        int n=0;for(boolean v:checkFlags)if(v)n++;
        if(n==0)return tr("သတိပေးလက္ခဏာ မရွေးထားသော်လည်း လုံခြုံကြောင်း အာမမခံနိုင်ပါ။ လွတ်လပ်စွာ အတည်ပြုပါ။",
            "No warning sign selected does NOT mean a message is safe. Verify independently.");
        return tr("သတိပေးလက္ခဏာ "+n+" ခု ရွေးထားသည်။ မသေချာသော လင့်ခ်များနှင့် ငွေလွှဲမှုကို ရပ်ပြီး တရားဝင်ရင်းမြစ်မှ စစ်ဆေးပါ။",
            n+" warning sign(s) selected. Stop before clicking, sending codes or paying; verify through an official channel.");
    }
    private void remedyPage(){
        LearnData.Remedy r=LearnData.REMEDIES[remedy];
        TextView back=button(tr("‹  အကူအညီသို့ ပြန်မယ်","‹  Back to help"),false);
        back.setOnClickListener(view->{remedy=-1;page=3;render();});body.addView(back);gap(body,15);
        LinearLayout hero=panel();hero.setBackground(bg(PALE,22));
        hero.addView(text(r.icon+"  "+(english?r.titleEn:r.titleMy),22,INK,true));gap(hero,8);
        hero.addView(text(english?r.subtitleEn:r.subtitleMy,14,CORAL,false));
        section(tr("ယခုလုပ်ဆောင်ရန်","Steps to take now"),"");
        LinearLayout steps=panel();String[] s=english?r.stepsEn:r.stepsMy;
        for(int i=0;i<s.length;i++){steps.addView(text((i+1)+".  "+s[i],14,INK,false));if(i<s.length-1)gap(steps,17);}
        LinearLayout foot=panel();foot.addView(text(tr("သင့်ဒေသတွင် ဝန်ဆောင်မှုများ မတူနိုင်ပါ။ မသိသော ဖုန်းနံပါတ်၊ လင့်ခ်များအစား သင်သိသော တရားဝင်ဝန်ဆောင်မှုမှ အကူအညီတောင်းပါ။",
            "Services vary by country. Contact banks and support providers via independently verified details, not links sent by a stranger."),12,MUTED,false));
    }
    private void resource(String title,String url){
        TextView row=button(title+"  ↗",false);row.setGravity(Gravity.CENTER_VERTICAL);
        row.setOnClickListener(view->{try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}
            catch(Exception ex){Toast.makeText(this,tr("Browser မဖွင့်နိုင်ပါ","Cannot open a browser"),Toast.LENGTH_LONG).show();}});
        body.addView(row);gap(body,9);
    }
    @Override public void onBackPressed(){
        if(currentLesson>=0){currentLesson=-1;page=1;render();}
        else if(remedy>=0){remedy=-1;page=3;render();}
        else if(page!=0){page=0;render();}
        else super.onBackPressed();
    }
}
