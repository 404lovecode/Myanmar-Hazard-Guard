import json
from pathlib import Path
from burmese_stories import STORIES
r=Path(__file__).resolve().parents[1]/'app/src/main/assets'
(r/'books').mkdir(parents=True,exist_ok=True)
items=[]
for i,(title,genre,summary,text) in enumerate(STORIES,1):
    id=f'my{i:03d}';asset=f'books/{id}.txt';(r/asset).write_text(text,encoding='utf-8')
    items.append(dict(id=id,title=title,author='Myanmar Reading Library · မူရင်းရေးသား',genre=genre,summary=summary,language='my',asset=asset,complete=True,source='Original Burmese short reading'))
(r/'library.json').write_text(json.dumps(items,ensure_ascii=False,indent=2),encoding='utf-8')
print('Seeded',len(items),'original Burmese readings for pre-build compile checks')
