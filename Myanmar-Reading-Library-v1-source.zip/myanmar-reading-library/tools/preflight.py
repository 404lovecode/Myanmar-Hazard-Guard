from pathlib import Path
import json,sys,zipfile
from burmese_stories import STORIES
root=Path(__file__).resolve().parents[1]
books=json.loads((root/'tools/world_catalog.json').read_text(encoding='utf-8'))
assert len(books)>=40
ids=[b['pgid'] for b in books]
assert len(set(ids))==len(ids)
for book in books:
 assert book['title'] and book['author'] and book['summary']
 assert len(book['summary'])>25 and '\u1000'<=book['summary'][0]<='\u109f'
assert len(STORIES)==12
assert all(len(s[-1])>400 and len(s[0])>4 for s in STORIES)
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
assert '<uses-permission' not in manifest
java=(root/'app/src/main/java/mm/reading/library/MainActivity.java').read_text()
for key in ('savedPage','openImport','toggleFavorite','paginate','renderReader','renderLibrary','fillResults'):
 assert key in java
icon=(root/'app/src/main/res/drawable/ic_library.png').read_bytes()
assert icon[:8]==b'\x89PNG\r\n\x1a\n' and len(icon)>10000
print('Preflight passed:',len(books),'world classics candidates +',len(STORIES),'Burmese originals; no Android permissions')
