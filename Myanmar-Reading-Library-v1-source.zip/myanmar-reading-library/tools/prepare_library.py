#!/usr/bin/env python3
"""Bundle free-to-reuse English classics from GITenberg source repositories.

Project Gutenberg's main site is intentionally not scraped. GITenberg is a
GitHub-hosted project of public-domain book repositories. For each selected
older work we fetch the original book file and strip Gutenberg branding/license
boilerplate while preserving the actual literary text. Region-specific rights
remain the distributor's responsibility; no modern translated edition is used.
"""
from __future__ import annotations
import json, os, re, sys, time, urllib.error, urllib.parse, urllib.request
from pathlib import Path
from burmese_stories import STORIES

BASE=Path(__file__).resolve().parents[1]
ASSETS=BASE/'app/src/main/assets'
BOOKS=ASSETS/'books'
CATALOG=BASE/'tools/world_catalog.json'
BOOKS.mkdir(parents=True,exist_ok=True)
GITHUB_TOKEN=os.getenv('GITHUB_TOKEN','')
USER_AGENT='MyanmarReadingLibrary/1.0 (public domain offline packager; open-source educational app)'

def request(url, auth=False, tries=2):
    headers={'User-Agent':USER_AGENT,'Accept':'application/vnd.github+json' if auth else '*/*'}
    if auth and GITHUB_TOKEN:headers['Authorization']='Bearer '+GITHUB_TOKEN
    for i in range(tries):
        try:
            with urllib.request.urlopen(urllib.request.Request(url,headers=headers),timeout=18) as r:
                if r.status!=200:raise OSError(f'HTTP {r.status}')
                data=r.read(8_000_001)
                if len(data)>8_000_000:raise OSError('Book response exceeded 8 MB')
                return data
        except urllib.error.HTTPError as e:
            if e.code in (404,410):return None
            if e.code in (403,429,500,502,503) and i+1<tries:
                time.sleep(2+3*i);continue
            raise
    return None

def repo_candidates(book):
    slug=book['slug']; pgid=book['pgid']
    v=[slug,slug.replace('s-','-s-'),slug.replace('--','-'),slug.replace('-','--'),slug.replace('The-',''),slug.replace('A-','')]
    if 'Alices-' in slug:v+=['Alice-s-Adventures-in-Wonderland','Alice_s-Adventures-in-Wonderland']
    if 'Jane-Eyre' in slug:v+=['Jane-Eyre--An-Autobiography']
    if 'Moby-Dick' in slug:v+=['Moby-Dick-Or-The-Whale','Moby-Dick--or-The-Whale']
    if 'Jekyll' in slug:v+=['The-Strange-Case-of-Dr.-Jekyll-and-Mr.-Hyde']
    if 'Monte-Cristo' in slug:v+=['The-Count-of-Monte-Cristo_','The-Count-of-Monte-Cristo']
    if 'Gullivers' in slug:v+=['Gulliver-s-Travels']
    if 'War-and-Peace' in slug:v+=['War-and-Peace--Volume-1','War-and-Peace']
    seen=set()
    for s in v:
        s=s.strip('-_')
        repo=f'{s}_{pgid}'
        if repo not in seen:
            seen.add(repo);yield repo

def text_urls(repo,id):
    for branch in ('master','main'):
        for filename in (f'{id}-0.txt',f'{id}.txt'):
            yield f'https://raw.githubusercontent.com/GITenberg/{repo}/{branch}/{filename}'

def find_repo_via_search(id):
    if not GITHUB_TOKEN:return []
    search='org:GITenberg in:name _'+str(id)
    q='https://api.github.com/search/repositories?q='+urllib.parse.quote(search)+'&per_page=20'
    try:
        data=json.loads(request(q,auth=True,tries=3) or b'{}')
        return [i['name'] for i in data.get('items',[]) if i.get('name','').endswith('_'+str(id))]
    except Exception as ex:
        print('Github catalog lookup unavailable for',id,repr(ex)[:130],flush=True)
        return []

def fetch_text(book):
    i=book['pgid']; already=set()
    # Guess the classic's GitHub slug first; avoid quota-consuming search when possible.
    for repo in repo_candidates(book):
        already.add(repo)
        for url in text_urls(repo,i):
            try: raw=request(url,tries=1)
            except Exception:continue
            if raw and len(raw)>16000:return repo,raw
    # Search GITenberg's public GitHub repository index with this workflow token.
    if GITHUB_TOKEN:
        time.sleep(2.2)
    for repo in find_repo_via_search(i):
        if repo in already:continue
        for url in text_urls(repo,i):
            try:raw=request(url,tries=1)
            except Exception:continue
            if raw and len(raw)>16000:return repo,raw
    return None,None

def strip_pg_boilerplate(raw):
    text=raw.decode('utf-8-sig','replace').replace('\r\n','\n').replace('\r','\n')
    # Remove Gutenberg's full front/back matter, preserving the literary content.
    start=re.search(r'(?im)^\*{3}\s*START OF (?:THE |THIS )?PROJECT GUTENBERG\s+(?:EBOOK|E-BOOK)\b[^\n]*\*{3}[^\n]*\n',text)
    if not start:
        start=re.search(r'(?im)^\*{3}\s*START OF\s+[^\n]*GUTENBERG[^\n]*\*{3}[^\n]*\n',text)
    end=re.search(r'(?im)^\*{3}\s*END OF (?:THE |THIS )?PROJECT GUTENBERG\s+(?:EBOOK|E-BOOK)\b[^\n]*\*{3}',text)
    if not end:
        end=re.search(r'(?im)^\*{3}\s*END OF\s+[^\n]*GUTENBERG[^\n]*\*{3}',text)
    if start and end and start.end()<end.start():text=text[start.end():end.start()]
    elif start:text=text[start.end():]
    elif end:text=text[:end.start()]
    else:
        # Accept only after screening: a copy of Gutenberg's trademark/terms
        # must never be hidden in the app by a failed marker parser.
        if 'project gutenberg' in text.lower():raise ValueError('unrecognized legal boilerplate')
    text=re.sub(r'(?m)\n{5,}','\n\n\n',text).strip()
    if len(text)<14000:raise ValueError('not a substantial book text')
    if re.search(r'(?i)THE FULL PROJECT GUTENBERG LICENSE',text):raise ValueError('license footer remained')
    return text+'\n'

def main():
    plan=json.loads(CATALOG.read_text(encoding='utf8'))
    library=[];failures=[]
    for no,book in enumerate(plan,1):
        print(f'[{no}/{len(plan)}] {book["title"]} (id {book["pgid"]})',flush=True)
        repo,raw=fetch_text(book)
        if not raw:
            failures.append(book['id']);print('  ⚠ source not available, omitted',flush=True);continue
        try:txt=strip_pg_boilerplate(raw)
        except Exception as exc:
            failures.append(book['id']);print('  ⚠ not bundled:',exc,flush=True);continue
        asset='books/'+book['id']+'.txt'
        (ASSETS/asset).write_text(txt,encoding='utf8')
        entry={k:v for k,v in book.items() if k not in ('pgid','slug')}
        entry.update(asset=asset,sourceUrl=f'https://github.com/GITenberg/{repo}',complete=True,chars=len(txt))
        library.append(entry)
        print('  ✓',repo,len(txt),'characters',flush=True)
    for n,(title,genre,summary,body) in enumerate(STORIES,1):
        id='my%03d'%n
        asset='books/'+id+'.txt'
        (ASSETS/asset).write_text(body+'\n',encoding='utf8')
        library.append({'id':id,'title':title,'author':'Myanmar Reading Library • မူရင်းရေးသား',
            'genre':genre,'summary':summary,'language':'my','full':True,'complete':True,
            'source':'Original Burmese short reading','sourceUrl':'','asset':asset,'chars':len(body)})
    (ASSETS/'library.json').write_text(json.dumps(library,ensure_ascii=False,indent=2),encoding='utf8')
    stats={'EnglishFullBooks':len([a for a in library if a['language']=='en']),
           'OriginalBurmeseShortReadings':len(STORIES),'FailedBookIds':failures,
           'Total':len(library)}
    (BASE/'library-build-report.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2),encoding='utf8')
    print('FINAL LIBRARY',json.dumps(stats),flush=True)
    if stats['EnglishFullBooks']<25:
        raise SystemExit('Fewer than 25 complete source novels could be verified. Refusing to publish an inflated count.')

if __name__=='__main__':main()
