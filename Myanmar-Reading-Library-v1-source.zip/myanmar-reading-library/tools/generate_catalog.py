import json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
# ID | English title | author | genre | Burmese introduction (NOT a translation) | preferred GITenberg slug
rows='''1342|Pride and Prejudice|Jane Austen|Romance|မိသားစု၊ ချစ်ခြင်းမေတ္တာနှင့် လူမှုအဆင့်အတန်းအကြောင်း ဝတ္ထုကြီး။|Pride-and-Prejudice
11|Alice’s Adventures in Wonderland|Lewis Carroll|Fantasy|အံ့ဖွယ်ရာ ကမ္ဘာထဲသို့ ရောက်ရှိသွားသော အဲလစ်၏ စိတ်ကူးယဉ်ခရီး။|Alices-Adventures-in-Wonderland
84|Frankenstein|Mary Shelley|Science Fiction|သိပ္ပံတီထွင်မှု၊ တာဝန်ယူမှုနှင့် လူသားဆန်မှုအကြောင်း ဂန္ထဝင်ဝတ္ထု။|Frankenstein
345|Dracula|Bram Stoker|Mystery|သရဲနှင့် သဘာဝလွန် လျှို့ဝှက်ဆန်းကြယ်မှုများပါဝင်သည့် ဂန္ထဝင်။|Dracula
1661|The Adventures of Sherlock Holmes|Arthur Conan Doyle|Mystery|ရှားလော့ဟုမ်း၏ စုံထောက်ဇာတ်လမ်းတိုများ စုစည်းမှု။|The-Adventures-of-Sherlock-Holmes
2701|Moby-Dick|Herman Melville|Adventure|ပင်လယ်၊ ဝေလငါးနှင့် အိုင်းဟပ်ကပ္ပတိန်၏ စွဲလမ်းမှုအကြောင်း။|Moby-Dick--Or-The-Whale
98|A Tale of Two Cities|Charles Dickens|Historical|လန်ဒန်နှင့် ပါရီမြို့နှစ်မြို့အကြား ပြင်သစ်တော်လှန်ရေးခေတ် ဇာတ်လမ်း။|A-Tale-of-Two-Cities
1400|Great Expectations|Charles Dickens|Classics|ပစ်ပ်ဆိုသည့် လူငယ်၏ ကြီးပြင်းလာမှုနှင့် ဘဝမျှော်လင့်ချက်များ။|Great-Expectations
1260|Jane Eyre|Charlotte Brontë|Romance|စိတ်ဓာတ်ခိုင်မာသည့် ဂျိန်း၏ ဘဝနှင့် ချစ်ခြင်းမေတ္တာ။|Jane-Eyre
768|Wuthering Heights|Emily Brontë|Romance|အင်္ဂလိပ်ကျေးလက်ဒေသမှ ချစ်ခြင်းနှင့် ဆက်ဆံရေးပဋိပက္ခများ။|Wuthering-Heights
174|The Picture of Dorian Gray|Oscar Wilde|Classics|အလှအပ၊ စိတ်ဆန္ဒနှင့် ကိုယ်ကျင့်တရားအကြောင်း စိတ်ကူးယဉ်ဇာတ်လမ်း။|The-Picture-of-Dorian-Gray
35|The Time Machine|H. G. Wells|Science Fiction|အနာဂတ်သို့ ခရီးသွားနိုင်သည့် စက်ကိရိယာတစ်ခုအကြောင်း။|The-Time-Machine
36|The War of the Worlds|H. G. Wells|Science Fiction|ကမ္ဘာမြေသို့ ထူးဆန်းသော ဧည့်သည်များ ရောက်လာသည့် သိပ္ပံစိတ်ကူးယဉ်ဇာတ်လမ်း။|The-War-of-the-Worlds
74|The Adventures of Tom Sawyer|Mark Twain|Adventure|မစ္စစ္စပီမြစ်နားရှိ ကလေးဘဝ စွန့်စားခန်းများ။|The-Adventures-of-Tom-Sawyer
76|Adventures of Huckleberry Finn|Mark Twain|Adventure|ဟပ်ကယ်ဘယ်ရီဖင်၏ မြစ်ကြောင်းခရီးနှင့် လူမှုဘဝစူးစမ်းမှု။|Adventures-of-Huckleberry-Finn
120|Treasure Island|Robert Louis Stevenson|Adventure|မြေပုံ၊ ပင်လယ်ဓားပြနှင့် ရတနာရှာဖွေခရီး။|Treasure-Island
1184|The Count of Monte Cristo|Alexandre Dumas|Adventure|မတရားမှု၊ လွတ်မြောက်မှုနှင့် တုံ့ပြန်မှုအကြောင်း ရှည်လျားသည့် ဝတ္ထု။|The-Count-of-Monte-Cristo
1257|The Three Musketeers|Alexandre Dumas|Adventure|ပြင်သစ်ဓားသမားများ၏ မိတ်ဆွေဖြစ်မှုနှင့် စွန့်စားခန်းများ။|The-Three-Musketeers
103|Around the World in Eighty Days|Jules Verne|Adventure|ကမ္ဘာပတ်ခရီးကို ရက်ရှစ်ဆယ်အတွင်း ပြီးမြောက်စေရန် ကြိုးစားမှု။|Around-the-World-in-Eighty-Days
164|Twenty Thousand Leagues Under the Seas|Jules Verne|Science Fiction|ပင်လယ်အောက် နော်တီးလပ်စ် ရေငုပ်သင်္ဘော၏ စိတ်လှုပ်ရှားဖွယ်ခရီး။|Twenty-Thousand-Leagues-under-the-Sea
113|The Secret Garden|Frances Hodgson Burnett|Children|လျှို့ဝှက်ဥယျာဉ်တစ်ခုနှင့် ကလေးများ၏ စိတ်ဓာတ်ပြောင်းလဲမှု။|The-Secret-Garden
514|Little Women|Louisa May Alcott|Family|ညီအစ်မလေးယောက်၏ မိသားစုဘဝ၊ အိပ်မက်နှင့် ကြီးပြင်းလာမှု။|Little-Women
43|The Strange Case of Dr. Jekyll and Mr. Hyde|Robert Louis Stevenson|Mystery|လူသား၏ ကောင်းသောဘက်နှင့် ဆိုးသောဘက်ကို စူးစမ်းသည့် ဂန္ထဝင်။|The-Strange-Case-of-Dr-Jekyll-and-Mr-Hyde
12|Through the Looking-Glass|Lewis Carroll|Fantasy|အဲလစ်၏ မှန်ကမ္ဘာတွင်းမှ ထူးဆန်းသော အဖြစ်အပျက်များ။|Through-the-Looking-Glass
55|The Wonderful Wizard of Oz|L. Frank Baum|Fantasy|ဒေါရသီနှင့် သူငယ်ချင်းများ၏ အော့ဇ်ကမ္ဘာ စွန့်စားခန်း။|The-Wonderful-Wizard-of-Oz
16|Peter Pan|J. M. Barrie|Children|မကြီးပြင်းချင်သော ကလေးပီတာပန်နှင့် နေဗာလန်းဒ်။|Peter-Pan
45|Anne of Green Gables|L. M. Montgomery|Family|အန်း၏ ရွှင်လန်းတက်ကြွသော စိတ်ကူးနှင့် မိသားစုအသစ်။|Anne-of-Green-Gables
500|The Adventures of Pinocchio|Carlo Collodi|Children|သစ်သားရုပ်ကလေး၏ စိတ်ဝင်စားဖွယ် ဘဝသင်ခန်းစာများ။|The-Adventures-of-Pinocchio
46|A Christmas Carol|Charles Dickens|Family|ကြင်နာမှု၊ ပြောင်းလဲနိုင်ခြင်းနှင့် အခြားသူများကို စာနာမှု။|A-Christmas-Carol
829|Gulliver’s Travels|Jonathan Swift|Fantasy|ထူးခြားသော နိုင်ငံများသို့ ဂယ်လီဗာ၏ သရော်စာဆန်သော ခရီး။|Gullivers-Travels
996|Don Quixote|Miguel de Cervantes|Classics|စိတ်ကူးယဉ်လောကထဲမှ ရဲရင့်သော သူရဲကောင်း၏ ရယ်မောဖွယ်ခရီး။|Don-Quixote
2554|Crime and Punishment|Fyodor Dostoevsky|Classics|အပြစ်၊ နောင်တနှင့် စိတ်ပိုင်းဆိုင်ရာ ပဋိပက္ခများကို ဖော်ပြသည့် ရုရှားဝတ္ထု။|Crime-and-Punishment
1399|Anna Karenina|Leo Tolstoy|Romance|မိသားစု၊ လူမှုဘဝနှင့် ချစ်ခြင်းမေတ္တာအကြောင်း ရုရှားဝတ္ထု။|Anna-Karenina
2600|War and Peace|Leo Tolstoy|Historical|စစ်ပွဲ၊ ငြိမ်းချမ်းရေးနှင့် လူနေမှုဘဝအကြောင်း ရှည်လျားသည့် ဝတ္ထု။|War-and-Peace
2852|The Hound of the Baskervilles|Arthur Conan Doyle|Mystery|ရှားလော့ဟုမ်းနှင့် ဝတ်ဆန်၏ နာမည်ကျော် စုံထောက်အမှု။|The-Hound-of-the-Baskervilles
33|The Scarlet Letter|Nathaniel Hawthorne|Historical|လူမှုအမြင်နှင့် ကိုယ်ကျင့်တရားဆိုင်ရာ ဝတ္ထု။|The-Scarlet-Letter
215|The Call of the Wild|Jack London|Adventure|တောရိုင်းဘဝနှင့် လွတ်လပ်မှုဆီသို့ ခွေးတစ်ကောင်၏ ခရီး။|The-Call-of-the-Wild
910|White Fang|Jack London|Adventure|တောရိုင်းတိရစ္ဆာန်တစ်ကောင်၏ ယုံကြည်မှုနှင့် ပြောင်းလဲမှု။|White-Fang
236|The Jungle Book|Rudyard Kipling|Children|တောအုပ်အတွင်း တိရစ္ဆာန်များနှင့် မိုဂလီ၏ ဇာတ်လမ်းများ။|The-Jungle-Book
289|The Wind in the Willows|Kenneth Grahame|Children|မိတ်ဆွေတိရစ္ဆာန်များ၏ မြစ်ကမ်းပါးနှင့် တောအုပ်ဘဝ။|The-Wind-in-the-Willows
158|Emma|Jane Austen|Romance|အင်္ဂလိပ်လူ့အဖွဲ့အစည်းနှင့် အမ်မာ၏ မှားယွင်းသော ခန့်မှန်းမှုများ။|Emma
161|Sense and Sensibility|Jane Austen|Romance|ညီအစ်မနှစ်ဦး၏ ချစ်ခြင်းမေတ္တာနှင့် ဆုံးဖြတ်ချက်များ။|Sense-and-Sensibility
5230|The Invisible Man|H. G. Wells|Science Fiction|မမြင်နိုင်သော လူတစ်ဦး၏ သိပ္ပံစမ်းသပ်မှုနှင့် အကျိုးဆက်များ။|The-Invisible-Man
2638|The Idiot|Fyodor Dostoevsky|Classics|ရုရှားလူ့အဖွဲ့အစည်းအတွင်း ရိုးသားသူတစ်ဦး၏ စိန်ခေါ်မှုများ။|The-Idiot
28054|The Brothers Karamazov|Fyodor Dostoevsky|Classics|ညီအစ်ကိုများ၊ မိသားစုနှင့် ဘဝ၏ ကျင့်ဝတ်မေးခွန်းများ။|The-Brothers-Karamazov'''
books=[]
for line in rows.splitlines():
    i,t,author,genre,summary,slug=line.split('|')
    books.append(dict(id='g'+i,pgid=int(i),title=t,author=author,genre=genre,summary=summary,slug=slug,language='en',full=True,source='GITenberg'))
assert len(books)==45,len(books)
(root/'tools'/'world_catalog.json').write_text(json.dumps(books,ensure_ascii=False,indent=2),encoding='utf8')
print('Novel catalog entries:',len(books))
