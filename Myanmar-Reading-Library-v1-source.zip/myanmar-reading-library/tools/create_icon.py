from PIL import Image,ImageDraw,ImageFilter
from pathlib import Path
import math
S=1024
img=Image.new('RGBA',(S,S))
p=img.load()
for y in range(S):
 for x in range(S):
  t=min(1,max(0,(x*.38+y*.62)/S))
  r=int(13+10*t);g=int(87+47*t);b=int(78+19*t)
  d=math.hypot(x-S*.5,y-S*.43)/S
  p[x,y]=(max(0,int(r-d*13)),max(0,int(g-d*28)),max(0,int(b-d*18)),255)
a=ImageDraw.Draw(img,'RGBA')
a.rounded_rectangle((28,28,996,996),radius=208,outline=(221,189,107,255),width=19)
a.ellipse((210,145,818,750),fill=(255,225,126,18))
# Golden rising moon/sun halo
a.ellipse((413,203,610,400),fill=(245,197,89,245))
a.ellipse((447,220,597,367),fill=(255,239,172,255))
# Book back shadow
a.polygon([(149,488),(480,492),(512,537),(537,491),(880,490),(882,755),(539,758),(510,800),(478,759),(147,760)],fill=(3,45,42,110))
# Pages left/right
for shift,c in [(0,(247,242,214,255)),(18,(231,233,201,255))]:
 a.polygon([(160+shift,440),(482,443),(507,476),(505,772),(466,736),(162+shift,731)],fill=c)
a.polygon([(507,476),(542,443),(869,440),(869,731),(551,736),(508,772)],fill=(255,250,224,255))
a.line([(508,476),(508,772)],fill=(214,165,83,255),width=14)
a.arc((191,463,484,765),215,305,fill=(218,166,84,160),width=14)
a.arc((531,463,833,765),236,328,fill=(219,165,89,160),width=14)
# Small leaf/bookmark
for dy in [0,60,120]:
 a.arc((221,479+dy,467,619+dy),205,307,fill=(108,145,122,150),width=8)
 a.arc((557,479+dy,815,620+dy),230,340,fill=(108,145,122,150),width=8)
# golden bookmark
poly=[(685,472),(736,472),(736,608),(712,584),(685,608)]
a.polygon(poly,fill=(238,178,77,255))
# tiny speckles
for x,y,r in [(268,277,8),(737,331,7),(791,238,5),(214,355,6),(772,410,4)]:
 a.ellipse((x-r,y-r,x+r,y+r),fill=(250,224,157,185))
path=Path('/mnt/data/myanmar-reading-library/app/src/main/res/drawable/ic_library.png')
img.resize((512,512),Image.Resampling.LANCZOS).save(path,optimize=True)
print(path, path.stat().st_size)
