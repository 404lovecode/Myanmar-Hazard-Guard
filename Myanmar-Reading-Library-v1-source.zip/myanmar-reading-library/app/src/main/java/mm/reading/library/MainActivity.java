package mm.reading.library;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;

/** Free, offline, Burmese-first reading library; no Internet or tracking permissions. */
public final class MainActivity extends Activity {
    private static final int IMPORT_REQUEST=1842;
    private final ArrayList<JSONObject> books=new ArrayList<>();
    private final Map<String,JSONObject> byId=new HashMap<>();
    private SharedPreferences prefs;
    private LinearLayout frame, body;
    private ScrollView scroll;
    private int tab=0, languageFilter=0;
    private String genreFilter="all", activeId="", query="";
    private ArrayList<String> pages=new ArrayList<>();
    private int currentPage=0;
    private int loadSequence=0;
    private boolean dark=false, english=false;
    private int BG=0, SURFACE=0, SURFACE_ALT=0, INK=0, MUTED=0, TEAL=0, TEAL_SOFT=0, BORDER=0, GOLD=0;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs=getSharedPreferences("myanmar_reading_library_v1",MODE_PRIVATE);
        dark=prefs.getBoolean("dark",false);
        english=prefs.getBoolean("english",false);
        setupPalette();
        loadCatalog();
        render();
    }
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private int color(String value){return Color.parseColor(value);}
    private String tr(String my,String en){return english?en:my;}
    private void setupPalette() {
        BG=color(dark?"#101E20":"#F6F4EC");
        SURFACE=color(dark?"#1D3030":"#FFFFFF");
        SURFACE_ALT=color(dark?"#273C3A":"#E6F2E8");
        INK=color(dark?"#F6F4E8":"#193830");
        MUTED=color(dark?"#B8CAC4":"#647970");
        TEAL=color(dark?"#6ED5BA":"#136D5A");
        TEAL_SOFT=color(dark?"#153E37":"#E1F3EA");
        BORDER=color(dark?"#385552":"#DFE7E0");
        GOLD=color(dark?"#EAC87F":"#AA7836");
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(dark?0:View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
    }
    private void loadCatalog(){
        books.clear();byId.clear();
        try{
            String json=readAsset("library.json");
            JSONArray arr=new JSONArray(json);
            for(int i=0;i<arr.length();i++)addBook(arr.getJSONObject(i));
            JSONArray added=new JSONArray(prefs.getString("imports","[]"));
            for(int i=0;i<added.length();i++){
                JSONObject book=added.optJSONObject(i);
                if(book!=null && new File(getFilesDir(),book.optString("asset")).isFile())addBook(book);
            }
        }catch(Exception ex){Toast.makeText(this,"Library data unavailable: "+ex.getMessage(),Toast.LENGTH_LONG).show();}
    }
    private void addBook(JSONObject b){books.add(b);byId.put(b.optString("id"),b);}
    private String readAsset(String path)throws Exception{
        try(InputStream in=getAssets().open(path)){return utf8(in);}
    }
    private String utf8(InputStream in)throws Exception{
        ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;
        while((n=in.read(b))!=-1){out.write(b,0,n);if(out.size()>8_000_000)throw new Exception("File too large");}
        return out.toString("UTF-8");
    }
    private String bookText(JSONObject book)throws Exception{
        String a=book.optString("asset","");
        if(a.startsWith("imports/")){
            try(InputStream in=new java.io.FileInputStream(new File(getFilesDir(),a))){return utf8(in);}
        }
        if(!a.startsWith("books/") || a.contains(".."))throw new Exception("Invalid book path");
        return readAsset(a);
    }
    private boolean favorite(String id){return prefs.getBoolean("fav_"+id,false);}
    private void toggleFavorite(String id){
        prefs.edit().putBoolean("fav_"+id,!favorite(id)).apply();
        render();
    }
    private int fontSize(){return prefs.getInt("font",20);}
    private int savedPage(String id){return prefs.getInt("page_"+id,0);}
    private void saveProgress(){
        if(!activeId.isEmpty() && pages.size()>0){
            prefs.edit().putInt("page_"+activeId,currentPage)
                .putString("recent",activeId).putInt("total_"+activeId,pages.size()).apply();
        }
    }
    private GradientDrawable rounded(int bg,int stroke,float radius){
        GradientDrawable d=new GradientDrawable();d.setColor(bg);d.setCornerRadius(dp(radius));
        if(stroke!=0)d.setStroke(dp(1),stroke);
        return d;
    }
    private LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout horizontal(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private void padding(View view,int a,int b,int c,int d){view.setPadding(dp(a),dp(b),dp(c),dp(d));}
    private void marginTop(View view,int top){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(top);body.addView(view,p);}
    private TextView text(String value,int size,int c,boolean bold){
        TextView t=new TextView(this);t.setText(value);t.setTextColor(c);t.setTextSize(TypedValue.COMPLEX_UNIT_SP,size);
        t.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);
        t.setIncludeFontPadding(true);
        t.setLineSpacing(dp(3),1.07f);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        return t;
    }
    private TextView button(String value,boolean filled){
        TextView b=text(value,14,filled?Color.WHITE:TEAL,true);
        b.setGravity(Gravity.CENTER);padding(b,13,11,13,11);
        b.setBackground(rounded(filled?color("#176D59"):TEAL_SOFT,filled?0:BORDER,15));
        b.setMinHeight(dp(48));return b;
    }
    private LinearLayout card(){
        LinearLayout c=vertical();padding(c,16,16,16,16);
        c.setBackground(rounded(SURFACE,BORDER,20));return c;
    }
    private TextView smallPill(String s,boolean selected){
        TextView p=text(s,12,selected?Color.WHITE:INK,selected);
        p.setGravity(Gravity.CENTER);padding(p,12,8,12,8);
        p.setBackground(rounded(selected?color("#136D5A"):SURFACE,selected?0:BORDER,22));return p;
    }
    private void addBody(View v,int top){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(top);body.addView(v,p);}
    private void section(String title,String caption){
        TextView t=text(title,19,INK,true);addBody(t,20);
        if(!caption.isEmpty())addBody(text(caption,12,MUTED,false),3);
    }
    private void render(){
        setupPalette();
        frame=vertical();frame.setBackgroundColor(BG);setContentView(frame);
        if(!activeId.isEmpty()){renderReader();return;}
        ScrollView sc=new ScrollView(this);sc.setFillViewport(false);sc.setVerticalScrollBarEnabled(false);
        frame.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        scroll=sc;body=vertical();padding(body,18,14,18,28);sc.addView(body);
        if(tab==0)renderHome();
        else if(tab==1)renderLibrary();
        else if(tab==2)renderFavorites();
        else renderSettings();
        renderBottom();
    }
    private void renderBottom(){
        LinearLayout nav=horizontal();padding(nav,7,7,7,11);
        nav.setBackgroundColor(SURFACE);
        String[] icons={"⌂","▤","♥","⚙"};
        String[] my={"ပင်မ","စာအုပ်များ","သိမ်းထား","ဆက်တင်"};
        String[] en={"Home","Books","Saved","Settings"};
        for(int i=0;i<4;i++){
            final int idx=i;
            LinearLayout slot=vertical();slot.setGravity(Gravity.CENTER);padding(slot,0,4,0,4);
            TextView icon=text(icons[i],23,tab==i?TEAL:MUTED,true);icon.setGravity(Gravity.CENTER);slot.addView(icon);
            TextView name=text(tr(my[i],en[i]),11,tab==i?TEAL:MUTED,tab==i);name.setGravity(Gravity.CENTER);slot.addView(name);
            if(tab==i)slot.setBackground(rounded(TEAL_SOFT,0,15));
            nav.addView(slot,new LinearLayout.LayoutParams(0,dp(57),1));
            slot.setOnClickListener(v->{tab=idx;query="";render();});
        }
        frame.addView(nav);
    }
    private void renderHero(boolean compact){
        LinearLayout hero=vertical();padding(hero,21,18,21,21);
        GradientDrawable gd=new GradientDrawable(GradientDrawable.Orientation.TL_BR,
            new int[]{color("#0B544B"),color("#188271")});gd.setCornerRadius(dp(22));hero.setBackground(gd);
        TextView over=text(tr("အခမဲ့ • အင်တာနက်မလို • ကိုယ်ပိုင်စာကြည့်တိုက်","FREE • OFFLINE • PRIVATE"),11,color("#C6EAD8"),true);hero.addView(over);
        TextView title=text(tr("မြန်မာစာကြည့်တိုက်","Myanmar Reading Library"),compact?23:26,Color.WHITE,true);
        LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,-2);tp.topMargin=dp(11);hero.addView(title,tp);
        TextView tag=text(tr("ဖတ်ကြည့်ပါ • သင်ယူပါ • စိတ်ကူးယဉ်ပါ","Read • Learn • Imagine"),13,color("#E5F6E9"),false);hero.addView(tag);
        LinearLayout stats=horizontal();padding(stats,0,15,0,0);
        int novels=0,myanmar=0;for(JSONObject b:books){if("my".equals(b.optString("language")))myanmar++;else novels++;}
        TextView count=text(novels+" "+tr("ကမ္ဘာ့ဝတ္ထု","classic books")+"   ·   "+myanmar+" "+tr("မြန်မာဝတ္ထုတို","Burmese readings"),12,color("#F8E3B4"),true);
        stats.addView(count);hero.addView(stats);
        addBody(hero,5);
    }
    private void renderHome(){
        renderHero(false);
        String recent=prefs.getString("recent","");
        if(byId.containsKey(recent)){
            JSONObject book=byId.get(recent);LinearLayout c=card();
            c.setBackground(rounded(TEAL_SOFT,0,19));
            c.addView(text(tr("ဆက်ဖတ်ရန် • Continue reading","Continue reading"),12,TEAL,true));
            TextView title=text(book.optString("title"),17,INK,true);LinearLayout.LayoutParams x=new LinearLayout.LayoutParams(-1,-2);x.topMargin=dp(6);c.addView(title,x);
            int p=savedPage(recent),total=prefs.getInt("total_"+recent,0);
            c.addView(text(total>0?(p+1)+" / "+total+" "+tr("စာမျက်နှာ","pages"):"",12,MUTED,false));
            TextView go=button(tr("စာဖတ်ခြင်းဆက်ရန်  →","Continue reading  →"),true);
            LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(-1,-2);gp.topMargin=dp(11);c.addView(go,gp);
            go.setOnClickListener(v->openBook(recent));addBody(c,14);
        }
        section(tr("ဘာဖတ်ချင်လဲ?","Find your next book"),tr("စာအုပ်အပြည့်အစုံနှင့် မြန်မာဝတ္ထုတိုများ","Complete English classics and original Burmese stories"));
        LinearLayout quick=horizontal();TextView my=button(tr("မြန်မာစာအုပ်တို","Burmese reads"),false),world=button(tr("ကမ္ဘာ့ဝတ္ထု","World classics"),false);
        LinearLayout.LayoutParams q1=new LinearLayout.LayoutParams(0,-2,1);q1.rightMargin=dp(8);quick.addView(my,q1);quick.addView(world,new LinearLayout.LayoutParams(0,-2,1));
        my.setOnClickListener(v->{languageFilter=1;tab=1;render();});world.setOnClickListener(v->{languageFilter=2;tab=1;render();});addBody(quick,12);
        section(tr("လူကြိုက်များသော ဂန္ထဝင်များ","Featured classics"),tr("မူရင်း English စာအုပ်အပြည့်၊ မြန်မာမိတ်ဆက်စာဖြင့်","Full English text with Burmese introductions"));
        int cards=0;String[] feature={"g1342","g11","g1661","g84","g345","g120"};
        for(String id:feature){if(byId.containsKey(id)){addBookCard(byId.get(id));cards++;}}
        if(cards==0){for(JSONObject b:books){if("en".equals(b.optString("language"))){addBookCard(b);if(++cards>=4)break;}}}
        section(tr("မြန်မာဘာသာ ဝတ္ထုတိုများ","Short Burmese readings"),tr("ဤအက်ပ်အတွက် အသစ်ရေးသားထားသော စာဖတ်စရာများ","Original short stories written for this app"));
        int shown=0;for(JSONObject b:books){if("my".equals(b.optString("language"))){addBookCard(b);if(++shown>=3)break;}}
    }
    private String[] genres(){return new String[]{"all","Romance","Mystery","Adventure","Classics","Children","Fantasy","Science Fiction","Historical","Family"};}
    private void renderLibrary(){
        TextView title=text(tr("စာအုပ်စင်","Bookshelf"),27,INK,true);addBody(title,8);
        TextView sub=text(tr("နာမည်၊ စာရေးသူ သို့မဟုတ် အမျိုးအစားကို ရှာပါ","Search title, author or category"),13,MUTED,false);addBody(sub,2);
        EditText search=new EditText(this);
        search.setSingleLine(true);search.setTextSize(15);search.setTextColor(INK);search.setHintTextColor(MUTED);
        search.setHint(tr("⌕  စာအုပ်ရှာရန်","⌕  Search books"));search.setBackground(rounded(SURFACE,BORDER,15));padding(search,14,11,14,11);
        search.setText(query);addBody(search,14);
        LinearLayout lang=horizontal();String[] labs={tr("အားလုံး","All"),tr("မြန်မာ","Burmese"),tr("ကမ္ဘာ့ဂန္ထဝင်","World classics")};
        for(int i=0;i<3;i++){final int filter=i;TextView b=smallPill(labs[i],languageFilter==i);
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,i==2?1.3f:1f);if(i>0)lp.leftMargin=dp(6);lang.addView(b,lp);
            b.setOnClickListener(v->{languageFilter=filter;render();});}
        addBody(lang,11);
        HorizontalScrollView strip=new HorizontalScrollView(this);strip.setHorizontalScrollBarEnabled(false);
        LinearLayout chips=horizontal();for(String g:genres()){
            final String value=g;String label="all".equals(g)?tr("အမျိုးအစားအားလုံး","All genres"):g;
            TextView chip=smallPill(label,genreFilter.equals(g));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-2,-2);p.rightMargin=dp(7);chips.addView(chip,p);
            chip.setOnClickListener(v->{genreFilter=value;render();});}
        strip.addView(chips);addBody(strip,12);
        LinearLayout results=vertical();addBody(results,6);
        search.addTextChangedListener(new TextWatcher(){
            @Override public void beforeTextChanged(CharSequence s,int a,int c,int f){}
            @Override public void onTextChanged(CharSequence s,int a,int b,int c){query=s.toString();fillResults(results);}
            @Override public void afterTextChanged(Editable s){}
        });
        fillResults(results);
    }
    private boolean matches(JSONObject b){
        String lang=b.optString("language");
        if(languageFilter==1&&!"my".equals(lang))return false;
        if(languageFilter==2&&!"en".equals(lang))return false;
        if(!genreFilter.equals("all")&&!genreFilter.equalsIgnoreCase(b.optString("genre")))return false;
        if(query.trim().isEmpty())return true;
        String q=Normalizer.normalize(query.trim(),Normalizer.Form.NFC).toLowerCase(Locale.ROOT);
        String value=(b.optString("title")+" "+b.optString("author")+" "+b.optString("genre")+" "+b.optString("summary")).toLowerCase(Locale.ROOT);
        return value.contains(q);
    }
    private void fillResults(LinearLayout container){
        container.removeAllViews();int count=0;
        ArrayList<JSONObject> filtered=new ArrayList<>();for(JSONObject b:books)if(matches(b))filtered.add(b);
        Collections.sort(filtered,(a,b)->a.optString("title").compareToIgnoreCase(b.optString("title")));
        TextView total=text(filtered.size()+" "+tr("အုပ် ရရှိသည်","books available"),12,MUTED,true);
        LinearLayout.LayoutParams top=new LinearLayout.LayoutParams(-1,-2);top.topMargin=dp(9);container.addView(total,top);
        for(JSONObject book:filtered)addBookCard(container,book);
        if(filtered.isEmpty()){
            TextView none=text(tr("ဤရှာဖွေမှုနှင့် ကိုက်ညီသော စာအုပ်မရှိပါ။","No matching books found."),14,MUTED,false);
            padding(none,10,18,10,18);container.addView(none);
        }
    }
    private void addBookCard(JSONObject b){addBookCard(body,b);}
    private void addBookCard(LinearLayout container,JSONObject book){
        String id=book.optString("id");boolean my="my".equals(book.optString("language"));
        LinearLayout c=card();LinearLayout header=horizontal();
        LinearLayout iconBox=vertical();iconBox.setGravity(Gravity.CENTER);
        iconBox.setBackground(rounded(my?color(dark?"#405744":"#E3EAD4"):color(dark?"#3E4B58":"#E2EAF1"),0,12));
        TextView ico=text(my?"စာ":"▤",my?15:26,my?color("#556E2D"):color("#235E6B"),true);ico.setGravity(Gravity.CENTER);iconBox.addView(ico);
        header.addView(iconBox,new LinearLayout.LayoutParams(dp(56),dp(68)));
        LinearLayout names=vertical();LinearLayout.LayoutParams namesP=new LinearLayout.LayoutParams(0,-2,1);namesP.leftMargin=dp(12);
        names.addView(text(book.optString("title"),16,INK,true));
        TextView author=text(book.optString("author"),12,MUTED,false);LinearLayout.LayoutParams a=new LinearLayout.LayoutParams(-1,-2);a.topMargin=dp(4);names.addView(author,a);
        TextView kind=text((my?tr("မြန်မာမူရင်းဝတ္ထုတို","Original Burmese short story"):tr("အင်္ဂလိပ်မူရင်း ဝတ္ထုအပြည့်","Full original English novel"))+"  ·  "+book.optString("genre"),11,TEAL,false);
        LinearLayout.LayoutParams kp=new LinearLayout.LayoutParams(-1,-2);kp.topMargin=dp(4);names.addView(kind,kp);
        header.addView(names,namesP);
        TextView fav=text(favorite(id)?"♥":"♡",27,favorite(id)?color("#C86C59"):MUTED,false);
        fav.setGravity(Gravity.CENTER);header.addView(fav,new LinearLayout.LayoutParams(dp(36),dp(46)));
        fav.setOnClickListener(v->{prefs.edit().putBoolean("fav_"+id,!favorite(id)).apply();fav.setText(favorite(id)?"♥":"♡");fav.setTextColor(favorite(id)?color("#C86C59"):MUTED);});
        c.addView(header);
        TextView desc=text(book.optString("summary"),13,MUTED,false);desc.setMaxLines(2);
        LinearLayout.LayoutParams d=new LinearLayout.LayoutParams(-1,-2);d.topMargin=dp(9);c.addView(desc,d);
        LinearLayout bottom=horizontal();LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2);bp.topMargin=dp(12);
        int pg=savedPage(id),last=prefs.getInt("total_"+id,0);
        TextView progress=text(last>0?(int)(100f*pg/last)+"% "+tr("ဖတ်ပြီး","read"):tr("ဖတ်ရှုရန် အသင့်","Ready to read"),11,MUTED,false);
        bottom.addView(progress,new LinearLayout.LayoutParams(0,-2,1));
        TextView open=button(tr("ဖတ်မည်  →","Read  →"),true);bottom.addView(open);
        open.setOnClickListener(v->openBook(id));c.setOnClickListener(v->openBook(id));
        c.addView(bottom,bp);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(10);container.addView(c,lp);
    }
    private void renderFavorites(){
        addBody(text(tr("သိမ်းထားသော စာအုပ်များ","Saved books"),27,INK,true),9);
        addBody(text(tr("ကြိုက်နှစ်သက်သော စာအုပ်များကို ဤနေရာတွင် တွေ့နိုင်သည်။","Your favorite reads live only on this phone."),13,MUTED,false),4);
        int count=0;for(JSONObject b:books)if(favorite(b.optString("id"))){addBookCard(b);count++;}
        if(count==0){LinearLayout c=card();c.addView(text(tr("♥  စာအုပ်တစ်အုပ်ကို နှလုံးပုံနှိပ်၍ သိမ်းထားနိုင်သည်။","♥  Tap the heart on any book to save it here."),15,INK,false));addBody(c,18);}
    }
    private void renderSettings(){
        addBody(text(tr("စာဖတ်ခြင်း ဆက်တင်များ","Reading settings"),26,INK,true),8);
        addBody(text(tr("သင့်ဖုန်းအတွင်းသာ သိမ်းဆည်းမည်။ အကောင့်မလို၊ ကြော်ငြာမရှိ။","Everything stays on your device. No account or ads."),13,MUTED,false),5);
        LinearLayout opts=card();
        TextView theme=button(dark?tr("☀  အလင်းရောင်မုဒ်","☀  Light theme"):tr("☾  အမှောင်မုဒ်","☾  Dark theme"),false);
        theme.setOnClickListener(v->{dark=!dark;prefs.edit().putBoolean("dark",dark).apply();render();});opts.addView(theme);
        TextView language=button(tr("English UI သို့ ပြောင်းရန်","မြန်မာ UI သို့ ပြောင်းရန်"),false);
        LinearLayout.LayoutParams a=new LinearLayout.LayoutParams(-1,-2);a.topMargin=dp(9);opts.addView(language,a);
        language.setOnClickListener(v->{english=!english;prefs.edit().putBoolean("english",english).apply();render();});
        TextView textSize=text(tr("စာလုံးအရွယ်အစား","Reading font size")+": "+fontSize(),15,INK,true);
        LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,-2);tp.topMargin=dp(18);opts.addView(textSize,tp);
        SeekBar size=new SeekBar(this);size.setMax(17);size.setProgress(fontSize()-16);opts.addView(size);
        size.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            @Override public void onProgressChanged(SeekBar bar,int p,boolean user){textSize.setText(tr("စာလုံးအရွယ်အစား","Reading font size")+": "+(16+p));}
            @Override public void onStartTrackingTouch(SeekBar b){}
            @Override public void onStopTrackingTouch(SeekBar b){prefs.edit().putInt("font",16+b.getProgress()).apply();}
        });
        TextView importBtn=button(tr("＋  ကိုယ်ပိုင် TXT စာအုပ်ထည့်ရန်","＋  Import your own TXT book"),true);
        LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,-2);ip.topMargin=dp(10);opts.addView(importBtn,ip);
        importBtn.setOnClickListener(v->openImport());
        addBody(opts,17);
        section(tr("စာအုပ်မူပိုင်ခွင့်","Book rights and sources"),"");
        LinearLayout note=card();
        note.addView(text(tr("ကမ္ဘာ့ဝတ္ထုအပြည့်များသည် မူပိုင်ခွင့်ကင်းလွတ်ကြောင်း အမေရိကန်ဥပဒေအရ ဖော်ပြထားသည့် ရှေးဟောင်းအင်္ဂလိပ်စာပေများဖြစ်သည်။ စာအုပ်တစ်အုပ်ချင်း၏ မူရင်းအရင်းအမြစ်ကို ပြထားသည်။ မြန်မာဘာသာမိတ်ဆက်စာသည် ဝတ္ထုအပြည့် ဘာသာပြန်မဟုတ်ပါ။ မိမိနိုင်ငံ၏ မူပိုင်ခွင့်ဥပဒေကို စစ်ဆေးပါ။",
            "The full English classics come from GITenberg's public-domain collections (US assessment). Burmese descriptions are introductions, not complete translations. Copyright rules vary by country; check local law before redistribution."),13,INK,false));
        TextView source=button(tr("ရင်းမြစ်ဝက်ဘ်ဆိုဒ်","About source library"),false);
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);sp.topMargin=dp(13);note.addView(source,sp);
        source.setOnClickListener(v->openWebsite("https://gitenberg.org/"));
        addBody(note,11);
        section(tr("အသုံးပြုမှု","About the app"),"");
        addBody(text(tr("ဤအက်ပ်သည် အင်တာနက်မလိုသော အခမဲ့စာဖတ်အက်ပ်ဖြစ်ပြီး ကိုယ်ရေးအချက်အလက်များကို မပို့ပါ။ မြန်မာဝတ္ထုတို ၁၂ ပုဒ်ကို ဤအက်ပ်အတွက် အသစ်ရေးသားထားသည်။",
            "Free • Offline • No tracking • No Android permissions. Includes 12 original short Burmese readings plus complete English classics."),13,MUTED,false),6);
    }
    private void openWebsite(String url){
        try{startActivity(new Intent(Intent.ACTION_VIEW,android.net.Uri.parse(url)));}
        catch(Exception e){Toast.makeText(this,tr("ဘရောက်ဇာမရရှိပါ","No browser available"),Toast.LENGTH_SHORT).show();}
    }
    private void openImport(){
        Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);intent.setType("text/plain");intent.addCategory(Intent.CATEGORY_OPENABLE);
        try{startActivityForResult(intent,IMPORT_REQUEST);}catch(Exception e){Toast.makeText(this,"File picker not available",Toast.LENGTH_LONG).show();}
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request!=IMPORT_REQUEST||result!=RESULT_OK||data==null||data.getData()==null)return;
        final android.net.Uri uri=data.getData();
        new Thread(()->{
            try{
                String content;
                try(InputStream in=getContentResolver().openInputStream(uri)){if(in==null)throw new Exception("Unable to open file");content=utf8(in);}
                if(content.trim().length()<30)throw new Exception("The text file appears empty");
                String id="custom"+System.currentTimeMillis();File folder=new File(getFilesDir(),"imports");folder.mkdirs();
                String asset="imports/"+id+".txt";
                try(OutputStream out=new FileOutputStream(new File(getFilesDir(),asset))){out.write(content.getBytes("UTF-8"));}
                String title="My book";
                try(android.database.Cursor c=getContentResolver().query(uri,new String[]{android.provider.OpenableColumns.DISPLAY_NAME},null,null,null)){
                    if(c!=null && c.moveToFirst())title=c.getString(0);
                }catch(Exception ignored){}
                JSONObject b=new JSONObject().put("id",id).put("title",title).put("author",tr("ကိုယ်ပိုင်စာအုပ်","My own imported book"))
                    .put("genre","Personal").put("summary",tr("ကိုယ်ပိုင်ဖိုင်မှ တင်ထားသည်","Imported from your device"))
                    .put("language",containsBurmese(content)?"my":"en")
                    .put("asset",asset).put("source","Personal import").put("sourceUrl","").put("complete",true);
                JSONArray imports=new JSONArray(prefs.getString("imports","[]"));imports.put(b);
                prefs.edit().putString("imports",imports.toString()).apply();
                runOnUiThread(()->{loadCatalog();tab=1;languageFilter=0;genreFilter="all";query="";render();Toast.makeText(this,tr("စာအုပ်ထည့်ပြီးပါပြီ","Book imported"),Toast.LENGTH_LONG).show();});
            }catch(Exception e){runOnUiThread(()->Toast.makeText(this,tr("စာအုပ်ထည့်ရန် မအောင်မြင်ပါ: ","Import failed: ")+e.getMessage(),Toast.LENGTH_LONG).show());}
        }).start();
    }
    private boolean containsBurmese(String t){int count=0;for(int i=0;i<Math.min(t.length(),700);i++){char c=t.charAt(i);if(c>='\u1000'&&c<='\u109F')count++;}return count>12;}
    private void openBook(String id){
        if(!byId.containsKey(id))return;
        activeId=id;pages.clear();currentPage=0;int seq=++loadSequence;
        render();
        JSONObject book=byId.get(id);
        new Thread(()->{
            try{
                String content=bookText(book);
                int cap="my".equals(book.optString("language"))?900:2800;
                ArrayList<String> result=paginate(content,cap);
                runOnUiThread(()->{
                    if(seq!=loadSequence||!id.equals(activeId))return;
                    pages=result;currentPage=Math.min(Math.max(0,savedPage(id)),pages.size()-1);saveProgress();render();
                });
            }catch(Exception ex){runOnUiThread(()->{
                if(seq!=loadSequence)return;
                new AlertDialog.Builder(this).setTitle(tr("ဖတ်ရှု၍ မရပါ","Unable to open book"))
                    .setMessage(ex.getMessage()).setPositiveButton("OK",(d,w)->{activeId="";render();}).show();
            });}
        },"OfflineBookReader").start();
    }
    private static ArrayList<String> paginate(String data,int max){
        ArrayList<String> out=new ArrayList<>();String text=data.replace("\r\n","\n").replace('\r','\n').trim();
        String[] paragraphs=text.split("\\n\\s*\\n");StringBuilder current=new StringBuilder();
        for(String paragraph:paragraphs){
            String p=paragraph.trim();if(p.isEmpty())continue;
            while(!p.isEmpty()){
                if(current.length()>0 && current.length()+p.length()+2>max){out.add(current.toString().trim());current.setLength(0);}
                int room=max-current.length()-2;
                if(p.length()<=room){current.append(p).append("\n\n");p="";}
                else{
                    int cut=Math.min(p.length(),Math.max(100,room));
                    if(cut<p.length()){
                        int boundary=Math.max(p.lastIndexOf(' ',cut),p.lastIndexOf('\n',cut));
                        if(boundary>cut/2)cut=boundary+1;
                        if(cut>0 && cut<p.length() && Character.isHighSurrogate(p.charAt(cut-1)))cut--;
                    }
                    if(cut<=0)cut=Math.min(100,p.length());
                    current.append(p,0,cut);out.add(current.toString().trim());current.setLength(0);
                    p=p.substring(cut).trim();
                }
            }
        }
        if(current.length()>0)out.add(current.toString().trim());
        if(out.isEmpty())out.add("");return out;
    }
    private void renderReader(){
        JSONObject book=byId.get(activeId);if(book==null){activeId="";render();return;}
        LinearLayout head=horizontal();padding(head,13,9,13,9);head.setBackgroundColor(SURFACE);
        TextView back=button("‹  "+tr("ပြန်ရန်","Back"),false);
        head.addView(back);back.setOnClickListener(v->{loadSequence++;activeId="";pages.clear();render();});
        LinearLayout title=vertical();LinearLayout.LayoutParams t=new LinearLayout.LayoutParams(0,-2,1);t.leftMargin=dp(12);
        TextView name=text(book.optString("title"),15,INK,true);name.setSingleLine(true);name.setEllipsize(android.text.TextUtils.TruncateAt.END);title.addView(name);
        title.addView(text(tr("စာဖတ်နေသည်","Reading"),11,MUTED,false));head.addView(title,t);
        TextView heart=text(favorite(activeId)?"♥":"♡",27,favorite(activeId)?color("#C46A63"):MUTED,true);
        heart.setGravity(Gravity.CENTER);head.addView(heart,new LinearLayout.LayoutParams(dp(43),dp(48)));
        heart.setOnClickListener(v->{prefs.edit().putBoolean("fav_"+activeId,!favorite(activeId)).apply();heart.setText(favorite(activeId)?"♥":"♡");});
        frame.addView(head);
        ScrollView sc=new ScrollView(this);sc.setFillViewport(false);sc.setVerticalScrollBarEnabled(false);scroll=sc;
        frame.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        body=vertical();padding(body,20,20,20,35);sc.addView(body);
        if(pages.isEmpty()){
            ProgressBar loading=new ProgressBar(this);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(50),dp(50));lp.gravity=Gravity.CENTER;lp.topMargin=dp(85);body.addView(loading,lp);
            addBody(text(tr("စာအုပ်ဖွင့်နေသည်…","Preparing book…"),15,MUTED,false),15);return;
        }
        boolean my="my".equals(book.optString("language"));
        if(currentPage==0){
            addBody(text(book.optString("title"),24,INK,true),5);
            addBody(text(book.optString("author"),13,MUTED,false),6);
            LinearLayout intro=card();intro.setBackground(rounded(TEAL_SOFT,0,17));
            intro.addView(text(tr("အကြောင်းအရာ မိတ်ဆက်","Introduction"),12,TEAL,true));
            TextView caption=text(book.optString("summary"),14,INK,false);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.topMargin=dp(6);intro.addView(caption,cp);
            addBody(intro,17);
            if(!my){addBody(text(tr("အောက်ပါစာသားသည် မူရင်း အင်္ဂလိပ်စာအုပ်အပြည့် ဖြစ်သည်။ မြန်မာမိတ်ဆက်စာသည် ဝတ္ထုဘာသာပြန် မဟုတ်ပါ။",
                "The following is the complete English-language text. The Burmese introduction is not a novel translation."),12,MUTED,false),10);}
        }
        LinearLayout reading=card();reading.setBackground(rounded(dark?color("#20312E"):color("#FFFDF6"),dark?0:color("#E9E1D4"),15));
        TextView copy=text(pages.get(currentPage),fontSize(),INK,false);copy.setTextIsSelectable(true);copy.setLineSpacing(dp(7),1.18f);
        copy.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);reading.addView(copy);
        addBody(reading,15);
        TextView hint=text(tr("စာမျက်နှာ ","Page ")+(currentPage+1)+" / "+pages.size(),12,MUTED,false);
        hint.setGravity(Gravity.CENTER);addBody(hint,17);
        // Optional source citation opens the user's browser, never loads content silently.
        if(currentPage==0 && book.optString("sourceUrl").startsWith("https://")){
            TextView source=text(tr("ရင်းမြစ်: ","Source: ")+book.optString("source"),11,MUTED,false);addBody(source,10);
            source.setOnClickListener(v->openWebsite(book.optString("sourceUrl")));
        }
        LinearLayout footer=vertical();padding(footer,12,7,12,12);footer.setBackgroundColor(SURFACE);
        SeekBar progress=new SeekBar(this);progress.setMax(Math.max(1,pages.size()-1));progress.setProgress(currentPage);footer.addView(progress);
        progress.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            @Override public void onProgressChanged(SeekBar s,int p,boolean user){}
            @Override public void onStartTrackingTouch(SeekBar b){}
            @Override public void onStopTrackingTouch(SeekBar b){goPage(b.getProgress());}
        });
        LinearLayout buttons=horizontal();
        TextView prev=button(tr("‹  ယခင်","‹  Previous"),false),next=button(tr("နောက်ထပ်  ›","Next  ›"),true);
        LinearLayout.LayoutParams prevP=new LinearLayout.LayoutParams(0,-2,1);prevP.rightMargin=dp(8);buttons.addView(prev,prevP);
        buttons.addView(next,new LinearLayout.LayoutParams(0,-2,1));
        prev.setEnabled(currentPage>0);prev.setAlpha(currentPage==0?.4f:1f);
        next.setEnabled(currentPage<pages.size()-1);next.setAlpha(currentPage==pages.size()-1?.4f:1f);
        prev.setOnClickListener(v->goPage(currentPage-1));next.setOnClickListener(v->goPage(currentPage+1));
        footer.addView(buttons);frame.addView(footer);
    }
    private void goPage(int page){if(page<0||page>=pages.size())return;currentPage=page;saveProgress();render();}
    @Override public void onBackPressed(){
        if(!activeId.isEmpty()){loadSequence++;activeId="";pages.clear();render();}
        else if(tab!=0){tab=0;render();}else super.onBackPressed();
    }
}
