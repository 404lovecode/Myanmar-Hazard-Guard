# မြန်မာစာကြည့်တိုက် · Myanmar Reading Library

**Free, private, Burmese-first offline Android eBook library.** Version 1.0.0. No accounts, ads, or Android permissions.

## Included

- 45 *candidate* classic English novels selected from the GitHub-hosted **GITenberg** public-domain editions. During the verified Android build, complete text editions are downloaded from their GITenberg GitHub repositories and checked. Unavailable or invalid editions are **omitted**, never advertised as complete. The final APK reports the actual number of successfully bundled works.
- 12 **original Burmese short readings written for this project**. They are not represented as classic novels or translations.
- English full-text novels with original Burmese introductions. **Burmese introductions are not full Burmese translations.** No unlicensed modern literary translations are bundled.
- Offline paging (designed for long novels), reading progress, favorite books, search, genre and language filters, dark mode, adjustable reading text size, and a one-tap **Import TXT** workflow using Android's file picker. Import uses the Storage Access Framework with no broad storage permission.
- All reading progress, bookmarks, preferences, and imported files remain locally on the device; app does not connect to any server.

## Book licensing and source

- [GITenberg](https://gitenberg.org/) repositories host source texts originally collected from Project Gutenberg. Texts are selected from older U.S. public-domain works, stripped of Project Gutenberg trademark/license headers and footers, then repackaged in the Android APK as self-contained offline readings. All records have a link to the exact GITenberg source repository. Acknowledging sources is not a claim of affiliation with either organization.
- **Important:** Public-domain status varies by jurisdiction. GITenberg and Project Gutenberg focus on U.S. public-domain determinations. Check applicable laws before distributing the package in another country, including Myanmar and Thailand.
- Original Burmese story texts and Burmese descriptions were newly authored for this app and should be proofread by fluent native speakers before public distribution.
- Individual GITenberg sources occasionally use different edition, author spelling, transcription and chapter formatting. The source/build report lists titles that passed validation.

## Developer build

```bash
python3 tools/preflight.py
python3 tools/prepare_library.py  # requires Internet and may use GITHUB_TOKEN for catalog lookup
# Android SDK 35, Java 17, Gradle 8.11.1:
gradle :app:assembleDebug
```

The GitHub Actions workflow provides reproducible public source collection and Android build verification. A physical Android device still needs to be used for runtime UI and performance checks.
