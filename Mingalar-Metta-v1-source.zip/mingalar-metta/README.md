# Mingalar Metta • မင်္ဂလာမေတ္တာ

Independent, free, Burmese-first Android Buddhist reflection and prayer practice app.

## Inspired by, not copied from, Dhamma Payeik

The *concept* of easy-to-browse Burmese chanting, Dhamma readings, favorites, and meditation is informed by Dhamma Payeik's official app listing. This software has an original layout, icon, gong tone, wording, package, and name. It does not include or redistribute Dhamma Payeik's source code, audio, artwork, translated content, or trademark.

## v1 features
- 13 offline readings organized into Chant, Study and Practice. A limited number of **traditional Pali invocations** are included, plus original Burmese learning notes. Study guides are **explicitly summaries, not full canonical sutras**.
- Burmese-first navigation, optional English explanations, responsive large-print reader, adjustable font size, dark mode.
- Offline search, favorites and saved last read.
- Buddhist digital bead counter (27, 54, 108) and a separately labeled Islamic Tasbeeh counter (33, 99); counts and completed rounds are local and can be reset.
- 5/10/15-minute meditation timer, original synthesized gentle gong; no downloaded religious recordings.
- Optional Android text-to-speech **for Burmese explanatory notes**, only when a locally installed Burmese voice is available; never claims to have authentic chanting audio.
- No accounts, advertising, analytics, network calls, or Android permissions; all data kept in local SharedPreferences. No online/community ranking.

## Important cultural and accessibility notes
For a public release, ask Burmese-speaking monks/teachers and Pali experts to review transcriptions and explanations, and Islamic reviewers to check the separate tasbeeh presentation. The Pali excerpts and Burmese-script phonetic renderings are not a substitute for authoritative recitation books or teachers. For full verified sutta text, follow source references to SuttaCentral when online using the user's chosen browser. This app does not reproduce third-party translations. Public-domain traditional Pali formulas and *newly authored summaries* only. Real Android devices have varying Burmese offline TTS support.

Reference (features only): https://play.google.com/store/apps/details?id=com.dhamma.dana.dhammapayeik
Canonical references and licensing: https://suttacentral.net/licensing

Build: Android Gradle Plugin 8.9.1, Gradle 8.11.1, Java 17, API35.
