import json, pathlib, xml.etree.ElementTree as ET
root=pathlib.Path(__file__).resolve().parents[1]
records=json.loads((root/'app/src/main/assets/library.json').read_text(encoding='utf-8'))
assert len(records)>=12,len(records)
assert len({r['id'] for r in records})==len(records)
assert all(r['titleMy'] and r['titleEn'] and r['explanationMy'] and r['explanationEn'] for r in records)
assert all(r['source'].startswith('https://suttacentral.net/') for r in records)
assert {r['category'] for r in records}=={'Chant','Study','Practice'}
assert all(r['pali'] for r in records if r['category']=='Chant')
manifest=ET.parse(root/'app/src/main/AndroidManifest.xml').getroot()
assert len(manifest.findall('uses-permission'))==0
print('Validated',len(records),'readings, three categories, sources and zero Android permissions.')
