# Mingalar Metta v2.0 · မင်္ဂလာမေတ္တာ

**An original Burmese-first, free Android Buddhist study, chanting and reflection app.**

## New in v2

- **72 offline entries** across five dedicated sections: Buddha's life (12), introductory Dhamma explanations (26), short traditional chants and formulas (13), study guides to named suttas (5), and practical exercises (16).
- **Detailed Burmese explanations**, English summaries and reference links, saved locally in `assets/library.json`. These are newly authored *study notes*, not complete copies of the Tipiṭaka. The biographical accounts distinguish tradition from established history when possible.
- **Actual recorded chanting audio, not merely text-to-speech:** one **CC0 recorded Three Refuges** chant is bundled in the APK, playable wholly offline with pause, seek, stop and repeat controls. It is a musical rendition and **not a Burmese monastic chanting recording**. Source: **Hariharan (2013)** via Wikimedia Commons, CC0 1.0. https://commons.wikimedia.org/wiki/File:Buddham_Saranam_Gacchami_-_Male_Voice,_with_Female_Chorus.oga
- **Attach personal chant audio** to any library entry by selecting an audio file already on your phone through Android's document picker. It remains private; the app does not upload it. You can remove your imported audio and fall back to the included recording. Ensure you have rights to any recording before redistribution.
- Original bell sound, independent Buddhist and Tasbeeh counters, favorite readings, search, bigger text and dark mode from v1 remain.
- **No login, no ads, no analytics or Android permissions**, including no Internet permission. All embedded material works offline. Device Burmese TTS remains optional only where an offline Burmese voice is installed.

## Important accuracy and scope notes

The Dhamma Payeik application is **a feature reference only**. None of its code, screenshots, artwork, text, or sound files are included. Our UI, summary writings, icon and bell are original. The external chant is separately licensed CC0, with full credit above.

**Not a complete Buddhist canon.** The five named-sutta study guides are summaries, not full sutras. The six newly added recitations are short traditional Pāli verses with no invented Burmese-script pronunciations. Existing v1 Burmese-script Pāli guides and all doctrinal details must be reviewed by monks, Pāli teachers and experienced Burmese language editors before widespread release.

Core references:
- SuttaCentral canonical indices and original sutta references: https://suttacentral.net/
- Four Noble Truths/first sermon SN 56.11: https://suttacentral.net/sn56.11
- Noble Search MN 26: https://suttacentral.net/mn26
- Great Passing DN 16: https://suttacentral.net/dn16
- Buddha sites overview: https://www.vridhamma.org/node/15
- Wikimedia Commons audio public-domain dedication: https://creativecommons.org/publicdomain/zero/1.0/

## Build

Requirements: Java 17, Android SDK 35, Gradle 8.11.1, Android Gradle Plugin 8.9.1, and Python 3.

The real recording is **not duplicated** in this small source ZIP. **To build an offline-audio APK**, first fetch the CC0 recording using `python3 tools/fetch_audio.py` in the `mingalar-metta/` folder, then run `gradle :app:assembleDebug`. The GitHub workflow performs this automatically. The script checks it is an Ogg recording and keeps it under the size limit. If the recording cannot be obtained, the audio-packaging build should fail rather than claiming audio is present.

Android application ID `mm.mingalar.metta`; v2 `versionCode 2`. Debug signing identity may differ from a previous v1 debug APK; an Android device may require uninstalling v1 first, which removes its saved counts and favorites. For public distribution, establish a stable release signing identity.
