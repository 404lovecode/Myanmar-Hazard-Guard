from pathlib import Path
import json
root=Path(__file__).resolve().parents[1]
items=json.loads((root/'app/src/main/assets/library.json').read_text())
assert len(items)==72, len(items)
ids=[entry['id'] for entry in items]
assert len(ids)==len(set(ids))
categories={x['category'] for x in items}
assert categories=={'Life','Dhamma','Chant','Study','Practice'},categories
assert sum(x['category']=='Life' for x in items)==12
assert sum(x['category']=='Dhamma' for x in items)==26
assert sum(x['category']=='Chant' for x in items)==13
assert sum(x['category']=='Study' for x in items)==5
assert sum(x['category']=='Practice' for x in items)==16
for item in items:
 for key in ['id','titleMy','titleEn','explanationMy','explanationEn','source']:
  assert item.get(key), (item['id'],key)
 assert item['source'].startswith('https://')
 assert any('\u1000'<=ch<='\u109F' for ch in item['titleMy']),item['id']
 if item['category'] in ('Life','Dhamma'):
  assert len(item.get('detailsMy',''))>90,item['id']
  assert len(item.get('detailsEn',''))>70,item['id']
assert next(x for x in items if x['id']=='refuge').get('audio')=='refuge_chant'
# Document import relies on SAF and needs zero storage permissions.
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
assert 'uses-permission' not in manifest
print('72 bilingual entries, category structure, audio linking and privacy test passed.')
