package mm.hazardguard;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

public final class HazardRepository {
    private HazardRepository() {}
    public static final String USGS = "https://earthquake.usgs.gov/fdsnws/event/1/query";
    public static final String RONI = "https://www.cpc.ncep.noaa.gov/products/analysis_monitoring/enso/roni/";
    public static final String WEATHER = "https://api.open-meteo.com/v1/forecast";
    public static final String AIR = "https://air-quality-api.open-meteo.com/v1/air-quality";
    public static final String EONET = "https://eonet.gsfc.nasa.gov/api/v3/events?status=open&limit=100";
    public static final String GEOCODE = "https://geocoding-api.open-meteo.com/v1/search";

    public static final class Snapshot {
        public JSONObject quake, globalQuake, events, weather, air, climate;
        public long quakeAt, globalQuakeAt, eventsAt, weatherAt, airAt, climateAt, checkedAt;
        public boolean newQuake, newWorldQuake, newEvents, newWeather, newAir, newClimate;
        public int failed;
        public long lastUpdate() { return Math.max(Math.max(Math.max(quakeAt,weatherAt),Math.max(airAt,climateAt)), Math.max(eventsAt,globalQuakeAt)); }
    }

    public static JSONObject cached(Context c, String key) {
        try { return new JSONObject(Prefs.get(c).getString("data_" + key, "{}")); }
        catch (Exception e) { return new JSONObject(); }
    }
    public static Snapshot snapshot(Context c) {
        SharedPreferences p = Prefs.get(c);
        Snapshot s = new Snapshot();
        s.quake = scoped(c,"quake"); s.weather = scoped(c,"weather");
        s.globalQuake = cached(c,"global_quake"); s.events=cached(c,"events");
        s.air = scoped(c,"air"); s.climate = cached(c,"climate");
        s.quakeAt = scopedTime(c,"quake"); s.weatherAt = scopedTime(c,"weather");
        s.globalQuakeAt = p.getLong("time_global_quake",0); s.eventsAt=p.getLong("time_events",0);
        s.airAt = scopedTime(c,"air"); s.climateAt = p.getLong("time_climate",0);
        s.checkedAt = p.getLong("time_checked",0);
        return s;
    }
    private static void save(Context c, String key, JSONObject data) {
        Prefs.get(c).edit().putString("data_" + key, data.toString()).putLong("time_" + key,System.currentTimeMillis()).apply();
    }
    private static JSONObject scoped(Context c,String key) {
        return Prefs.locationKey(c).equals(Prefs.get(c).getString("location_"+key,"")) ? cached(c,key) : new JSONObject();
    }
    private static long scopedTime(Context c,String key) {
        return Prefs.locationKey(c).equals(Prefs.get(c).getString("location_"+key,"")) ? Prefs.get(c).getLong("time_"+key,0) : 0;
    }
    /** Prevent older asynchronous requests from overwriting new-location data. */
    private static boolean saveScoped(Context c,String key,JSONObject result,String locationKey) {
        if(!locationKey.equals(Prefs.locationKey(c))) return false;
        Prefs.get(c).edit().putString("data_"+key,result.toString())
            .putString("location_"+key,locationKey).putLong("time_"+key,System.currentTimeMillis()).apply();
        return true;
    }
    public static Snapshot update(Context c, boolean notify) {
        final Context app=c.getApplicationContext();
        final double lat=Prefs.latitude(app), lon=Prefs.longitude(app);
        final String selected=Prefs.locationKey(app);
        ExecutorService pool=Executors.newFixedThreadPool(6);
        ArrayList<Future<Boolean>> tasks=new ArrayList<>();
        tasks.add(pool.submit(() -> { try {return saveScoped(app,"quake",new JSONObject(fetch(quakeUrl(lat,lon))),selected);}catch(Exception e){return false;} }));
        tasks.add(pool.submit(() -> { try {return saveScoped(app,"weather",new JSONObject(fetch(weatherUrl(lat,lon))),selected);}catch(Exception e){return false;} }));
        tasks.add(pool.submit(() -> { try {return saveScoped(app,"air",new JSONObject(fetch(airUrl(lat,lon))),selected);}catch(Exception e){return false;} }));
        tasks.add(pool.submit(() -> { try { if(System.currentTimeMillis()-Prefs.get(app).getLong("time_climate",0) < 6*3600_000L) return true; save(app,"climate",parseRoni(fetch(RONI)));return true;}catch(Exception e){return false;} }));
        tasks.add(pool.submit(() -> { try {save(app,"global_quake",new JSONObject(fetch(globalQuakeUrl())));return true;}catch(Exception e){return false;} }));
        tasks.add(pool.submit(() -> { try {save(app,"events",new JSONObject(fetch(EONET)));return true;}catch(Exception e){return false;} }));
        pool.shutdown();
        boolean[] successes=new boolean[tasks.size()];
        for(int i=0;i<tasks.size();i++) {
            try {successes[i]=tasks.get(i).get(18,TimeUnit.SECONDS);}
            catch(Exception e){tasks.get(i).cancel(true);successes[i]=false;}
        }
        pool.shutdownNow();
        Prefs.get(app).edit().putLong("time_checked",System.currentTimeMillis()).apply();
        Snapshot s=snapshot(app);
        s.newQuake=successes[0]; s.newWeather=successes[1];s.newAir=successes[2];
        s.newClimate=successes[3];s.newWorldQuake=successes[4];s.newEvents=successes[5];
        for(boolean success:successes)if(!success)s.failed++;
        // Only earthquakes near the chosen location trigger earthquake notifications.
        if(notify)AlertEngine.evaluate(app,s);
        return s;
    }
    private static String since48h() {
        SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss",Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("UTC"));
        return f.format(new Date(System.currentTimeMillis()-48L*3600_000L));
    }
    private static String quakeUrl(double lat,double lon) {
        return USGS+"?format=geojson&starttime="+since48h()+"&latitude="+lat+"&longitude="+lon
            +"&maxradiuskm=600&minmagnitude=2.5&orderby=time&limit=120";
    }
    private static String globalQuakeUrl() {
        return USGS+"?format=geojson&starttime="+since48h()+"&minmagnitude=4.5&orderby=time&limit=150";
    }
    private static String weatherUrl(double lat,double lon) {
        return WEATHER+"?latitude="+lat+"&longitude="+lon
          +"&current=temperature_2m,relative_humidity_2m,precipitation,wind_speed_10m,weather_code"
          +"&hourly=precipitation,wind_speed_10m&forecast_hours=6&timezone=auto";
    }
    private static String airUrl(double lat,double lon) {
        return AIR+"?latitude="+lat+"&longitude="+lon
          +"&current=us_aqi,pm2_5,pm10&timezone=auto";
    }
    /** Search city names anywhere in the world (no API key; requires network). */
    public static JSONArray places(String query) throws Exception {
        String url=GEOCODE+"?name="+java.net.URLEncoder.encode(query,"UTF-8")+"&count=12&language=en&format=json";
        JSONObject result=new JSONObject(fetch(url));
        JSONArray places=result.optJSONArray("results");return places==null?new JSONArray():places;
    }
    private static String fetch(String url) throws Exception {
        HttpURLConnection connection=(HttpURLConnection)new URL(url).openConnection();
        connection.setConnectTimeout(8000); connection.setReadTimeout(8000);
        connection.setRequestProperty("Accept","application/json,text/html;q=0.9");
        connection.setRequestProperty("User-Agent","MyanmarHazardGuard/1.0 public-data-reader");
        connection.setInstanceFollowRedirects(true);
        try {
            if(connection.getResponseCode()!=200) throw new java.io.IOException("HTTP "+connection.getResponseCode());
            try(InputStream in=connection.getInputStream(); ByteArrayOutputStream out=new ByteArrayOutputStream()) {
                byte[] buffer=new byte[8192]; int len;
                while((len=in.read(buffer))!=-1) {
                    out.write(buffer,0,len);
                    if(out.size()>2_500_000) throw new java.io.IOException("Response too large");
                }
                return out.toString("UTF-8");
            }
        } finally { connection.disconnect(); }
    }
    static JSONObject parseRoni(String html) throws Exception {
        RoniParser.Reading r=RoniParser.parse(html);
        return new JSONObject().put("value",r.value).put("year",r.year)
            .put("season",r.season).put("phase",r.phase)
            .put("consecutive",r.consecutive).put("sustained",r.sustained)
            .put("source",RONI);
    }
    public static double number(JSONObject o, String key) { return o==null ? Double.NaN : o.optDouble(key,Double.NaN); }
    public static double maxFirst(JSONArray a, int n) {
        if(a==null || a.length()==0) return Double.NaN;
        double v=Double.NaN;
        for(int i=0;i<Math.min(n,a.length());i++) {
            double x=a.optDouble(i,Double.NaN);
            if(!Double.isNaN(x)) v=Double.isNaN(v)?x:Math.max(v,x);
        }
        return v;
    }
}
