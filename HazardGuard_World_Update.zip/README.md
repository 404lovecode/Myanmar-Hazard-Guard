# HazardGuard World — Android v2.0

**Worldwide natural-event explorer + location-specific hazard monitoring**, preserving Myanmar as the default starting location, Burmese/English language controls, alerts, vibration and optional foreground speech.

## What changed in v2

- Redesigned dark ocean-blue dashboard, refreshed header, colorful status chips and six-tab navigation.
- 66 starter locations worldwide, including 14 in Myanmar. Search **any other city** through Open-Meteo's international geocoding service, no API key required for ordinary use under its terms.
- **Quakes:** separate *Nearby* and *Worldwide* USGS feeds. Nearby queries reported M2.5+ events within roughly 600 km over 48 hours; global feed queries reported M4.5+ events over 48 hours. Display lists are capped. USGS coverage may be incomplete depending on region. Earthquake push alerts remain restricted to newly reported events around the selected location and the chosen magnitude threshold.
- **World:** NASA EONET currently open natural event records (sampled latest 100 events) including wildfires, severe storms, volcanoes and floods where the provider has records. Counts represent the retrieved subset, not total global events. **EONET cards are informational; these events do not generate emergency notifications**.
- **Environment:** selected-city Open-Meteo modeled air quality and weather, with existing advisory thresholds.
- **El Niño / La Niña:** NOAA Relative Oceanic Niño Index observations as before; this is a global climate context indicator, not a localized forecast or an official El Niño emergency alert.
- Language switch: Burmese/English. Myanmar has Burmese city labels; searched city results are returned in English by the geocoding service.
- Selected location is saved; outdated data for the previous location is hidden until new data loads.
- Local notifications, sound, vibration, optional loud alarm tone and text-to-speech **while the app is open**, based on OS permission and phone voice availability.

## Important safety limitations

This is a **supplementary information and preparedness app**, not a certified early-warning device. No earthquake prediction or official tsunami alerting. NASA EONET is not a complete global disaster register. Weather/AQI values are modeled estimates and can be inaccurate. USGS events are reports of earthquakes that already occurred; some are reported or revised late. Android JobScheduler's requested 15-minute cadence can be delayed, sometimes significantly, by operating-system battery policies; this is **not a guaranteed 15-minute alarm**. Background text-to-speech is not provided. Follow official country emergency alerts and evacuation orders first.

## Getting the APK from your EXISTING GitHub repository — single ZIP upload

1. Download `HazardGuard_World_Update.zip` (distributed separately alongside this source ZIP).
2. In your existing GitHub repository (e.g. `Myanmar-Hazard-Guard`) open **Code → Add file → Upload files**. Upload the **one ZIP file** unchanged, then click **Commit changes**. You do *not* need to upload 66 Java files individually.
3. Open **Code → .github → workflows → main.yml**, click the pencil icon, and use the complete replacement YAML from `GITHUB_UPDATE_INSTRUCTIONS.txt` (distributed separately). Click **Commit changes**.
4. Click **Actions**, open the latest **Build Android APK** run. If it succeeds, under **Artifacts** download **HazardGuard-World-APK**. Extract this downloaded ZIP to obtain `app-debug.apk`.
5. Transfer APK to your Android phone and open it. Enable notifications for alerts. If Android says it cannot update an existing debug installation because signatures differ, first uninstall the older debug APK (this deletes its saved local settings and history), then install the new one.

## Android Studio / full source ZIP

Extract `HazardGuard_World_Android_Source.zip`. Open the `MyanmarHazardGuardAndroid` directory as a Gradle project in Android Studio. With Android SDK Platform 35, Android build tools, JDK 17, and network access for initial Gradle setup, build the `assembleDebug` task. Output: `app/build/outputs/apk/debug/app-debug.apk`. Existing `BUILD_APK_WINDOWS.bat` can do this on properly provisioned Windows machines.

## Public data and attribution

- USGS Earthquake Catalog API — https://earthquake.usgs.gov/fdsnws/event/1/
- NOAA CPC RONI — https://www.cpc.ncep.noaa.gov/products/analysis_monitoring/enso/roni/
- Open-Meteo Forecast API — https://open-meteo.com/en/docs
- Open-Meteo Air Quality API — https://open-meteo.com/en/docs/air-quality-api
- Open-Meteo Geocoding API — https://open-meteo.com/en/docs/geocoding-api
- NASA EONET events — https://eonet.gsfc.nasa.gov/docs/v3

Provider availability, licenses, limits and terms may change. For commercial distribution, review each provider's current usage terms. No third-party analytics, trackers, ads, or API keys are embedded in this project.

## Build status

The source has passed basic XML/resource cross-checking, Java syntax parsing, and NOAA RONI parser unit tests. **The APK has not been compiled or device-tested in the current environment** because Android SDK/Gradle build dependencies are unavailable. The GitHub Actions build is needed to confirm Android compilation and phone behavior.
