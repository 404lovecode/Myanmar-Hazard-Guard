#!/usr/bin/env python3
"""Bundle verified, ancient canonical Pāli roots and SuttaCentral CC0 English translations.

SuttaCentral Bilara dataset is pinned at a published Git commit; fail closed if any
reference changes or cannot be retrieved. This is NOT Dhamma Payeik data.
"""
import hashlib
import json
from pathlib import Path
from urllib.request import Request, urlopen

PIN = "4b0b8739c05b990c54d660d30b62103408d97485"
REPOSITORY = "https://raw.githubusercontent.com/suttacentral/bilara-data/"+ PIN
TITLES = [
("kn/kp/kp1", "သရဏဂုံသုံးပါး", "Three Refuges", "မြတ်စွာဘုရား၊ တရားတော်နှင့် သံဃာတော်ကို မှီခိုရာအဖြစ် ခံယူသည့် ချုပ်ဆိုချက်ဖြစ်ပါသည်။"),
("kn/kp/kp2", "ဆယ်ပါးသီလ", "Ten Training Rules", "သီလလေ့ကျင့်ရန် သတိပြုသင့်သည့် ဆယ်ပါးကို ဖော်ပြသည့် မူရင်းပါဠိစာဖြစ်သည်။"),
("kn/kp/kp3", "ခန္ဓာကိုယ် ၃၂ ပါး", "Thirty-Two Parts of the Body", "ခန္ဓာကိုယ်၏ အစိတ်အပိုင်းများကို သတိထားဆင်ခြင်ရာတွင် အသုံးပြုသည်။"),
("kn/kp/kp4", "ကုမာရပဉှာ", "Questions to a Young Novice", "သင်ယူခြင်းနှင့် တရားအရေအတွက်ဆိုင်ရာ မေးခွန်းငယ်များဖြစ်သည်။"),
("kn/kp/kp5", "မင်္ဂလသုတ်", "Blessings (Maṅgala Sutta)", "လောကီလောကုတ္တရာ မင်္ဂလာတို့ကို သင်ကြားသည့် သုတ်တော်ဖြစ်ပါသည်။"),
("kn/kp/kp6", "ရတနသုတ်", "Jewels (Ratana Sutta)", "ဗုဒ္ဓ၊ ဓမ္မ၊ သံဃာ သုံးရတနာ၏ ဂုဏ်တော်များကို အမှတ်ရသည့် သုတ်တော်ဖြစ်သည်။"),
("kn/kp/kp7", "တိရောကုဋ္ဋသုတ်", "Outside the Walls", "ကွယ်လွန်သူတို့အတွက် ကုသိုလ်အမျှဝေခြင်း၏ အဓိပ္ပါယ်ကို လေ့လာပါ။"),
("kn/kp/kp8", "နိဓိကဏ္ဍသုတ်", "The Hidden Treasure", "ထင်ရှားသော ပစ္စည်းဥစ္စာထက် ကောင်းမှုကုသိုလ်၏ တန်ဖိုးကို ဖော်ပြသည်။"),
("kn/kp/kp9", "ကရဏီယမေတ္တသုတ်", "Loving-kindness (Karaṇīyamettā)", "သတ္တဝါအားလုံးအပေါ် မေတ္တာထားရန် လမ်းညွှန်ထားသော သုတ်တော်ဖြစ်သည်။"),
("kn/snp/vagga1/snp1.8", "ကရဏီယမေတ္တသုတ် (သုတ္တနိပါတ်)", "Loving-kindness (Snp 1.8)", "သုတ္တနိပါတ်တွင် ပါဝင်သော မေတ္တာသုတ်တော် မူရင်းစာဖြစ်သည်။"),
("sn/sn56/sn56.11", "ဓမ္မစက္ကပဝတ္တနသုတ်", "Setting in Motion the Wheel of Dhamma", "မဇ္ဈိမပဋိပဒါ၊ သစ္စာလေးပါးနှင့် မဂ္ဂင်ရှစ်ပါးအကြောင်း မြတ်စွာဘုရား၏ တရားဦးဖြစ်သည်။"),
("mn/mn10", "သတိပဋ္ဌာနသုတ်", "Foundations of Mindfulness", "ကာယ၊ ဝေဒနာ၊ စိတ်၊ ဓမ္မ တို့ကို သတိထားဆင်ခြင်ရန် ညွှန်ကြားသည့် သုတ်တော်ဖြစ်သည်။"),
("dn/dn31", "သိင်္ဂါလောဝါဒသုတ်", "Advice to Sigālaka", "မိသားစု၊ မိတ်ဆွေ၊ ဆရာသမားနှင့် အလုပ်အကိုင်ဆိုင်ရာ ကျင့်ဝတ်များကို ဆွေးနွေးသည်။"),
("kn/dhp/dhp1-20", "ဓမ္မပဒ - ယမကဝဂ်", "Dhammapada: Pairs", "စိတ်၊ စကားနှင့် အပြုအမူ၏ သက်ရောက်မှုကို ပြသသော ဓမ္မပဒအစပိုင်း ဖြစ်ပါသည်။"),
("sn/sn22/sn22.59", "အနတ္တလက္ခဏသုတ်", "Not-self Characteristic", "ရုပ်၊ ဝေဒနာ၊ သညာ၊ သင်္ခါရ၊ ဝိညာဏ်တို့၏ အနတ္တသဘောကို လေ့လာပါ။"),
]

def fetch(relative):
    uri = REPOSITORY + '/' + relative
    req = Request(uri, headers={"User-Agent":"Mingalar-Metta-Open-Canon/3.0 (offline CC0 scripture bundling)","Accept":"application/json"})
    with urlopen(req, timeout=30) as response:
        raw = response.read(2500000)
        if len(raw)>2499999:
            raise RuntimeError('Oversize canonical text')
    obj=json.loads(raw.decode('utf-8'))
    if not isinstance(obj,dict) or len(obj)<2:
        raise ValueError(f'Incomplete canonical source: {relative}')
    return obj

def assemble():
    target=Path(__file__).resolve().parents[1]/'app/src/main/assets/library.json'
    library=json.loads(target.read_text(encoding='utf-8'))
    existing={a['id'] for a in library}
    count=0
    for path,burmese,english,note in TITLES:
        uid=path.rsplit('/',1)[-1]
        root=fetch(f'root/pli/ms/sutta/{path}_root-pli-ms.json')
        translation=fetch(f'translation/en/sujato/sutta/{path}_translation-en-sujato.json')
        common=[key for key in root if key in translation]
        if len(common)<max(2, len(root)//3):
            raise RuntimeError(f'Canonical segment mismatch: {uid}')
        ptext='\n'.join(str(root[k]).strip() for k in root if str(root[k]).strip())
        etext='\n'.join(str(translation[k]).strip() for k in root if str(translation.get(k,'')).strip())
        if len(ptext)<25 or len(etext)<25:
            raise RuntimeError(f'Canonical text suspiciously short: {uid}')
        entry={
          'id':'canon_'+uid.replace('.','_').replace('-','_'),
          'titleMy':burmese,
          'titleEn':english+f' ({uid.upper()})',
          'category':'Canon',
          'kind':'canonical',
          'myanmar':'',
          'pali':ptext,
          'englishText':etext,
          'explanationMy':note,
          'explanationEn':f'A complete canonical root Pāli reading with a public-domain English translation, {uid.upper()}.',
          'detailsMy':note+'\n\nအောက်တွင် မူရင်းပါဠိစာသားအပြည့်နှင့် အများပိုင် English translation ကို စာပိုဒ်လိုက် ဖတ်နိုင်ပါသည်။ မြန်မာဘာသာလုံးစုံ ဘာသာပြန် မပါဝင်သေးပါ။',
          'detailsEn':'The complete published root Pāli and Bhikkhu Sujato’s public-domain English translation are provided below. A complete Burmese translation is not yet included; Burmese explanations are original introductory study notes.',
          'source':f'https://suttacentral.net/{uid}',
          'sourceLicense':'Canonical Pāli; CC0 English translation by Bhikkhu Sujato via SuttaCentral Bilara, pinned '+PIN,
        }
        if entry['id'] in existing:
            raise ValueError('Duplicate canonical entry '+uid)
        library.append(entry);existing.add(entry['id']);count+=1
        print(uid,len(ptext),len(etext),'Pali/English chars')
    target.write_text(json.dumps(library,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('Bundled',count,'complete Pāli canonical works; total readings',len(library))
    if count!=15 or len(library)!=87:
        raise AssertionError('Unexpected canon count')

if __name__=='__main__':assemble()
