from pathlib import Path
import json
root=Path(__file__).resolve().parents[1]
items=json.loads((root/'app/src/main/assets/library.json').read_text(encoding='utf-8'))
assert len(items)==87, len(items)
ids=[entry['id'] for entry in items]
assert len(ids)==len(set(ids)), 'Duplicate IDs'
from collections import Counter
cats=Counter(x['category'] for x in items)
assert cats=={'Life':12,'Dhamma':26,'Chant':13,'Study':5,'Practice':16,'Canon':15},cats
for item in items:
 for key in ['id','titleMy','titleEn','explanationMy','explanationEn','source']:
  assert item.get(key),(item['id'],key)
 assert item['source'].startswith('https://'), item['id']
 assert any('\u1000'<=ch<='\u109F' for ch in item['titleMy']),item['id']
 if item['category'] in ('Life','Dhamma'):
  assert len(item.get('detailsMy',''))>90,item['id']
  assert len(item.get('detailsEn',''))>70,item['id']
 if item['category']=='Canon':
  assert item.get('kind')=='canonical'
  assert len(item.get('pali',''))>40, item['id']
  assert len(item.get('englishText',''))>40, item['id']
  assert item['source'].startswith('https://suttacentral.net/'),item['id']
  assert 'CC0' in item['sourceLicense'],item['id']
assert next(x for x in items if x['id']=='refuge').get('audio')=='refuge_chant'
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
assert 'uses-permission' not in manifest, 'unexpected Android permissions'
java=(root/'app/src/main/java/mm/mingalar/metta/MainActivity.java').read_text()
for required in ('renderAudioLibrary()', 'renderMiniPlayer()', 'renderCategoryTiles()', 'englishText', 'iconParams', 'read_y_', 'setPlaybackParams', 'putStringSet'):
 assert required in java,required
assert (root/'app/src/main/res/drawable/ic_metta.png').stat().st_size>20000
print('PASS: 87 readings including 15 complete canonical Pāli/CC0 English texts; five tabs; original icon; privacy.')
