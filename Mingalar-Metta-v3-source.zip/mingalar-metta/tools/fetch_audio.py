"""Fetch an explicitly CC0 Three Refuges recording into the Android offline resources.

Attribution: Hariharan (8 December 2013), Wikimedia Commons CC0.
https://commons.wikimedia.org/wiki/File:Buddham_Saranam_Gacchami_-_Male_Voice,_with_Female_Chorus.oga
This is a musical arrangement, not a Burmese monastic chanting recording.
"""
from pathlib import Path
import urllib.request
import hashlib
import sys

URLS = [
    'https://archive.org/download/BuddhamSaranamGacchami/BuddhamSaranam...ed.ogg',
    'https://upload.wikimedia.org/wikipedia/commons/8/8d/Buddham_Saranam_Gacchami_-_Male_Voice%2C_with_Female_Chorus.oga',
    'https://commons.wikimedia.org/wiki/Special:Redirect/file/Buddham_Saranam_Gacchami_-_Male_Voice,_with_Female_Chorus.oga',
]
root = Path(__file__).resolve().parents[1]
out = root/'app/src/main/res/raw/refuge_chant.ogg'
if out.is_file() and out.stat().st_size > 100_000:
    print('Existing CC0 audio asset:', out.stat().st_size, 'bytes')
    sys.exit(0)
audio=None
errors=[]
for URL in URLS:
    req=urllib.request.Request(URL, headers={'User-Agent':'Mozilla/5.0 (MingalarMettaOfflineReader/2.0; educational Android app)','Accept':'audio/ogg,application/octet-stream'})
    try:
        with urllib.request.urlopen(req, timeout=45) as r:
            candidate=r.read(5_000_000)
        if candidate[:4]==b'OggS' and len(candidate)>1_000_000:
            audio=candidate
            print('CC0 audio source reached:',URL)
            break
        errors.append(URL+' invalid audio '+repr(candidate[:24]))
    except Exception as exc:
        errors.append(URL+' '+str(exc))
if audio is None:
    raise SystemExit('Cannot package real offline chanting audio: '+ '; '.join(errors))
if not (audio.startswith(b'OggS') and 1_000_000 < len(audio) < 5_000_000):
    raise SystemExit('Downloaded chant has unexpected encoding or length: '+str(len(audio)))
out.parent.mkdir(parents=True,exist_ok=True)
out.write_bytes(audio)
print('CC0 chanting audio packaged:', len(audio),'bytes', 'SHA256:',hashlib.sha256(audio).hexdigest())
