# Mingalar Metta v3 — မင်္ဂလာမေတ္တာ

**A free, original, offline Burmese-first Buddhist Dhamma reader, chanting companion and digital bead counter.**

## New in v3

- New **original** jade/teal and gold Dharma-wheel/lotus/prayer-bead launcher icon, independently created for this project; not based on Dhamma Payeik’s artwork.
- More usable navigation: **Read / Listen / Beads / Saved / More**, searchable reading cards and six large category tiles.
- **87 offline reading entries**: 72 original Burmese-first learning notes and 15 **complete canonical Pāli readings** obtained from SuttaCentral's pinned published Bilara text. Each full reading includes the **CC0 public-domain English translation by Bhikkhu Sujato**; Burmese study introductions are original summaries, **not full Burmese translations**.
- Pāli canonical additions: Khuddakapāṭha 1–9 (including Three Refuges, Maṅgala, Ratana, and Mettā), Snp 1.8, SN 56.11, MN 10, DN 31, Dhammapada 1–20, and SN 22.59.
- Small sticky **mini player** while browsing, dedicated audio library, speed controls, seek, repeat, and one bundled **CC0 recording** of the Three Refuges. Attach additional audio for each reading from your own device through Android's document picker. No recordings or screenshots from Dhamma Payeik are included.
- Remember last reading and scroll position, share short excerpts with source attribution, favorites, adjustable font size, light/dark modes.
- Independent 27/54/108 Buddhist beads and separate 33/99 Tasbeeh mode, vibration feedback, original gong and meditation timer.
- **No login, no ads, no analytics, no internet permission or other Android permissions.** All packaged readings, audio and counts are accessible offline. Optional device text-to-speech needs an installed offline Burmese voice.

## Scope and provenance

**Dhamma Payeik is a feature reference only.** We do not reproduce its source code, branding, interface artwork, audio, translations or in-app data. The app is not affiliated with Dhamma Payeik or its developer. Canonical Pāli scriptures are ancient texts; our source is the independent SuttaCentral Bilara edition and English translations explicitly released under CC0. Visit https://suttacentral.net/licensing.

**Audio licensing:** Hariharan, *Buddham Saranam Gacchami - Male Voice, with Female Chorus* (2013), public domain (CC0), via https://commons.wikimedia.org/wiki/File:Buddham_Saranam_Gacchami_-_Male_Voice,_with_Female_Chorus.oga. This is a musical rendition, **not Burmese Sayadaw chanting**. Authentic Burmese monastic paritta audio requires rights clearance and appropriate verification before inclusion; the app supports attaching your own local recordings.

**Important:** 72 Burmese lessons are original introductory educational notes, not complete canonical translations. The 15 newly added full works are **full Pāli canonical source texts with full English CC0 translations**, and do not yet include complete Burmese translations or verified Burmese-script Pāli pronunciation. Full canon texts and all explanations should be reviewed by knowledgeable Pāli teachers, Sayadaws and Burmese-language editors before wide public distribution. Real-phone playback, accessibility and navigation still require user testing.

## Reproducible building

Prerequisites: Java 17, Android SDK 35, Gradle 8.11.1, Android Gradle Plugin 8.9.1, Python 3, and an internet connection **during build only**.

```sh
python3 tools/fetch_canon.py  # Download 15 publicly licensed complete works, pinned Bilara SHA
python3 tools/fetch_audio.py  # Download CC0 musical Three Refuges recording
python3 tools/validate_content.py
# from project root
gradle --no-daemon :app:assembleDebug
```

`tools/fetch_canon.py` pins Bilara published commit `4b0b8739c05b990c54d660d30b62103408d97485`, validates the Pāli and English segment IDs, and fails if a text is unavailable. `tools/fetch_audio.py` checks for a genuine Ogg recording and similarly fails if the audio cannot be obtained. The successful GitHub Actions build packages all sources so the APK works offline afterwards. Re-running the canonical fetch after the library has already been expanded is not supported; use a fresh source extraction.

Android application ID `mm.mingalar.metta`; v3 `versionCode 3`. Development/debug signing keys may differ across GitHub Actions machines; updating an older debug build can require uninstalling the old app, which deletes locally saved preferences. A fixed release signing key should be configured before public distribution.
