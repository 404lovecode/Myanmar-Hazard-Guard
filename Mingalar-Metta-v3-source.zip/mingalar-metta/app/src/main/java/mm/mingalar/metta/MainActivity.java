package mm.mingalar.metta;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.widget.ImageView;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.view.WindowInsets;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.HorizontalScrollView;
import android.media.PlaybackParams;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/** Independently designed, offline Burmese-first study and reflection app. */
public final class MainActivity extends Activity {
    private final Handler ui=new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private JSONArray library;
    private LinearLayout root, content;
    private ScrollView scroll;
    private int page=0;
    private String activeAudioReading="";
    private TextView miniPlay;
    private TextView miniTitle;
    private String readingId="";
    private String pendingAudioId="";
    private static final int CHOOSE_AUDIO=301;
    private boolean dark=false, burmese=true, ttsReady=false;
    private TextToSpeech tts;
    private MediaPlayer chantPlayer;
    private String currentChant="";
    private boolean chantRepeat=false;
    private SeekBar chantSeek;
    private TextView chantClock,chantPlay;
    private final Runnable chantProgress=new Runnable(){
        @Override public void run(){
            if(chantPlayer==null)return;
            try {
                int total=chantPlayer.getDuration(), current=chantPlayer.getCurrentPosition();
                if(chantSeek!=null && !chantSeek.isPressed())chantSeek.setProgress(current);
                if(chantClock!=null)chantClock.setText(formatDuration(current)+" / "+formatDuration(total));
                if(chantPlay!=null)chantPlay.setText(chantPlayer.isPlaying()?word("Ⅱ  ခေတ္တရပ်","Ⅱ  Pause"):word("▶  ဆက်ဖွင့်","▶  Resume"));
                ui.postDelayed(this,350);
            } catch(Exception ignored){}
        }
    };
    private int BACKGROUND, SURFACE, TEXT, SECONDARY, ACCENT, DARK_GREEN, BORDER, SAGE, WHITE=0xffffffff;
    private int fontSize=19;
    private String mode="buddhist";
    private int buddhistGoal=108,tasbeehGoal=33;
    private TextView countLabel, roundsLabel, timerLabel;
    private ProgressBar progress;
    private boolean timerRunning=false;
    private long timerEnd=0;
    private int timerSeconds=5*60;
    private final Runnable ticker=new Runnable(){
        @Override public void run(){
            if(!timerRunning)return;
            int remain=(int)Math.max(0,(timerEnd-SystemClock.elapsedRealtime()+999)/1000);
            if(remain<=0) {
                timerRunning=false;
                playGong();
                Toast.makeText(MainActivity.this,word("တရားထိုင်ချိန် ပြည့်ပါပြီ","Meditation complete"),Toast.LENGTH_LONG).show();
            }
            if(timerLabel!=null)timerLabel.setText(clock(remain));
            if(!timerRunning) {if(page==1)show();return;}
            ui.postDelayed(this,1000);
        }
    };

    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        prefs=getSharedPreferences("metta_v1_local",MODE_PRIVATE);
        dark=prefs.getBoolean("dark",false);
        burmese=prefs.getBoolean("burmese",true);
        fontSize=prefs.getInt("font",19);
        mode=prefs.getString("counter_mode","buddhist");
        buddhistGoal=prefs.getInt("goal_buddhist",108);
        tasbeehGoal=prefs.getInt("goal_tasbeeh",33);
        readLibrary();
        tts=new TextToSpeech(this,status->ttsReady=status==TextToSpeech.SUCCESS);
        show();
    }
    @Override protected void onResume(){super.onResume();if(timerRunning){ui.removeCallbacks(ticker);ui.post(ticker);}if(chantPlayer!=null){ui.removeCallbacks(chantProgress);ui.post(chantProgress);}}
    @Override protected void onPause(){
        storeReadingPosition();
        super.onPause();ui.removeCallbacks(ticker);ui.removeCallbacks(chantProgress);
        if(chantPlayer!=null && chantPlayer.isPlaying())chantPlayer.pause();}
    @Override protected void onDestroy(){ui.removeCallbacks(ticker);stopChant();if(tts!=null){tts.stop();tts.shutdown();}super.onDestroy();}
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==CHOOSE_AUDIO && resultCode==RESULT_OK && data!=null &&
           data.getData()!=null && !pendingAudioId.isEmpty()){
            try {
                Uri uri=data.getData();
                getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);
                prefs.edit().putString("audio_uri_"+pendingAudioId,uri.toString()).apply();
                stopChant();
                toast("ကိုယ်ပိုင်အသံဖိုင်ကို သိမ်းထားပါပြီ","Your chosen audio is saved for this reading");
                show();
            } catch(Exception ex){toast("အသံဖိုင်ကို ဖွင့်မရပါ","Could not keep access to the chosen audio");}
        }
        pendingAudioId="";
    }
    private void chooseAudioForReading(){
        if(readingId.isEmpty())return;
        pendingAudioId=readingId;
        Intent pick=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        pick.setType("audio/*");
        pick.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try{startActivityForResult(pick,CHOOSE_AUDIO);}
        catch(Exception e){toast("အသံဖိုင်ရွေးရန် မရပါ","Audio file picker unavailable");}
    }
    @Override public void onBackPressed(){
        storeReadingPosition();
        if(!readingId.isEmpty()){readingId="";show();}else if(page!=0){page=0;show();}else super.onBackPressed();
    }

    private void storeReadingPosition(){
        if(!readingId.isEmpty() && scroll!=null) {
            prefs.edit().putInt("read_y_"+readingId,Math.max(0,scroll.getScrollY())).apply();
        }
    }
    private void readLibrary(){
        try(InputStream in=getAssets().open("library.json");ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1)out.write(b,0,n);
            library=new JSONArray(out.toString("UTF-8"));
        }catch(Exception e){library=new JSONArray();}
    }
    private JSONObject getItem(String id){for(int i=0;i<library.length();i++){
        JSONObject x=library.optJSONObject(i);if(x!=null && id.equals(x.optString("id")))return x;}
        return null;}
    private String word(String my,String en){return burmese?my:en;}
    private String name(JSONObject o){return burmese?o.optString("titleMy"):o.optString("titleEn");}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
    private void palette(){
        if(dark){BACKGROUND=0xff162622;SURFACE=0xff20362e;TEXT=0xfff8f0db;SECONDARY=0xffc0cfbd;
            ACCENT=0xfff2d18c;DARK_GREEN=0xffa4dac0;BORDER=0xff416158;SAGE=0xff314c40;}
        else{BACKGROUND=0xfffbf8f1;SURFACE=0xffffffff;TEXT=0xff273b32;SECONDARY=0xff647c6c;
            ACCENT=0xffd39e51;DARK_GREEN=0xff205b4a;BORDER=0xffe8e5d8;SAGE=0xffedf4ea;}
    }
    private GradientDrawable shape(int color,int radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));return g;}
    private GradientDrawable bordered(int color,int radius){GradientDrawable g=shape(color,radius);g.setStroke(dp(1),BORDER);return g;}
    private GradientDrawable heroGradient(){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,
            new int[]{0xff265b50,0xff1e423b,0xff393947});g.setCornerRadius(dp(24));return g;}
    private LinearLayout vertical(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);return x;}
    private LinearLayout horizontal(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.HORIZONTAL);x.setGravity(Gravity.CENTER_VERTICAL);return x;}
    private void gap(LinearLayout parent,int d){View v=new View(this);parent.addView(v,new LinearLayout.LayoutParams(1,dp(d)));}
    private TextView text(String s,int sp,int color,boolean strong){TextView v=new TextView(this);
        v.setText(s);v.setTextSize(sp);v.setTextColor(color);v.setIncludeFontPadding(true);
        v.setLineSpacing(dp(3),1.07f);if(strong)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        return v;}
    private TextView button(String s,boolean primary){TextView t=text(s,14,primary?WHITE:DARK_GREEN,true);
        t.setGravity(Gravity.CENTER);t.setMinHeight(dp(48));t.setPadding(dp(15),dp(10),dp(15),dp(10));
        t.setBackground(bordered(primary?0xff276952:SAGE,14));return t;}
    private LinearLayout card(){LinearLayout x=vertical();x.setPadding(dp(17),dp(17),dp(17),dp(17));
        x.setBackground(bordered(SURFACE,21));content.addView(x,new LinearLayout.LayoutParams(-1,-2));gap(content,13);return x;}
    private void addText(LinearLayout p,String s,int sp,int color,boolean bold){p.addView(text(s,sp,color,bold));}
    private void columnButton(LinearLayout p,String label,Runnable run,boolean primary){TextView b=button(label,primary);p.addView(b);
        b.setOnClickListener(v->run.run());}
    private void titleRow(String title,String subtitle){addText(content,title,25,TEXT,true);gap(content,4);addText(content,subtitle,12,SECONDARY,false);gap(content,16);}
    private void toast(String my,String en){Toast.makeText(this,word(my,en),Toast.LENGTH_SHORT).show();}
    private void show(){
        chantSeek=null;chantClock=null;chantPlay=null;miniPlay=null;miniTitle=null;
        palette();getWindow().setStatusBarColor(dark?BACKGROUND:0xfff4f1e8);
        getWindow().setNavigationBarColor(dark?BACKGROUND:0xfffbf8f1);
        getWindow().getDecorView().setSystemUiVisibility(dark?0:(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR));
        root=vertical();root.setBackgroundColor(BACKGROUND);setContentView(root);
        root.setOnApplyWindowInsetsListener((v,insets)->{
            v.setPadding(0,insets.getSystemWindowInsetTop(),0,insets.getSystemWindowInsetBottom());return insets;
        });root.requestApplyInsets();
        LinearLayout top=horizontal();top.setPadding(dp(19),dp(10),dp(19),dp(10));
        ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.ic_metta);
        LinearLayout.LayoutParams iconParams=new LinearLayout.LayoutParams(dp(44),dp(44));
        iconParams.setMargins(0,0,dp(10),0);top.addView(logo,iconParams);
        TextView heading=text("  "+word("မင်္ဂလာမေတ္တာ","Mingalar Metta"),20,TEXT,true);
        top.addView(heading,new LinearLayout.LayoutParams(0,-2,1));
        TextView night=button(dark?"☀":"☾",false);
        night.setMinWidth(dp(48));night.setOnClickListener(v->{dark=!dark;prefs.edit().putBoolean("dark",dark).apply();show();});top.addView(night);
        root.addView(top);
        View divider=new View(this);divider.setBackgroundColor(BORDER);root.addView(divider,new LinearLayout.LayoutParams(-1,dp(1)));
        scroll=new ScrollView(this);scroll.setFillViewport(false);scroll.setVerticalScrollBarEnabled(false);
        content=vertical();content.setPadding(dp(17),dp(20),dp(17),dp(22));scroll.addView(content);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        if(!readingId.isEmpty())renderReader();
        else if(page==0)renderLibrary();
        else if(page==1)renderPractice();
        else if(page==2)renderFavorites();
        else if(page==4)renderAudioLibrary();
        else renderSettings();
        renderMiniPlayer();
        bottomNav();
        if(!readingId.isEmpty()){
            final int remembered=Math.max(0,prefs.getInt("read_y_"+readingId,0));
            scroll.post(()->{if(scroll!=null)scroll.scrollTo(0,remembered);});
        }
    }
    private void bottomNav(){
        LinearLayout nav=horizontal();nav.setPadding(dp(5),dp(7),dp(5),dp(10));nav.setBackgroundColor(SURFACE);
        int[] pages={0,4,1,2,3};
        String[] my={"▤\nစာဖတ်","♫\nအသံ","◉\nပုတီး","♡\nသိမ်း","⚙\nဆက်တင်"};
        String[] en={"▤\nRead","♫\nListen","◉\nBeads","♡\nSaved","⚙\nMore"};
        for(int i=0;i<pages.length;i++){
            final int idx=pages[i];
            TextView t=text((burmese?my:en)[i],11,idx==page?DARK_GREEN:SECONDARY,idx==page);
            t.setGravity(Gravity.CENTER);t.setMinHeight(dp(51));
            t.setBackground(shape(idx==page?SAGE:SURFACE,14));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);
            lp.setMargins(dp(2),0,dp(2),0);nav.addView(t,lp);
            t.setOnClickListener(v->{storeReadingPosition();page=idx;readingId="";hideKeyboard();show();});
        }
        root.addView(nav);
    }
    private void renderMiniPlayer(){
        if(chantPlayer==null || currentChant.isEmpty())return;
        LinearLayout bar=horizontal();bar.setPadding(dp(15),dp(9),dp(12),dp(10));
        bar.setBackgroundColor(dark?0xff244638:0xffe5f0e8);
        String title=activeAudioReading.isEmpty()?word("အသံဖိုင်","Now playing"):
            (getItem(activeAudioReading)==null?word("အသံဖိုင်","Now playing"):name(getItem(activeAudioReading)));
        miniTitle=text("♫  "+title,12,TEXT,true);bar.addView(miniTitle,new LinearLayout.LayoutParams(0,-2,1));
        miniPlay=button(chantPlayer.isPlaying()?"Ⅱ":"▶",false);
        miniPlay.setMinWidth(dp(48));bar.addView(miniPlay);
        miniPlay.setOnClickListener(v->{
            if(chantPlayer==null)return;
            if(chantPlayer.isPlaying())chantPlayer.pause();else chantPlayer.start();
            miniPlay.setText(chantPlayer.isPlaying()?"Ⅱ":"▶");
        });
        TextView close=button("×",false);close.setMinWidth(dp(48));bar.addView(close);
        close.setOnClickListener(v->{stopChant();show();});
        root.addView(bar);
    }
    private void hideKeyboard(){try{((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(root.getWindowToken(),0);}catch(Exception ignore){}}
    private void hero(){LinearLayout hero=vertical();hero.setPadding(dp(23),dp(24),dp(23),dp(24));hero.setBackground(heroGradient());
        addText(hero,"☸   "+word("ဓမ္မပန်းတိုင်","A quieter heart, a clearer path"),23,WHITE,true);gap(hero,8);
        addText(hero,word("ပါဠိကျမ်းစာအပြည့်၊ မြန်မာဘာသာ လေ့လာရေးမှတ်စု၊ ဓမ္မအသံနှင့် ပုတီးစိပ်ကိရိယာ — အင်တာနက်မလိုပါ။",
            "Complete Pāli scriptures, Burmese study notes, recorded chanting, and digital beads — all offline."),14,0xffe5e9dc,false);
        gap(hero,13);TextView p=button(word("🎧  အသံဖိုင်ဖြင့် သရဏဂုံနားထောင်ရန်","🎧  Listen to a recorded chant"),true);
        p.setBackground(shape(0xffcb9b53,14));p.setOnClickListener(v->openReading("refuge"));hero.addView(p);
        gap(hero,9);TextView beads=button(word("◉  ပုတီးစိပ်ရန်","◉  Open bead counter"),false);
        beads.setOnClickListener(v->{stopChant();page=1;show();});hero.addView(beads);
        content.addView(hero);gap(content,13);
        String last=prefs.getString("last_read","");
        JSONObject previous=getItem(last);
        if(previous!=null){
            LinearLayout cont=card();
            addText(cont,word("📖  ဆက်လက်ဖတ်ရှုရန်","📖  Continue where you stopped"),13,DARK_GREEN,true);
            gap(cont,7);
            columnButton(cont,name(previous),()->openReading(last),false);
        }
    }
    private String filter="All";
    private void renderLibrary(){
        hero();titleRow(word("ဓမ္မစာကြည့်တိုက်","Dhamma reading library"),
            word("မူရင်းပါဠိကျမ်းစာ + မြန်မာရှင်းလင်းချက် • " + library.length()+" ပုဒ်",
                library.length()+" offline readings • full canonical Pāli + Burmese study notes"));
        renderCategoryTiles();
        EditText search=new EditText(this);search.setSingleLine(true);search.setTextSize(16);search.setTextColor(TEXT);search.setHintTextColor(SECONDARY);
        search.setPadding(dp(14),dp(7),dp(14),dp(7));search.setHint(word("🔎  စာသားရှာရန်","🔎  Search readings"));
        search.setBackground(bordered(SURFACE,14));content.addView(search,new LinearLayout.LayoutParams(-1,dp(52)));gap(content,11);
        HorizontalScrollView categoryScroll=new HorizontalScrollView(this);
        categoryScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout categories=horizontal();String[] cats={"All","Canon","Chant","Life","Dhamma","Study","Practice"};
        for(String cat:cats){
            String label=cat.equals("All")?word("အားလုံး","All"):
                cat.equals("Canon")?word("ပါဠိကျမ်းစာအပြည့်","Full scriptures"):
                cat.equals("Life")?word("ဘုရားသမိုင်း","Buddha's Life"):
                cat.equals("Dhamma")?word("တရားအခြေခံ","Dhamma"):
                cat.equals("Chant")?word("ရွတ်ဖတ်","Chants"):
                cat.equals("Study")?word("သုတ်တော်လေ့လာ","Sutta guides"):word("လေ့ကျင့်","Practice");
            TextView chip=button(label,cat.equals(filter));
            chip.setTextSize(13);chip.setMinHeight(dp(45));chip.setPadding(dp(14),dp(6),dp(14),dp(6));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,-2);lp.setMargins(0,0,dp(8),0);categories.addView(chip,lp);
            chip.setOnClickListener(v->{filter=cat;renderList(listHost,search.getText().toString());
                for(int k=0;k<categories.getChildCount();k++)categories.getChildAt(k).setAlpha(0.7f);
                chip.setAlpha(1f);});}
        categoryScroll.addView(categories);
        content.addView(categoryScroll);gap(content,15);
        listHost=vertical();content.addView(listHost);
        renderList(listHost,"");
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            public void onTextChanged(CharSequence s,int start,int before,int count){renderList(listHost,s.toString());}
            public void afterTextChanged(Editable e){} });
    }
    private void renderCategoryTiles(){
        String[] keys={"Canon","Chant","Life","Dhamma","Study","Practice"};
        String[] my={"ပါဠိကျမ်းစာအပြည့်","ရွတ်ဖတ်ပူဇော်","ဗုဒ္ဓဝင်","တရားတော်","သုတ်တော်လေ့လာ","တရားထိုင်"};
        String[] en={"Complete Pāli texts","Daily chants","Buddha’s life","Teachings","Sutta guides","Meditation"};
        String[] symbols={"☸","♫","✦","◈","▤","◉"};
        LinearLayout grid=vertical();
        for(int r=0;r<3;r++){
            LinearLayout row=horizontal();
            for(int j=0;j<2;j++){
                int index=r*2+j;int cnt=0;
                for(int k=0;k<library.length();k++){
                    JSONObject item=library.optJSONObject(k);
                    if(item!=null && keys[index].equals(item.optString("category")))cnt++;
                }
                final String cat=keys[index];
                LinearLayout tile=vertical();tile.setPadding(dp(14),dp(12),dp(12),dp(12));
                tile.setBackground(bordered(SURFACE,18));
                addText(tile,symbols[index]+"  "+(burmese?my[index]:en[index]),14,DARK_GREEN,true);
                gap(tile,5);addText(tile,cnt+word(" ပုဒ်"," readings"),12,SECONDARY,false);
                LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(97),1);
                lp.setMargins(dp(3),0,dp(3),dp(7));row.addView(tile,lp);
                tile.setOnClickListener(v->{filter=cat;show();});
            }
            grid.addView(row);
        }
        content.addView(grid);gap(content,11);
    }
    private LinearLayout listHost;
    private void renderList(LinearLayout host,String query){
        if(host==null)return;host.removeAllViews();int shown=0;
        for(int i=0;i<library.length();i++){
            JSONObject obj=library.optJSONObject(i);if(obj==null)continue;
            if(!"All".equals(filter)&&!filter.equals(obj.optString("category")))continue;
            String hay=(obj.optString("titleMy")+" "+obj.optString("titleEn")+" "+obj.optString("explanationMy")+" "+obj.optString("detailsMy")+" "+obj.optString("detailsEn")+" "+obj.optString("pali")+" "+obj.optString("englishText")).toLowerCase(Locale.ROOT);
            if(!hay.contains(query.toLowerCase(Locale.ROOT).trim()))continue;
            final String id=obj.optString("id");
            LinearLayout c=vertical();c.setPadding(dp(15),dp(14),dp(15),dp(14));c.setBackground(bordered(SURFACE,16));
            LinearLayout row=horizontal();TextView title=text(name(obj),17,TEXT,true);row.addView(title,new LinearLayout.LayoutParams(0,-2,1));
            TextView star=button(favorites().contains(id)?"♥":"♡",false);star.setMinWidth(dp(48));star.setMinHeight(dp(48));
            star.setOnClickListener(v->{toggleFavorite(id);star.setText(favorites().contains(id)?"♥":"♡");});row.addView(star);c.addView(row);
            addText(c,(obj.optString("audio").isEmpty()?"":"🎧  ")+obj.optString("category")+"  •  "+
                (burmese?obj.optString("titleEn"):obj.optString("titleMy")),12,SECONDARY,false);
            if(!obj.optString("detailsMy").isEmpty()){
                String detail=burmese?obj.optString("detailsMy"):obj.optString("detailsEn");
                if(detail.length()>95)detail=detail.substring(0,95)+"…";
                gap(c,7);addText(c,detail,13,SECONDARY,false);
            }
            c.setOnClickListener(v->openReading(id));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,0,0,dp(11));host.addView(c,lp);shown++;
        }
        if(shown==0)host.addView(text(word("ဒီအမျိုးအစားတွင် စာသားမတွေ့ပါ","No matching readings found"),15,SECONDARY,false));
    }
    private Set<String> favorites(){return new HashSet<>(prefs.getStringSet("favorites",new HashSet<>()));}
    private void toggleFavorite(String id){Set<String> next=favorites();if(!next.add(id))next.remove(id);
        prefs.edit().putStringSet("favorites",next).apply();}
    private void openReading(String id){
        storeReadingPosition();
        readingId=id;prefs.edit().putString("last_read",id).apply();hideKeyboard();show();
    }
    private void renderReader(){JSONObject o=getItem(readingId);if(o==null){readingId="";renderLibrary();return;}
        TextView back=button(word("‹  စာရင်းသို့ပြန်ရန်","‹  Back to library"),false);
        back.setOnClickListener(v->{stopChant();readingId="";show();});content.addView(back);gap(content,15);
        titleRow(name(o),o.optString("titleEn")+" · "+o.optString("category"));
        boolean fullCanon="canonical".equals(o.optString("kind"));
        if(fullCanon){
            LinearLayout note=card();
            addText(note,word("☸  သုတ်တော် မူရင်းစာအပြည့် • ပါဠိ","☸  Complete canonical Pāli text"),15,DARK_GREEN,true);
            gap(note,6);addText(note,word("SuttaCentral ၏ မူရင်းပါဠိကျမ်းစာနှင့် CC0 အများပိုင် English ဘာသာပြန်ဖြစ်သည်။ မြန်မာဘာသာရှင်းလင်းချက်သည် အကျဉ်းချုပ်ဖြစ်သည်။",
                "Original Pāli + CC0 English from SuttaCentral. Burmese explanation is an introductory summary, not a complete translation."),12,SECONDARY,false);
        }
        String my=o.optString("myanmar"),pali=o.optString("pali");
        if(!my.isEmpty()){
            LinearLayout chant=card();addText(chant,word("ပါဠိအသံထွက် ဖတ်ရှုရန်","Burmese-script chant guide"),13,SECONDARY,true);gap(chant,11);
            addText(chant,my,fontSize+1,TEXT,false);gap(chant,8);
            addText(chant,word("စာသားနှင့်အသံထွက်ကို အတည်ပြုရန် ဆရာတော်နှင့် တိုင်ပင်ပါ။",
                "Ask a qualified teacher to verify the recitation."),11,SECONDARY,false);
        }
        if(!pali.isEmpty()){
            LinearLayout latin=card();addText(latin,fullCanon?word("ပါဠိကျမ်း မူရင်းအပြည့်","Complete Pāli scripture"):word("ပါဠိ ရောမအက္ခရာ","Pali · Roman script"),13,SECONDARY,true);gap(latin,9);
            addText(latin,pali,Math.max(16,fontSize-1),TEXT,false);
        }
        if(fullCanon && !o.optString("englishText").isEmpty()){
            LinearLayout translated=card();addText(translated,"EN  Public-domain English translation",14,DARK_GREEN,true);
            gap(translated,9);addText(translated,o.optString("englishText"),Math.max(15,fontSize-1),TEXT,false);
            gap(translated,10);addText(translated,"Bhikkhu Sujato · SuttaCentral · CC0",11,SECONDARY,false);
        }
        if(!o.optString("audio").isEmpty() || !prefs.getString("audio_uri_"+readingId,"").isEmpty())
            renderChantPlayer(o);
        LinearLayout explanation=card();addText(explanation,word("အသေးစိတ် ရှင်းလင်းချက်","Detailed explanation"),17,DARK_GREEN,true);gap(explanation,10);
        String detail=burmese?o.optString("detailsMy"):o.optString("detailsEn");
        if(detail.isEmpty())detail=burmese?o.optString("explanationMy"):o.optString("explanationEn");
        addText(explanation,detail,fontSize,TEXT,false);gap(explanation,10);
        String practice=burmese?o.optString("practiceMy"):o.optString("practiceEn");
        if(!practice.isEmpty()){
            LinearLayout practiceCard=card();addText(practiceCard,word("ယနေ့ လေ့ကျင့်ကြည့်ရန်","Try it today"),16,DARK_GREEN,true);
            gap(practiceCard,9);addText(practiceCard,practice,fontSize,TEXT,false);
        }
        TextView eng=button(word("EN  English meaning","မြန်မာ  Burmese meaning"),false);
        eng.setOnClickListener(v->{burmese=!burmese;prefs.edit().putBoolean("burmese",burmese).apply();show();});explanation.addView(eng);
        if(burmese){gap(explanation,8);TextView speak=button("▶  "+word("ရှင်းလင်းချက်ကို ဖုန်းအသံဖြင့်ဖတ်ရန်","Speak note (device voice)"),false);
            speak.setOnClickListener(v->speakBurmese(o.optString("explanationMy")));explanation.addView(speak);}
        LinearLayout actions=card();
        columnButton(actions,word("♫  ကိုယ်ပိုင် MP3/အသံဖိုင် ရွေးရန်","♫  Add my own audio file"),
            this::chooseAudioForReading,false);
        gap(actions,9);
        columnButton(actions,word("◉  ပုတီးစိပ်ရန် / 108","◉  Open digital 108-bead counter"),()->{
            storeReadingPosition();readingId="";page=1;show();},false);
        gap(actions,9);
        TextView fav=button(favorites().contains(readingId)?word("♥  သိမ်းထားပြီး","♥  Saved"):word("♡  သိမ်းထားရန်","♡  Save to favorites"),true);
        fav.setOnClickListener(v->{toggleFavorite(readingId);fav.setText(favorites().contains(readingId)?"♥  "+word("သိမ်းထားပြီး","Saved"):"♡  "+word("သိမ်းထားရန်","Save to favorites"));});actions.addView(fav);gap(actions,9);
        TextView share=button(word("↗  စာသားမျှဝေရန်","↗  Share reading"),false);
        share.setOnClickListener(v->{
            String excerpt=o.optString("pali");if(excerpt.isEmpty())excerpt=o.optString("detailsMy");
            if(excerpt.length()>2500)excerpt=excerpt.substring(0,2500)+"…";
            Intent intent=new Intent(Intent.ACTION_SEND);intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_TEXT,name(o)+"\n\n"+excerpt+"\n"+o.optString("source"));
            startActivity(Intent.createChooser(intent,word("မျှဝေရန်","Share")));
        });actions.addView(share);gap(actions,9);
        TextView reference=button(word("↗  မူရင်းကျမ်း အရင်းအမြစ်","↗  Canonical reference"),false);
        reference.setOnClickListener(v->{String u=o.optString("source","");
            if(u.startsWith("https://suttacentral.net/") || u.startsWith("https://www.vridhamma.org/"))
                startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(u)));
        });actions.addView(reference);
        gap(actions,10);addText(actions,word("မှတ်ချက် — ဗုဒ္ဓဝင်နှင့် တရားလေ့လာရေးစာများသည် ကျမ်းစာအပြည့် မဟုတ်ပါ။ ပါဠိစာသားတိုများကိုလည်း တတ်ကျွမ်းသော ဆရာတော်များနှင့် စစ်ဆေးပါ။",
            "Life and Dhamma guides are original explanations, not complete scripture texts. Short Pali verses need qualified review before wider publication."),12,SECONDARY,false);
    }
    private String formatDuration(int milliseconds){
        int seconds=Math.max(0,milliseconds/1000);
        return String.format(Locale.US,"%02d:%02d",seconds/60,seconds%60);
    }
    private void stopChant(){
        ui.removeCallbacks(chantProgress);
        chantSeek=null;chantClock=null;chantPlay=null;
        if(chantPlayer!=null){
            try{chantPlayer.stop();}catch(Exception ignored){}
            chantPlayer.release();chantPlayer=null;
        }
        currentChant="";
        activeAudioReading="";
    }
    private void startOrToggleChant(String audio){
        if(chantPlayer!=null && !currentChant.equals(audio))stopChant();
        try{
            if(chantPlayer==null){
                if(audio.startsWith("user:")){
                    String saved=prefs.getString("audio_uri_"+audio.substring(5),"");
                    if(saved.isEmpty()){toast("ကိုယ်ပိုင် အသံဖိုင် မရှိပါ","No personal recording selected");return;}
                    chantPlayer=MediaPlayer.create(this,Uri.parse(saved));
                } else {
                    int res=getResources().getIdentifier(audio,"raw",getPackageName());
                    if(res==0){toast("အသံဖိုင် မတွေ့ပါ","Recording unavailable in this build");return;}
                    chantPlayer=MediaPlayer.create(this,res);
                }
                if(chantPlayer==null){toast("အသံဖိုင် ဖွင့်မရပါ","Recording could not be opened");return;}
                currentChant=audio;
                activeAudioReading=audio.startsWith("user:")?audio.substring(5):"refuge";
                chantPlayer.setLooping(chantRepeat);
                chantPlayer.setOnCompletionListener(mp->{
                    if(chantPlay!=null)chantPlay.setText(word("▶  ပြန်ဖွင့်","▶  Play again"));
                });
            }
            if(chantPlayer.isPlaying())chantPlayer.pause();else chantPlayer.start();
            if(chantSeek!=null)chantSeek.setMax(chantPlayer.getDuration());
            if(miniPlay!=null)miniPlay.setText(chantPlayer.isPlaying()?"Ⅱ":"▶");
            ui.removeCallbacks(chantProgress);ui.post(chantProgress);
        }catch(Exception e){stopChant();toast("အသံဖိုင် ဖွင့်မရပါ","Cannot play the recording");}
    }
    private void renderChantPlayer(JSONObject o){
        final String imported=prefs.getString("audio_uri_"+readingId,"");
        final String audio=imported.isEmpty()?o.optString("audio"):"user:"+readingId;
        LinearLayout player=card();
        addText(player,"🎧  "+(imported.isEmpty()?(
            burmese?o.optString("audioLabelMy"):o.optString("audioLabelEn")):
            word("ကိုယ်ပိုင်အသံဖိုင်","My saved audio file")),17,DARK_GREEN,true);gap(player,8);
        addText(player,imported.isEmpty()?
            word("ဤသည် ဗုဒ္ဓဘာသာ သရဏဂုံသုံးပါးကို တေးသွားနှင့် ရွတ်ဆိုထားသော အသံဖိုင်ဖြစ်ပြီး မြန်မာဆရာတော်များ၏ ပရိတ်ရွတ်သံ မဟုတ်ပါ။ ဖုန်းတွင် အင်တာနက်မရှိဘဲ နားထောင်နိုင်သည်။",
                "A musical Three Refuges recording; not Burmese monastic chanting. Bundled for offline playback."):
            word("သင့်ဖုန်းမှ ရွေးထားသော အသံဖိုင်ကို ဖွင့်ပါသည်။ မူပိုင်ခွင့်နှင့် အသံထွက်ကို မိမိကိုယ်တိုင် စစ်ဆေးပါ။",
                "Plays a recording selected from your device. Check its pronunciation and rights before sharing."),13,SECONDARY,false);gap(player,13);
        chantPlay=button(word("▶  အသံဖိုင်ဖွင့်ရန်","▶  Play recording"),true);
        chantPlay.setOnClickListener(v->startOrToggleChant(audio));player.addView(chantPlay);gap(player,10);
        chantSeek=new SeekBar(this);chantSeek.setProgressTintList(ColorStateList.valueOf(DARK_GREEN));player.addView(chantSeek);
        chantClock=text("00:00 / 06:19",13,SECONDARY,false);chantClock.setGravity(Gravity.CENTER);player.addView(chantClock);
        chantSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onStartTrackingTouch(SeekBar bar){}
            public void onStopTrackingTouch(SeekBar bar){if(chantPlayer!=null)chantPlayer.seekTo(bar.getProgress());}
            public void onProgressChanged(SeekBar bar,int val,boolean user){}
        });
        if(chantPlayer!=null && currentChant.equals(audio)){
            chantSeek.setMax(chantPlayer.getDuration());chantSeek.setProgress(chantPlayer.getCurrentPosition());
            chantClock.setText(formatDuration(chantPlayer.getCurrentPosition())+" / "+formatDuration(chantPlayer.getDuration()));
            ui.removeCallbacks(chantProgress);ui.post(chantProgress);
        }
        LinearLayout controls=horizontal();
        TextView stop=button(word("■  ရပ်ရန်","■  Stop"),false);
        TextView repeat=button(chantRepeat?word("↻  ထပ်ဖွင့် • ON","↻  Repeat · ON"):word("↻  ထပ်ဖွင့် • OFF","↻  Repeat · OFF"),false);
        controls.addView(stop,new LinearLayout.LayoutParams(0,-2,1));controls.addView(repeat,new LinearLayout.LayoutParams(0,-2,1));player.addView(controls);
        stop.setOnClickListener(v->{stopChant();show();});
        repeat.setOnClickListener(v->{chantRepeat=!chantRepeat;
            if(chantPlayer!=null)chantPlayer.setLooping(chantRepeat);
            repeat.setText(chantRepeat?word("↻  ထပ်ဖွင့် • ON","↻  Repeat · ON"):word("↻  ထပ်ဖွင့် • OFF","↻  Repeat · OFF"));
        });gap(player,9);
        LinearLayout speeds=horizontal();
        addText(player,word("အသံအမြန်နှုန်း","Playback speed"),12,SECONDARY,true);gap(player,6);
        for(float multiplier:new float[]{0.75f,1.0f,1.25f}){
            TextView speed=button(String.format(Locale.US,"%.2f×",multiplier),false);
            speeds.addView(speed,new LinearLayout.LayoutParams(0,-2,1));
            speed.setOnClickListener(v->{
                if(chantPlayer==null){toast("အရင် အသံဖွင့်ပါ","Start playing audio first");return;}
                try{
                    PlaybackParams params=chantPlayer.getPlaybackParams();params.setSpeed(multiplier);
                    chantPlayer.setPlaybackParams(params);
                }catch(Exception e){toast("အသံနှုန်းပြောင်းမရပါ","Playback speed not supported");}
            });
        }
        player.addView(speeds);gap(player,9);
        if(!imported.isEmpty()){
            gap(player,9);
            columnButton(player,word("×  ကိုယ်ပိုင်အသံဖိုင် ဖယ်ရှားရန်","×  Remove my audio"),()->{
                prefs.edit().remove("audio_uri_"+readingId).apply();stopChant();show();},false);
        } else {
            addText(player,"Recorded by Hariharan (2013) • Wikimedia Commons • CC0 / public domain",11,SECONDARY,false);
        }
    }
    private void renderAudioLibrary(){
        titleRow(word("ဓမ္မရွတ်ဖတ် အသံဖိုင်များ","Chanting and audio library"),
            word("အော့ဖ်လိုင်း မူရင်းအသံ + ကိုယ်တိုင်ထည့်ထားသော အသံဖိုင်များ",
                "Offline credited recording and audio you add from your phone"));
        LinearLayout notice=card();
        addText(notice,word("နားထောင်ဖို့ အဆင်သင့်ပါ","Ready to listen"),19,DARK_GREEN,true);
        gap(notice,8);
        addText(notice,word("မူရင်းအသံတစ်ပုဒ်သာ ထည့်ထားပါသည်။ မူပိုင်ခွင့် ရရှိထားသည့် ပရိတ်ရွတ်ဖတ်အသံများကို ကိုယ့်ဖုန်းမှ ထပ်ထည့်နိုင်ပါသည်။",
            "One freely reusable recording is bundled. Attach additional chanting recordings that you have permission to use."),14,TEXT,false);
        gap(notice,9);
        columnButton(notice,word("🎧  သရဏဂုံသုံးပါး အသံနားထောင်ရန်","🎧  Play Three Refuges"),()->openReading("refuge"),true);
        gap(notice,10);
        addText(notice,"Hariharan (2013) • musical recording • CC0",11,SECONDARY,false);
        int additions=0;
        for(int i=0;i<library.length();i++){
            JSONObject o=library.optJSONObject(i);
            if(o==null || prefs.getString("audio_uri_"+o.optString("id"),"").isEmpty())continue;
            additions++;
            final String id=o.optString("id");
            LinearLayout c=card();addText(c,"♫  "+name(o),16,TEXT,true);gap(c,8);
            columnButton(c,word("နားထောင်ရန်","Open recording"),()->openReading(id),false);
        }
        LinearLayout info=card();
        addText(info,word("ကိုယ်ပိုင် အသံဖိုင် "+additions+" ပုဒ်","Your recordings: "+additions),14,DARK_GREEN,true);gap(info,8);
        addText(info,word("စာဖတ်ရန် စာရင်းမှ သုတ်တော်တစ်ပုဒ်ကို ရွေးပြီး ကိုယ်ပိုင် MP3 ရွေးရန် ကို နှိပ်ပါ။",
            "To add an MP3, open a reading and tap Add my own audio. Nothing is uploaded."),13,TEXT,false);
    }
    private void speakBurmese(String s){
        if(!ttsReady || tts==null){toast("အသံဖတ်စနစ် မရရှိသေးပါ","Device speech engine unavailable");return;}
        Voice offline=null;
        try{for(Voice v:tts.getVoices()){
            String lang=v.getLocale()==null?"":v.getLocale().getLanguage();
            if("my".equals(lang)&&!v.isNetworkConnectionRequired()){offline=v;break;}
        }}catch(Exception ignored){}
        if(offline==null){toast("ဖုန်းတွင် အော့ဖ်လိုင်း မြန်မာအသံမရှိပါ","No offline Burmese voice installed");return;}
        tts.setVoice(offline);tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"note");
    }
    private void renderFavorites(){titleRow(word("သိမ်းထားသောစာများ","Saved readings"),word("မိမိဖုန်းထဲတွင်သာ သိမ်းထားသည်","Stored only on this phone"));
        String last=prefs.getString("last_read","");if(!last.isEmpty() && getItem(last)!=null){LinearLayout lastCard=card();
            addText(lastCard,word("နောက်ဆုံးဖတ်ခဲ့သည်","Continue reading"),13,SECONDARY,false);gap(lastCard,7);
            columnButton(lastCard,name(getItem(last)),()->openReading(last),false);}
        Set<String> favs=favorites();if(favs.isEmpty()){
            LinearLayout c=card();addText(c,word("♡  ကြိုက်နှစ်သက်သောစာများကို နှလုံးသားပုံနှိပ်၍ သိမ်းနိုင်သည်။","♡  Tap the heart beside a reading to save it."),15,TEXT,false);
            return;}
        for(int i=0;i<library.length();i++){JSONObject o=library.optJSONObject(i);if(o==null || !favs.contains(o.optString("id")))continue;
            final String id=o.optString("id");LinearLayout c=card();addText(c,name(o),17,TEXT,true);gap(c,9);
            columnButton(c,word("ဖတ်ရှုရန်","Open reading"),()->openReading(id),true);}
    }
    private int goal(){return "buddhist".equals(mode)?buddhistGoal:tasbeehGoal;}
    private String countKey(){return "count_"+mode;}
    private int count(){return prefs.getInt(countKey(),0);}
    private void setCount(int n){prefs.edit().putInt(countKey(),Math.max(0,n)).apply();updateCounter();}
    private void updateCounter(){int c=count(),g=goal();if(countLabel!=null)countLabel.setText(String.valueOf(c));
        if(roundsLabel!=null)roundsLabel.setText(word("ပြီးဆုံးခဲ့သည့် အကြိမ်ရေ","Completed rounds")+": "+(c/g)+"    •    "+(c%g)+" / "+g);
        if(progress!=null){progress.setMax(g);progress.setProgress(c%g);}}
    private void renderPractice(){
        titleRow(word("နေ့စဉ် လေ့ကျင့်ခြင်း","Daily practice"),word("ရေတွက်ခြင်း၊ တရားထိုင်ခြင်းနှင့် ငြိမ်းချမ်းစိတ်","Beads, mindful breathing and gentle reflection"));
        LinearLayout c=card();addText(c,word("ပုတီးစိပ် / Tasbeeh","Prayer beads / Tasbeeh"),17,DARK_GREEN,true);gap(c,12);
        LinearLayout choose=horizontal();String[] names={word("◉  ဗုဒ္ဓဘာသာ","◉  Buddhist"),"☾  Tasbeeh"};
        for(int i=0;i<2;i++){final String m=i==0?"buddhist":"tasbeeh";
            TextView b=button(names[i],m.equals(mode));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.setMargins(dp(2),0,dp(2),0);choose.addView(b,lp);
            b.setOnClickListener(v->{mode=m;prefs.edit().putString("counter_mode",mode).apply();show();});}
        c.addView(choose);gap(c,13);
        addText(c,mode.equals("buddhist")?word("ပုတီးစိပ် ရေတွက်ကိရိယာ","Buddhist recitation counter"):
            word("သီးခြား Tasbeeh ရေတွက်ကိရိယာ","Separate Tasbeeh counter"),13,SECONDARY,false);gap(c,10);
        LinearLayout presets=horizontal();int[] goals=mode.equals("buddhist")?new int[]{27,54,108}:new int[]{33,99};
        for(int g:goals){TextView b=button(String.valueOf(g),g==goal());LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.setMargins(dp(4),0,dp(4),0);presets.addView(b,lp);
            b.setOnClickListener(v->{if(mode.equals("buddhist")){buddhistGoal=g;prefs.edit().putInt("goal_buddhist",g).apply();}
                else{tasbeehGoal=g;prefs.edit().putInt("goal_tasbeeh",g).apply();}show();});}
        c.addView(presets);gap(c,19);
        countLabel=text("0",64,TEXT,true);countLabel.setGravity(Gravity.CENTER);c.addView(countLabel);
        roundsLabel=text("",13,SECONDARY,false);roundsLabel.setGravity(Gravity.CENTER);c.addView(roundsLabel);gap(c,8);
        progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        progress.setProgressTintList(ColorStateList.valueOf(ACCENT));progress.setProgressBackgroundTintList(ColorStateList.valueOf(SAGE));
        c.addView(progress,new LinearLayout.LayoutParams(-1,dp(10)));gap(c,17);
        TextView tap=text(word("+   ပုတီးတစ်လုံး ရေတွက်ရန်","+   Tap to count one bead"),22,WHITE,true);
        tap.setGravity(Gravity.CENTER);tap.setMinHeight(dp(114));tap.setBackground(shape(0xff296a55,58));
        tap.setOnClickListener(v->{int previous=count();setCount(previous+1);v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
            if((previous+1)%goal()==0)playGong();});c.addView(tap);gap(c,14);
        LinearLayout edit=horizontal();TextView undo=button(word("↶  ပြန်နုတ်","↶  Undo"),false),reset=button(word("⟲  ပြန်စ","⟲  Reset"),false);
        LinearLayout.LayoutParams lp1=new LinearLayout.LayoutParams(0,-2,1);lp1.setMargins(0,0,dp(6),0);
        LinearLayout.LayoutParams lp2=new LinearLayout.LayoutParams(0,-2,1);lp2.setMargins(dp(6),0,0,0);
        edit.addView(undo,lp1);edit.addView(reset,lp2);c.addView(edit);
        undo.setOnClickListener(v->setCount(count()-1));reset.setOnClickListener(v->new AlertDialog.Builder(this)
            .setTitle(word("ရေတွက်ခြင်း ပြန်စမည်လား","Reset the count?"))
            .setMessage(word("လက်ရှိရေတွက်ထားသော အရေအတွက် ပျက်မည်။","Your count for this mode will be cleared."))
            .setNegativeButton(word("မလုပ်ပါ","Cancel"),null)
            .setPositiveButton(word("ပြန်စ","Reset"),(a,b)->setCount(0)).show());
        updateCounter();
        if(mode.equals("tasbeeh")){LinearLayout note=card();addText(note,word("ဤ Tasbeeh သည် ဗုဒ္ဓဘာသာ ပုတီးစိပ်ခြင်းနှင့် သီးခြား ဖြစ်ပါသည်။ လေ့ကျင့်မှုနှစ်မျိုး၏ ရေတွက်ချက်များ မရောပါ။",
            "Tasbeeh is a separate Islamic practice. Its counts are not mixed with Buddhist bead counts."),13,TEXT,false);}
        LinearLayout meditate=card();addText(meditate,word("သတိဖြင့် အသက်ရှူခြင်း","Mindful breathing timer"),18,DARK_GREEN,true);gap(meditate,9);
        addText(meditate,word("တိတ်ဆိတ်စွာ လေ့ကျင့်ပါ။ ခဏတည်းခိုသည့် အသံက မိမိအက်ပ်တွင် ဖန်တီးထားသည့် အသံဖြစ်သည်။",
            "Quiet practice with an original, locally generated completion chime."),13,SECONDARY,false);gap(meditate,12);
        LinearLayout duration=horizontal();for(int secs:new int[]{5*60,10*60,15*60}){
            TextView b=button((secs/60)+" min",!timerRunning && timerSeconds==secs);
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.setMargins(dp(3),0,dp(3),0);duration.addView(b,lp);
            b.setOnClickListener(v->{timerRunning=false;ui.removeCallbacks(ticker);timerSeconds=secs;show();});}
        meditate.addView(duration);gap(meditate,14);
        timerLabel=text(timerRunning?clock((int)Math.max(0,(timerEnd-SystemClock.elapsedRealtime()+999)/1000)):clock(timerSeconds),35,TEXT,true);
        timerLabel.setGravity(Gravity.CENTER);meditate.addView(timerLabel);gap(meditate,11);
        columnButton(meditate,timerRunning?word("■  ရပ်ရန်","■  Stop timer"):word("▶  စတင်ရန်","▶  Start timer"),()->{
            if(timerRunning){timerRunning=false;ui.removeCallbacks(ticker);show();return;}
            timerRunning=true;timerEnd=SystemClock.elapsedRealtime()+timerSeconds*1000L;
            ui.removeCallbacks(ticker);ui.post(ticker);show();},true);
        LinearLayout reflection=card();addText(reflection,word("နေ့စဉ် မေတ္တာဆင်ခြင်ခြင်း","Daily reflection"),17,DARK_GREEN,true);gap(reflection,8);
        addText(reflection,word("ယနေ့တွင် မိမိကိုယ်ကိုနှင့် အခြားသူများကို မေတ္တာထားပြီး စိတ်ကြည်လင်စွာ နေထိုင်နိုင်ပါစေ။",
            "May I approach myself and others today with kindness and clarity."),15,TEXT,false);
    }
    private void playGong(){try {MediaPlayer mp=MediaPlayer.create(this,R.raw.gong);
        if(mp!=null){mp.setOnCompletionListener(MediaPlayer::release);mp.start();}}
        catch(Exception ignored) {}}
    private String clock(int seconds){return String.format(Locale.US,"%02d:%02d",seconds/60,seconds%60);}
    private void renderSettings(){titleRow(word("ဖတ်ရှုမှုဆိုင်ရာ ဆက်တင်များ","Reading settings"),word("အင်တာနက်မလို • အကောင့်မလို • ကြော်ငြာမရှိ","Offline • No account • No ads"));
        LinearLayout c=card();addText(c,word("ဘာသာစကား","Language"),16,TEXT,true);gap(c,10);
        columnButton(c,burmese?"မြန်မာ → English":"English → မြန်မာ",()->{burmese=!burmese;prefs.edit().putBoolean("burmese",burmese).apply();show();},false);
        gap(c,16);addText(c,word("စာလုံးအရွယ်အစား","Reader text size"),16,TEXT,true);gap(c,12);
        LinearLayout row=horizontal();TextView less=button("A−",false),bigger=button("A+",false);
        TextView current=text(String.valueOf(fontSize)+" sp",17,TEXT,true);current.setGravity(Gravity.CENTER);
        row.addView(less,new LinearLayout.LayoutParams(0,-2,1));row.addView(current,new LinearLayout.LayoutParams(0,-2,1));row.addView(bigger,new LinearLayout.LayoutParams(0,-2,1));c.addView(row);
        less.setOnClickListener(v->{fontSize=Math.max(16,fontSize-2);prefs.edit().putInt("font",fontSize).apply();current.setText(fontSize+" sp");});
        bigger.setOnClickListener(v->{fontSize=Math.min(30,fontSize+2);prefs.edit().putInt("font",fontSize).apply();current.setText(fontSize+" sp");});
        LinearLayout about=card();addText(about,word("အကြောင်း","About this app"),18,DARK_GREEN,true);gap(about,9);
        addText(about,word("ဤအက်ပ်သည် Dhamma Payeik ၏ အသုံးဝင်သော အကြံအဉာဏ်များကို အခြေခံစဉ်းစားထားသော်လည်း ကိုယ်ပိုင်ဒီဇိုင်းနှင့် အသစ်ရေးသားထားသော ရှင်းလင်းချက်များ ပါဝင်ပါသည်။ မူရင်းအက်ပ်၏ အသံဖိုင်နှင့် စာသားများကို မကူးယူထားပါ။",
            "An independent app informed by general features of Dhamma Payeik. No recordings, artwork or text from that app are copied."),13,TEXT,false);gap(about,9);
        addText(about,word("ဗုဒ္ဓဝင်၊ တရားလေ့လာရေး ၇၂ ခေါင်းစဉ်နှင့် SuttaCentral မှ မူရင်းပါဠိကျမ်းစာအပြည့် ၁၅ ပုဒ် ပါရှိသည်။ English translation သည် Bhikkhu Sujato ၏ CC0 စာသားများဖြစ်သည်။ သရဏဂုံသံစဉ်ကို Hariharan (2013) မှ CC0 ခွင့်ပြုထားသည်။",
            "72 original study topics plus 15 complete Pāli canonical works and CC0 English translations by Bhikkhu Sujato via SuttaCentral. The musical Three Refuges recording is CC0 by Hariharan (2013). This is not a full Burmese paritta collection."),13,SECONDARY,false);
        gap(about,10);columnButton(about,"↗  SuttaCentral (source texts)",()->startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://suttacentral.net"))),false);
        LinearLayout privacy=card();addText(privacy,word("ကိုယ်ရေးလုံခြုံမှု","Privacy"),17,DARK_GREEN,true);gap(privacy,8);
        addText(privacy,word("ပုတီးရေတွက်ချက်၊ ကြိုက်နှစ်သက်သောစာများနှင့် ရွေးချယ်မှုများကို မိမိဖုန်းထဲတွင်သာ သိမ်းထားပါသည်။ အကောင့်၊ တည်နေရာ၊ ခေါ်ဆိုမှုမှတ်တမ်းနှင့် အင်တာနက်ခွင့်ပြုချက် မလိုပါ။",
            "Counts, favorites and settings stay on your device. No analytics, login, location, call logs or network permission."),13,TEXT,false);
    }
}
