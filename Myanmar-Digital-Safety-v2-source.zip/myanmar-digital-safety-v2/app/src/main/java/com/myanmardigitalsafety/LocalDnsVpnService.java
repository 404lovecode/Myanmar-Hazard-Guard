package com.myanmardigitalsafety;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.VpnService;
import android.os.Build;
import android.os.ParcelFileDescriptor;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.net.ssl.HttpsURLConnection;

/**
 * DNS-only local VPN with a transparent offline ad-domain list and encrypted DoH.
 * Routes 10.67.0.2/32 only; does not intercept browsing, SMS, or call content.
 * Cloudflare receives domain lookups; this is disclosed before VPN consent.
 */
public final class LocalDnsVpnService extends VpnService {
    public static final String ACTION_STOP="com.myanmardigitalsafety.STOP_AD_SHIELD";
    private static final String CHANNEL="myanmar_safety_adshield";
    private static final int NOTIFY_ID=2401;
    private static final String DOH="https://cloudflare-dns.com/dns-query";
    private final ExecutorService pool=Executors.newFixedThreadPool(4);
    private final Object writeLock=new Object();
    private ParcelFileDescriptor tunnel;
    private volatile boolean running;
    private FileOutputStream output;

    private SharedPreferences prefs(){return getSharedPreferences(PhoneBlockRules.PREFS,MODE_PRIVATE);}

    @Override public int onStartCommand(Intent intent,int flags,int startId) {
        if(intent!=null && ACTION_STOP.equals(intent.getAction())){
            shutdown();stopSelf();return START_NOT_STICKY;
        }
        if(running)return START_STICKY;
        startAsForeground();
        try {
            Builder b=new Builder()
                .setSession("Myanmar Digital Safety · DNS Ad Shield")
                .addAddress("10.67.0.1",32)
                .addRoute("10.67.0.2",32)
                .addDnsServer("10.67.0.2")
                .setMtu(1500);
            tunnel=b.establish();
            if(tunnel==null)throw new IllegalStateException("VPN permission not granted");
            output=new FileOutputStream(tunnel.getFileDescriptor());
            running=true;
            prefs().edit().putBoolean("ad_shield_running",true).apply();
            new Thread(this::readLoop,"AdShield-DNS-TUN").start();
            return START_STICKY;
        } catch(Exception e) {
            prefs().edit().putBoolean("ad_shield_running",false)
                .putString("ad_shield_error","Could not start DNS shield").apply();
            shutdown();stopSelf();return START_NOT_STICKY;
        }
    }
    private void startAsForeground(){
        NotificationManager manager=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel channel=new NotificationChannel(CHANNEL,"DNS ad protection",NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Shown while local DNS ad protection is active");
            manager.createNotificationChannel(channel);
        }
        Notification.Builder builder=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);
        PendingIntent tap=PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),
            PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        builder.setSmallIcon(R.drawable.ic_shield)
            .setContentTitle("Myanmar Digital Safety · Ad Shield")
            .setContentText("DNS-only protection active · Open the app to stop")
            .setOngoing(true).setContentIntent(tap)
            .setCategory(Notification.CATEGORY_SERVICE);
        startForeground(NOTIFY_ID,builder.build());
    }
    private void readLoop(){
        if(tunnel==null)return;
        try(FileInputStream input=new FileInputStream(tunnel.getFileDescriptor())){
            byte[] packet=new byte[32767];int n;
            while(running && (n=input.read(packet))>0){
                DnsPackets.Question q=DnsPackets.parse(packet,n);
                if(q==null)continue;
                if(AdDomainRules.shouldBlock(q.host,prefs().getString("ad_allowed_domains",""))){
                    send(q,DnsPackets.blockedDns(q));
                    SharedPreferences p=prefs();
                    p.edit().putInt("ad_block_count",p.getInt("ad_block_count",0)+1).apply();
                }else{
                    pool.execute(()->{
                        byte[] reply=resolveOverHttps(q.wire);
                        if(reply==null)reply=DnsPackets.failDns(q);
                        send(q,reply);
                    });
                }
            }
        }catch(Exception ignored){}finally{shutdown();stopSelf();}
    }
    private Network findPhysicalNetwork(){
        ConnectivityManager cm=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
        if(cm==null)return null;
        Network candidate=null;
        for(Network n:cm.getAllNetworks()){
            NetworkCapabilities cap=cm.getNetworkCapabilities(n);
            if(cap==null||cap.hasTransport(NetworkCapabilities.TRANSPORT_VPN)||
                !cap.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET))continue;
            if(cap.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED))return n;
            candidate=n;
        }
        return candidate;
    }
    private byte[] resolveOverHttps(byte[] dns){
        Network physical=findPhysicalNetwork();
        if(physical==null)return null;
        HttpsURLConnection con=null;
        try {
            con=(HttpsURLConnection)physical.openConnection(new URL(DOH));
            con.setConnectTimeout(5000);con.setReadTimeout(5000);
            con.setRequestMethod("POST");con.setDoOutput(true);
            con.setInstanceFollowRedirects(false);
            con.setRequestProperty("Content-Type","application/dns-message");
            con.setRequestProperty("Accept","application/dns-message");
            con.setFixedLengthStreamingMode(dns.length);
            try(OutputStream out=con.getOutputStream()){out.write(dns);}
            if(con.getResponseCode()!=200)return null;
            try(InputStream in=con.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){
                byte[] b=new byte[1500];int n;
                while((n=in.read(b))!=-1){out.write(b,0,n);if(out.size()>3900)return null;}
                return out.toByteArray();
            }
        }catch(Exception ignored){return null;}
        finally{if(con!=null)con.disconnect();}
    }
    private void send(DnsPackets.Question q,byte[] dns){
        byte[] ip=DnsPackets.reply(q,dns);
        if(ip==null||!running)return;
        synchronized(writeLock){try{if(output!=null)output.write(ip);}catch(Exception ignored){}}
    }
    private synchronized void shutdown(){
        running=false;
        prefs().edit().putBoolean("ad_shield_running",false).apply();
        try{if(tunnel!=null)tunnel.close();}catch(Exception ignored){}
        tunnel=null;output=null;pool.shutdownNow();stopForeground(true);
    }
    @Override public void onRevoke(){shutdown();stopSelf();super.onRevoke();}
    @Override public void onDestroy(){shutdown();super.onDestroy();}
}
