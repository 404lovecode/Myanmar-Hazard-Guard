package com.myanmardigitalsafety;

import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.telecom.Call;
import android.telecom.CallScreeningService;

/** User-approved Android 10+ call screening. Local list and optional unknown blocking only. */
public final class ScamCallScreeningService extends CallScreeningService {
    @Override public void onScreenCall(Call.Details callDetails) {
        if(Build.VERSION.SDK_INT >= 29 && callDetails.getCallDirection()!=Call.Details.DIRECTION_INCOMING) return;
        Uri handle=callDetails.getHandle();
        String incoming=handle==null?"":handle.getSchemeSpecificPart();
        SharedPreferences p=getSharedPreferences(PhoneBlockRules.PREFS,MODE_PRIVATE);
        boolean block=PhoneBlockRules.shouldBlock(incoming,
            p.getString(PhoneBlockRules.BLOCKED,""),
            p.getString(PhoneBlockRules.TRUSTED,""),
            p.getBoolean("block_unknown_callers",false));
        CallResponse.Builder response=new CallResponse.Builder();
        if(block){
            response.setDisallowCall(true).setRejectCall(true)
                .setSkipCallLog(false).setSkipNotification(true);
            p.edit().putInt("blocked_call_count",p.getInt("blocked_call_count",0)+1).apply();
        }
        respondToCall(callDetails,response.build());
    }
}
