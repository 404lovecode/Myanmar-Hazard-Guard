package com.myanmardigitalsafety;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Locale;

/** Small IPv4/UDP DNS wire helper for a DNS-ONLY local VPN. Never handles arbitrary browsing data. */
public final class DnsPackets {
    private DnsPackets() {}
    public static final class Question {
        public final String host;
        public final byte[] wire;
        public final byte[] sourceIp, destIp;
        public final int sourcePort;
        public final int questionEnd;
        Question(String h,byte[] w,byte[] ipPacket,int src,int end) {
            host=h; wire=w; sourcePort=src; questionEnd=end;
            sourceIp=Arrays.copyOfRange(ipPacket,12,16);destIp=Arrays.copyOfRange(ipPacket,16,20);
        }
    }
    private static int u16(byte[] a,int p){return ((a[p]&255)<<8)|(a[p+1]&255);}
    private static void put16(byte[] a,int p,int v){a[p]=(byte)(v>>>8);a[p+1]=(byte)v;}
    private static long sum(byte[] a,int start,int end,long sum){
        for(int i=start;i+1<end;i+=2)sum+=u16(a,i);
        if(((end-start)&1)!=0)sum+=(a[end-1]&255)<<8;
        return sum;
    }
    private static int checksum(long sum){
        while((sum>>>16)!=0)sum=(sum&65535)+(sum>>>16);
        return (int)(~sum)&65535;
    }
    public static Question parse(byte[] packet,int size) {
        if(packet==null||size<40||size>packet.length||(packet[0]>>>4)!=4)return null;
        int ihl=(packet[0]&15)*4;
        if(ihl<20 || ihl+20>size || (packet[9]&255)!=17)return null;
        if((u16(packet,6)&0x3fff)!=0)return null; // reject fragments
        int ipLength=u16(packet,2);
        if(ipLength>size || ipLength<ihl+20)return null;
        int udp=ihl;
        int len=u16(packet,udp+4);
        if(u16(packet,udp+2)!=53||len<20||udp+len>ipLength)return null;
        int dns=udp+8;
        if((packet[dns+2]&0x80)!=0 || u16(packet,dns+4)!=1)return null;
        int p=dns+12,end=udp+len;
        StringBuilder host=new StringBuilder();
        for(int labels=0;labels<50;labels++) {
            if(p>=end)return null;
            int n=packet[p++]&255;
            if(n==0)break;
            if(n>63 || (n&0xc0)!=0 || p+n>end)return null;
            if(host.length()>0)host.append('.');
            String label=new String(packet,p,n,StandardCharsets.US_ASCII).toLowerCase(Locale.ROOT);
            host.append(label);p+=n;
            if(host.length()>253)return null;
        }
        if(p+4>end || host.length()==0)return null;
        int qtype=u16(packet,p),qclass=u16(packet,p+2);
        if(qclass!=1 || (qtype!=1 && qtype!=28 && qtype!=5 && qtype!=65))return null;
        int srcPort=u16(packet,udp);
        byte[] d=Arrays.copyOfRange(packet,dns,end);
        int questionEnd=p+4-dns;
        return new Question(host.toString(),d,packet,srcPort,questionEnd);
    }
    public static byte[] blockedDns(Question q){return errorDns(q,3);}
    public static byte[] failDns(Question q){return errorDns(q,2);}
    private static byte[] errorDns(Question q,int code) {
        byte[] d=Arrays.copyOf(q.wire,q.questionEnd);
        put16(d,2,0x8180|code); // standard response, recursion available, preserve question
        put16(d,4,1);put16(d,6,0);put16(d,8,0);put16(d,10,0);
        return d;
    }
    public static byte[] reply(Question q,byte[] dns) {
        if(q==null||dns==null||dns.length<12||dns.length>4000)return null;
        if(dns[0]!=q.wire[0]||dns[1]!=q.wire[1])return null; // only reply to same query
        int total=20+8+dns.length;
        byte[] ip=new byte[total];ip[0]=0x45;ip[1]=0;
        put16(ip,2,total);put16(ip,4,0);put16(ip,6,0);ip[8]=64;ip[9]=17;
        System.arraycopy(q.destIp,0,ip,12,4);System.arraycopy(q.sourceIp,0,ip,16,4);
        put16(ip,10,checksum(sum(ip,0,20,0)));
        put16(ip,20,53);put16(ip,22,q.sourcePort);put16(ip,24,8+dns.length);
        System.arraycopy(dns,0,ip,28,dns.length);
        long pseudo=0;
        pseudo=sum(ip,12,20,pseudo);pseudo+=17+(8+dns.length);
        pseudo=sum(ip,20,ip.length,pseudo);
        int check=checksum(pseudo);put16(ip,26,check==0?0xffff:check);
        return ip;
    }
}
