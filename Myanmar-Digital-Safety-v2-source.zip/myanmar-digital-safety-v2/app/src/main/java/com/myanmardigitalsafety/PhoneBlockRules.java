package com.myanmardigitalsafety;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;

/** Offline, privacy-preserving local call rules. Never queries a remote reputation service. */
public final class PhoneBlockRules {
    private PhoneBlockRules() {}
    public static final String PREFS = "myanmar_digital_safety_v1";
    public static final String BLOCKED = "call_blocked_numbers";
    public static final String TRUSTED = "call_trusted_numbers";

    public static String normalize(String value) {
        if (value == null) return "";
        value = value.trim();
        StringBuilder digits = new StringBuilder();
        for (int i=0;i<value.length();i++) {
            char c=value.charAt(i);
            if (c>='0' && c<='9') digits.append(c);
            else if (c=='+' && digits.length()==0 && value.indexOf('+')==i) digits.append('+');
            else if (c==' ' || c=='-' || c=='(' || c==')' || c=='.') continue;
            else return "";
        }
        int digitCount=digits.length()-(digits.length()>0 && digits.charAt(0)=='+' ? 1:0);
        if (digitCount < 7 || digitCount > 15) return "";
        if (digits.charAt(0)!='+' && digits.charAt(0)!='0') {
            // Domestic numbers can be accepted as entered, but don't guess a country code.
        }
        return digits.toString();
    }
    public static List<String> list(String raw) {
        LinkedHashSet<String> values=new LinkedHashSet<>();
        if (raw != null) for(String line:raw.split("\\n")) {
            String item=normalize(line);
            if (!item.isEmpty()) values.add(item);
        }
        return new ArrayList<>(values);
    }
    public static String add(String raw, String number) {
        String clean=normalize(number);
        if(clean.isEmpty())return raw==null?"":raw;
        LinkedHashSet<String> vals=new LinkedHashSet<>(list(raw)); vals.add(clean);
        return String.join("\n", vals);
    }
    public static String remove(String raw,String number) {
        String clean=normalize(number);
        LinkedHashSet<String> vals=new LinkedHashSet<>(list(raw)); vals.remove(clean);
        return String.join("\n", vals);
    }
    public static boolean contains(String raw,String number) {
        String clean=normalize(number);
        return !clean.isEmpty() && list(raw).contains(clean);
    }
    public static boolean shouldBlock(String incoming,String blocked,String trusted,boolean blockUnknown) {
        String clean=normalize(incoming);
        if(clean.isEmpty())return false; // Never blindly reject withheld/unreadable/service numbers.
        if(contains(trusted,clean))return false;
        if(contains(blocked,clean))return true;
        // Only called on numbers delivered by Android's call-screening role;
        // without READ_CONTACTS that usually excludes saved contacts.
        return blockUnknown;
    }
}
