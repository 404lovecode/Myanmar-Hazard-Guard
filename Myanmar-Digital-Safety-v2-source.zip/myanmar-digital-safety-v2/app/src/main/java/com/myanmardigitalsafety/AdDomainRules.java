package com.myanmardigitalsafety;

import java.util.Locale;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/** Small, transparent offline DNS ad/tracker list, not a remote surveillance feed. */
public final class AdDomainRules {
    private AdDomainRules() {}
    private static final Set<String> DOMAINS = new HashSet<>(Arrays.asList(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "adservice.google.com", "adservice.google.co.th", "adnxs.com", "adsrvr.org",
        "pubmatic.com", "rubiconproject.com", "openx.net", "criteo.com",
        "criteo.net", "taboola.com", "outbrain.com", "unityads.unity3d.com",
        "applovin.com", "chartboost.com", "inmobi.com", "admob.com",
        "advertising.com", "casalemedia.com", "smartadserver.com", "moatads.com",
        "scorecardresearch.com", "smaato.net", "smaato.com", "media.net",
        "ads.facebook.com", "adcolony.com", "bidr.io", "bidswitch.net",
        "lijit.com", "quantserve.com", "yieldmo.com", "adsafeprotected.com"
    ));
    public static String normalize(String raw) {
        if(raw==null)return "";
        String d=raw.trim().toLowerCase(Locale.ROOT);
        while(d.endsWith(".")) d=d.substring(0,d.length()-1);
        if(d.length()<3 || d.length()>253 || d.contains("..") || d.startsWith(".") || d.startsWith("-"))return "";
        for(char c:d.toCharArray()) if(!((c>='a'&&c<='z') || (c>='0'&&c<='9') || c=='.' || c=='-'))return "";
        return d;
    }
    public static boolean matches(String host,String base) {
        return host.equals(base)||host.endsWith("."+base);
    }
    public static boolean shouldBlock(String host, String userAllowed) {
        String d=normalize(host);
        if(d.isEmpty())return false;
        if(userAllowed!=null)for(String a:userAllowed.split("\\n")) {
            String allow=normalize(a);
            if(!allow.isEmpty() && matches(d,allow))return false;
        }
        for(String ad:DOMAINS)if(matches(d,ad))return true;
        return false;
    }
    public static String addAllow(String old,String host) {
        String clean=normalize(host);
        if(clean.isEmpty())return old==null?"":old;
        String current=old==null?"":old;
        for(String s:current.split("\\n"))if(clean.equals(normalize(s)))return current;
        return current.isEmpty()?clean:current+"\n"+clean;
    }
}
