package com.myanmardigitalsafety;

/** Offline, bilingual educational material. No personal messages or real accounts are processed. */
public final class LearnData {
    private LearnData() {}
    public static class Lesson {
        public final String icon, categoryMy, categoryEn, titleMy, titleEn, summaryMy, summaryEn;
        public final String exampleMy, exampleEn;
        public final String[] redMy, redEn, safeMy, safeEn;
        public Lesson(String icon,String catMy,String catEn,String titleMy,String titleEn,
                      String summaryMy,String summaryEn,String exampleMy,String exampleEn,
                      String[] redMy,String[] redEn,String[] safeMy,String[] safeEn) {
            this.icon=icon;this.categoryMy=catMy;this.categoryEn=catEn;
            this.titleMy=titleMy;this.titleEn=titleEn;this.summaryMy=summaryMy;this.summaryEn=summaryEn;
            this.exampleMy=exampleMy;this.exampleEn=exampleEn;
            this.redMy=redMy;this.redEn=redEn;this.safeMy=safeMy;this.safeEn=safeEn;
        }
    }
    public static final Lesson[] LESSONS={
      new Lesson("✉","မက်ဆေ့ချ်","MESSAGES","လင့်ခ်လိမ်လည်မှု (Phishing)","Phishing messages",
        "ဘဏ်၊ ပို့ဆောင်ရေး၊ လူမှုကွန်ရက်အကောင့်အမည်များဖြင့် လင့်ခ်နှိပ်ခိုင်းပြီး ကိုယ်ရေးအချက်အလက် တောင်းယူတတ်သည်။",
        "A message may impersonate a bank, delivery company or social app to steal passwords or payment details.",
        "ဥပမာ — “သင့်အကောင့် ပိတ်တော့မည်။ ယခု လင့်ခ်နှိပ်ပြီး အတည်ပြုပါ”",
        "Example — “Your account will be closed. Verify NOW using this link.”",
        new String[]{"ချက်ချင်းလုပ်ရန် ဖိအားပေးခြင်း","လင့်ခ်မှ စကားဝှက်/ငွေကြေးအချက်အလက် တောင်းခြင်း","ပို့သူ၏ အမည်၊ ဝဘ်လိပ်စာ မကိုက်ညီခြင်း"},
        new String[]{"Urgent threats or artificial deadlines","A link asks for your password or payment details","Sender or website address does not match the organization"},
        new String[]{"မသေချာသည့် လင့်ခ်ကို မနှိပ်ပါနှင့်။","မိမိသိထားသည့် တရားဝင်အက်ပ်/ဝဘ်ဆိုက်မှသာ စစ်ဆေးပါ။","အတည်မပြုနိုင်သည့် မက်ဆေ့ချ်ကို ပိတ်ဆို့ပြီး သတင်းပို့ပါ။"},
        new String[]{"Do not tap an unexpected link.","Check the company in its official app or a known website.","Block and report suspicious messages."}),
      new Lesson("▣","လူမှုကွန်ရက်","ACCOUNTS","OTP နှင့် အကောင့်လုံခြုံရေး","OTP and account takeover",
        "တစ်ခါသုံးကုဒ် (OTP) နှင့် ပြန်လည်ရယူရန်ကုဒ်များကို မည်သူ့ကိုမျှ မပေးပါနှင့်။",
        "Never share one-time codes, recovery codes, passkeys or passwords with anyone.",
        "ဥပမာ — “ကျွန်တော် support ပါ။ သင့်ဖုန်းထဲ ရောက်လာတဲ့ OTP ကို ပြန်ပြောပါ”",
        "Example — “I'm support. Tell me the code you just received.”",
        new String[]{"ဝန်ထမ်းဟုဆိုပြီး OTP တောင်းခြင်း","မိမိမစတင်ထားသော login အတွက် ကုဒ်ရောက်လာခြင်း","အကောင့်ပြန်ရယူရေးအတွက် ငွေပေးခိုင်းခြင်း"},
        new String[]{"Someone posing as support demands a code","A login code arrives when you did not try to sign in","They ask for money to recover an account"},
        new String[]{"OTP၊ PIN၊ recovery code ကို လျှို့ဝှက်ထားပါ။","ထူးဆန်းသော login များရှိပါက စကားဝှက်ပြောင်းပြီး စက်ပစ္စည်းများကို စစ်ပါ။","Two-step verification သို့မဟုတ် passkey ကို အသုံးပြုပါ။"},
        new String[]{"Keep OTPs, PINs and recovery codes secret.","Review unknown sessions and change your password if needed.","Enable two-step verification or passkeys."}),
      new Lesson("♧","အလုပ်အကိုင်","JOBS","အလုပ်ကမ်းလှမ်းချက်အတု","Fake job offers",
        "အလုပ်မစခင် မှတ်ပုံတင်ကြေး၊ ခရီးစရိတ်၊ လုံခြုံရေးစရိတ်ကြိုတောင်းသော ကမ်းလှမ်းချက်များကို သတိထားပါ။",
        "Treat unsolicited jobs that demand advance fees, identity documents or secrecy with caution.",
        "ဥပမာ — “အလုပ်သေချာရမယ်။ စာရင်းသွင်းကြေး အရင်လွှဲပေးပါ”",
        "Example — “Guaranteed job! Pay your registration fee first.”",
        new String[]{"အလုပ်မစခင် ငွေလွှဲခိုင်းခြင်း","ကုမ္ပဏီနာမည်/လိပ်စာကို အတည်မပြုနိုင်ခြင်း","ခရီးသွားရမည့်နေရာကို ရှင်းမပြခြင်း"},
        new String[]{"Upfront payment to start work","No verifiable employer address or registration","Unclear travel or workplace arrangements"},
        new String[]{"ကုမ္ပဏီနှင့် အလုပ်ကြော်ငြာကို လွတ်လပ်သောရင်းမြစ်များမှ စစ်ပါ။","စာချုပ်ဖတ်ရန် အချိန်ယူပြီး ယုံကြည်ရသူနှင့် ဆွေးနွေးပါ။","ဖိအားပေးခြင်း သို့မဟုတ် ခြိမ်းခြောက်ခြင်းရှိလျှင် လုံခြုံရာသို့ ရွှေ့ပြီး အကူအညီရှာပါ။"},
        new String[]{"Verify the employer independently.","Take time to review contracts with someone you trust.","If threatened or coerced, prioritize safety and seek trusted help."}),
      new Lesson("▤","ငွေကြေး","PAYMENTS","ငွေလွှဲနှင့် ရင်းနှီးမြှုပ်နှံမှုလိမ်လည်မှု","Payment and investment scams",
        "အမြတ်သေချာကြောင်း၊ တစ်ရက်အတွင်း ငွေနှစ်ဆဖြစ်မည်ဟု ကတိပေးသော ရင်းနှီးမြှုပ်နှံမှုများကို သံသယထားပါ။",
        "Promises of guaranteed returns and requests for irreversible payments are warning signs.",
        "ဥပမာ — “ရင်းနှီးမြှုပ်နှံလိုက်ပါ။ တစ်ပတ်အတွင်း အမြတ် ၃ ဆ ပြန်ပေးမယ်”",
        "Example — “Invest today, guaranteed triple returns next week.”",
        new String[]{"မဖြစ်နိုင်လောက်အောင် အမြတ်ကတိပေးခြင်း","လက်ဆောင်ကတ်၊ crypto သို့မဟုတ် အမည်မသိအကောင့်သို့ ပို့ခိုင်းခြင်း","အမြန်ဆုံးလွှဲရန် ဖိအားပေးခြင်း"},
        new String[]{"Unrealistic guaranteed profits","Payment to unknown accounts or hard-to-reverse methods","Pressure to transfer immediately"},
        new String[]{"ငွေလွှဲမီ လက်ခံသူအား သီးခြားနည်းလမ်းဖြင့် အတည်ပြုပါ။","ပုံမှန်မဟုတ်သော အမြတ်ကတိများကို မယုံပါနှင့်။","လွှဲပြီးပြီဆိုပါက ငွေကြေးဝန်ဆောင်မှုပေးသူကို ချက်ချင်းဆက်သွယ်ပါ။"},
        new String[]{"Verify the recipient independently before paying.","Do not trust guaranteed-profit claims.","If you paid, contact your bank/payment provider immediately."}),
      new Lesson("♡","ဆက်ဆံရေး","SOCIAL","မိတ်ဆွေ/ချစ်သူအယောင်ဆောင်မှု","Romance and impersonation",
        "ယုံကြည်မှုတည်ဆောက်ပြီးနောက် ငွေ၊ လျှို့ဝှက်ချက် သို့မဟုတ် ဓာတ်ပုံတောင်းခံတတ်သည်။",
        "Scammers may build trust, then ask for money, intimate images or account access.",
        "ဥပမာ — “တခြားသူတွေကို မပြောနဲ့။ အရေးပေါ်ဆိုပြီး ငွေထည့်ပေးပါ”",
        "Example — “Keep this secret. I urgently need you to send money.”",
        new String[]{"ကိုယ်တိုင်တွေ့/အတည်ပြုရန် အမြဲရှောင်ခြင်း","မိသားစုနှင့် မဆွေးနွေးရန် တားခြင်း","ချစ်ခင်မှုကို အသုံးချ၍ ငွေတောင်းခြင်း"},
        new String[]{"Avoids independent identity verification","Insists you keep the relationship secret","Uses emotional pressure to ask for money"},
        new String[]{"သက်ဆိုင်သူ၏ အမှန်တကယ်အကောင့်ကို သီးခြားစစ်ပါ။","ငွေ၊ OTP သို့မဟုတ် အထိခိုက်မခံသောဓာတ်ပုံများ မပို့ပါနှင့်။","ခြိမ်းခြောက်လာပါက အထောက်အထားသိမ်းပြီး ယုံကြည်ရသူထံ အကူအညီတောင်းပါ။"},
        new String[]{"Verify identity through a separate trusted channel.","Do not send money, codes or sensitive photos under pressure.","If threatened, preserve evidence and seek trusted support."}),
      new Lesson("◇","ဖုန်းလုံခြုံရေး","DEVICES","မသိသော APK နှင့် app permission","Unknown APKs and permissions",
        "မသိသောအရင်းအမြစ်မှ app ထည့်ခြင်း၊ အလွန်အကျွံ ခွင့်ပြုချက်ပေးခြင်းတို့ကို သတိထားပါ။",
        "Unknown apps may request dangerous permissions or install harmful software.",
        "ဥပမာ — “အလုပ်ရဖို့ ဒီ APK ဖိုင်ကို install လုပ်ပြီး Accessibility ဖွင့်ပါ”",
        "Example — “Install this APK and enable Accessibility access to get the job.”",
        new String[]{"မသိသောဝဘ်ဆိုက်မှ APK ဒေါင်းခိုင်းခြင်း","SMS၊ Accessibility၊ Notification access အလွန်အကျွံတောင်းခြင်း","လုံခြုံရေးသတိပေးချက်ကို ကျော်ခိုင်းခြင်း"},
        new String[]{"APK from an unverified website","Unnecessary SMS, Accessibility or notification permissions","Pressure to bypass device security warnings"},
        new String[]{"ယုံကြည်စိတ်ချရသော app store/ထုတ်လုပ်သူထံမှသာ ရယူပါ။","တောင်းထားသော permission များကို စစ်ဆေးပါ။","ဖုန်းစနစ်ကို update လုပ်၍ ယုံကြည်ရသော security scan ကို အသုံးပြုပါ။"},
        new String[]{"Install apps only from trusted publishers/stores.","Review permissions; deny access not needed for the feature.","Update your phone and use trusted device protection."}),
      new Lesson("⚿","အကောင့်လုံခြုံရေး","PASSWORDS","ခိုင်မာသော စကားဝှက်နှင့် 2FA","Strong passwords and 2FA",
        "အကောင့်တစ်ခုစီအတွက် မတူသော စကားဝှက်များထားပြီး အခြားသူနှင့် မမျှဝေပါနှင့်။",
        "Use unique passwords, a trusted password manager and strong account authentication.",
        "ဥပမာ — “Password တူတူကို Facebook၊ email၊ wallet မှာ သုံးထားသည်”",
        "Example — “I reuse the same password for email, social and payments.”",
        new String[]{"ဝဘ်ဆိုက်များစွာတွင် password တူခြင်း","2FA ပိတ်ထားခြင်း","Recovery email/ဖုန်းနံပါတ်ဟောင်းထားခြင်း"},
        new String[]{"Reusing the same password across accounts","No additional sign-in protection","Outdated recovery email or phone"},
        new String[]{"အကောင့်တိုင်းအတွက် password မတူအောင်ထားပါ။","Passkey သို့မဟုတ် authenticator-based 2FA သုံးပါ။","Recovery options နှင့် login devices များကို ပုံမှန်စစ်ပါ။"},
        new String[]{"Use a different strong password for each account.","Prefer passkeys or authenticator-based two-factor sign-in.","Review recovery options and signed-in devices."}),
      new Lesson("◎","သတင်းမှန်ကန်မှု","MISINFORMATION","သတင်းအတုနှင့် AI အသံ/ပုံ","Fake news and AI impersonation",
        "အသံ၊ ဓာတ်ပုံ၊ ဗီဒီယိုတစ်ခုတည်းကြောင့် သတင်းမှန်ဟု မယူဆပါနှင့်။",
        "A convincing photo, voice note or AI-generated video is not proof that a claim is true.",
        "ဥပမာ — “ကျော်ကြားသူက အခုချက်ချင်း ငွေလွှဲဆိုတဲ့ ဗီဒီယိုတစ်ခု မျှဝေလိုက်သည်”",
        "Example — “A familiar voice in a video urgently asks everyone to send money.”",
        new String[]{"မူရင်းသတင်းရင်းမြစ်မရှိခြင်း","ချက်ချင်းမျှဝေရန်/ငွေလွှဲရန် ဖိအားပေးခြင်း","အခြားလွတ်လပ်သော သတင်းရင်းမြစ်မတွေ့ခြင်း"},
        new String[]{"No original, verifiable source","Urgent pressure to share or pay","No corroboration from independent reliable sources"},
        new String[]{"သတင်းတင်သည့်ရက်စွဲနှင့် မူရင်းရင်းမြစ်ကို စစ်ပါ။","ယုံကြည်ရသော လွတ်လပ်သည့်ရင်းမြစ်များနှင့် နှိုင်းယှဉ်ပါ။","မသေချာသေးလျှင် မျှဝေပါနှင့်။"},
        new String[]{"Check date, context and original publisher.","Compare with independent reliable sources.","Do not amplify unverified claims."}),
      new Lesson("⌁","ကိုယ်ရေးအချက်အလက်","PRIVACY","အွန်လိုင်းကိုယ်ရေးအချက်အလက်","Privacy and public Wi-Fi",
        "လူသိရှင်ကြား ပို့စ်များနှင့် ဖုန်းခွင့်ပြုချက်များတွင် ကိုယ်ရေးအချက်အလက် မလိုအပ်ဘဲ မဖော်ပြပါနှင့်။",
        "Limit public personal information; review app access and protect accounts on shared devices.",
        "ဥပမာ — “အလုပ်လျှောက်ဖို့ မှတ်ပုံတင်၊ နေရပ်လိပ်စာ၊ OTP ကို public group ထဲ တင်ခိုင်းသည်”",
        "Example — “Post your ID, home address and OTP in a public jobs group.”",
        new String[]{"အများပြည်သူမြင်နိုင်သောနေရာတွင် ID တောင်းခြင်း","app permission လွန်ကဲခြင်း","အများသုံးဖုန်းပေါ် အကောင့်မထွက်ခြင်း"},
        new String[]{"Requests for IDs in public chat groups","Apps request broad permissions unnecessarily","Leaving accounts logged in on shared phones"},
        new String[]{"ID နှင့် ကိုယ်ရေးအချက်အလက်များကို မလိုအပ်ဘဲ မမျှဝေပါနှင့်။","အများသုံးစက်မှ logout လုပ်ပါ။","ဖုန်းပိတ်စကားဝှက်နှင့် update များကို သုံးပါ။"},
        new String[]{"Share only the minimum necessary personal information.","Sign out of shared devices and use screen locks.","Keep devices and apps updated."}),
      new Lesson("✚","အကူအညီ","RECOVERY","လိမ်လည်ခံရပြီးနောက် ဘာလုပ်မလဲ","After a scam: first steps",
        "လိမ်လည်မှုကို သံသယရှိပါက အချိန်မဆွဲဘဲ အကောင့်၊ ငွေကြေးနှင့် အထောက်အထားများကို ကာကွယ်ပါ။",
        "If you suspect a scam, act quickly to protect accounts, payments and evidence.",
        "ဥပမာ — “မှားပြီး လင့်ခ်နှိပ်ကာ password ထည့်ခဲ့သည်”",
        "Example — “I entered my password after opening a suspicious link.”",
        new String[]{"ပေးထားသောအချက်အလက်ကို ပြန်ရုပ်သိမ်းမရနိုင်ခြင်း","လိမ်သူက နောက်ထပ်ငွေတောင်းခြင်း","အကောင့်များကို အခြားသူဝင်ရောက်နိုင်ခြင်း"},
        new String[]{"Shared information may be misused","Scammers ask for more money to 'recover' it","Other accounts may now be at risk"},
        new String[]{"ယုံကြည်ရသော စက်မှ password ပြောင်းပြီး login sessions စစ်ပါ။","ငွေလွှဲခဲ့ပါက ဘဏ်/ငွေလွှဲဝန်ဆောင်မှုကို တိုက်ရိုက်ဆက်သွယ်ပါ။","အထောက်အထားများကို သိမ်းဆည်းပြီး သက်ဆိုင်ရာရင်းမြစ်များထံ အကူအညီတောင်းပါ။"},
        new String[]{"Change compromised passwords from a trusted device.","Contact your bank or payment provider through a verified channel.","Keep evidence and seek appropriate help."})
    };

    public static class Question {
        public final String my,en; public final String[] optionsMy, optionsEn;
        public final int answer; public final String explainMy,explainEn;
        public Question(String my,String en,String[] optionsMy,String[] optionsEn,int answer,String explainMy,String explainEn){
            this.my=my;this.en=en;this.optionsMy=optionsMy;this.optionsEn=optionsEn;this.answer=answer;this.explainMy=explainMy;this.explainEn=explainEn;
        }
    }
    public static final Question[] QUIZ={
      new Question("ဘဏ်ကဲ့သို့ ဟန်ဆောင်ပြီး OTP တောင်းလာလျှင် ဘာလုပ်မလဲ။","Someone posing as your bank asks for an OTP. What next?",
        new String[]{"OTP ကို ပေးမယ်","မပေးဘဲ တရားဝင်ဘဏ်မှ စစ်မယ်","လင့်ခ်ကို သူငယ်ချင်းများထံ ပို့မယ်"},
        new String[]{"Send the code","Refuse and verify through your bank's known channel","Forward the link to friends"},1,
        "OTP ကို မမျှဝေပါနှင့်။ ယုံကြည်ရသော အဆက်အသွယ်လမ်းကြောင်းမှသာ စစ်ပါ။","Never share OTPs. Verify requests through an independent official channel."),
      new Question("အလုပ်ရဖို့ မှတ်ပုံတင်ကြေး ကြိုပေးခိုင်းသည်။ ဘာလုပ်သင့်သလဲ။","A recruiter demands an advance registration fee. What should you do?",
        new String[]{"ချက်ချင်းငွေလွှဲမယ်","ကုမ္ပဏီကို သီးခြားစစ်မယ်","အခြားသူတွေကိုလည်း လွှဲခိုင်းမယ်"},
        new String[]{"Pay immediately","Verify the employer independently","Tell others to pay too"},1,
        "အလုပ်မစမီ ငွေကြိုတောင်းခြင်းသည် သတိပေးလက္ခဏာဖြစ်နိုင်သည်။","Advance fee requests are a warning sign; verify the employer."),
      new Question("မသေချာသော လင့်ခ်နှိပ်ရန် အချိန်ဖိအားပေးလျှင် ဘာလုပ်မလဲ။","A message pressures you to click a link immediately. What's safer?",
        new String[]{"လင့်ခ်မနှိပ်ဘဲ မူရင်းအက်ပ်မှ စစ်မယ်","စကားဝှက်ထည့်မယ်","ကုဒ်ကိုပို့မယ်"},
        new String[]{"Verify in the real app instead","Enter the password","Send your code"},0,
        "လင့်ခ်မသုံးဘဲ တရားဝင်လမ်းကြောင်းမှ စစ်ဆေးခြင်းက ပိုလုံခြုံသည်။","Verify using a known official app or URL rather than the suspicious link."),
      new Question("အမြတ် ၃ ဆ အာမခံသော ရင်းနှီးမြှုပ်နှံမှုကြော်ငြာကို တွေ့သည်။","A post promises guaranteed triple investment returns. What next?",
        new String[]{"ချက်ချင်းလွှဲမယ်","မိသားစု OTP ကို သုံးမယ်","သံသယထားပြီး သီးခြားစစ်မယ်"},
        new String[]{"Pay immediately","Use a family member's OTP","Treat as suspicious and verify"},2,
        "အမြတ်သေချာသည်ဟု အာမခံခြင်းသည် လိမ်လည်မှု၏ သတိပေးလက္ခဏာ ဖြစ်နိုင်သည်။","Guaranteed profits are a common warning sign; investigate independently."),
      new Question("အမည်မသိ APK တစ်ခုက Accessibility ခွင့်ပြုချက်တောင်းသည်။","An unknown APK requests Accessibility access. What is safest?",
        new String[]{"အကုန်ခွင့်ပြုမယ်","မထည့်ဘဲ အရင်းအမြစ်ကို စစ်မယ်","ဖုန်းလုံခြုံရေးပိတ်မယ်"},
        new String[]{"Allow all permissions","Avoid installing and verify the source","Disable phone security"},1,
        "မလိုအပ်သော ခွင့်ပြုချက်များကို မပေးပါနှင့်။","Deny unnecessary permissions and avoid untrusted apps."),
      new Question("သူငယ်ချင်းအကောင့်မှ အရေးပေါ်ငွေတောင်းသည်။ ဘာလုပ်မလဲ။","A friend's account urgently asks for money. What should you do?",
        new String[]{"သူငယ်ချင်းကို သီးခြားဖုန်းဆက်စစ်မယ်","ငွေချက်ချင်းလွှဲမယ်","OTP ပေးမယ်"},
        new String[]{"Verify with your friend in another channel","Transfer immediately","Share an OTP"},0,
        "အကောင့်အယောင်ဆောင်မှု ဖြစ်နိုင်သောကြောင့် သီးခြားနည်းဖြင့် စစ်ပါ။","The account may be impersonated; verify separately."),
      new Question("မိမိ password ကို လင့်ခ်အတုတွင် ဖြည့်ခဲ့မိသည်။ ဘာလုပ်မလဲ။","You entered a password on a phishing page. What should you do?",
        new String[]{"ဘာမှမလုပ်ဘူး","တူသော password များမပြောင်းဘူး","ယုံကြည်ရသောစက်မှ password ပြောင်းမယ်"},
        new String[]{"Do nothing","Keep reused passwords","Change the password from a trusted device"},2,
        "အကောင့်ကိုကာကွယ်ရန် password၊ 2FA နှင့် login session များကို စစ်ဆေးပါ။","Change passwords, review sessions and enable stronger sign-in protections."),
      new Question("သတင်းတစ်ခုတွင် AI အသံပါသည်။ ချက်ချင်းမျှဝေသင့်သလား။","A convincing AI voice clip makes a claim. Should you share at once?",
        new String[]{"မူရင်းနှင့် အခြားရင်းမြစ်များ စစ်မယ်","ချက်ချင်းမျှဝေမယ်","ငွေတောင်းလျှင်ပို့မယ်"},
        new String[]{"Check its origin and other sources","Share immediately","Pay if asked"},0,
        "အသံ/ဗီဒီယိုတစ်ခုတည်း မလုံလောက်ပါ။ မျှဝေမီ အချက်အလက်စစ်ပါ။","A convincing recording is not proof; verify the claim before sharing."),
    };

    public static class Remedy {
        public final String icon, titleMy,titleEn,subtitleMy,subtitleEn;
        public final String[] stepsMy,stepsEn;
        public Remedy(String icon,String my,String en,String subMy,String subEn,String[] mySteps,String[] enSteps){
            this.icon=icon;titleMy=my;titleEn=en;subtitleMy=subMy;subtitleEn=subEn;stepsMy=mySteps;stepsEn=enSteps;
        }
    }
    public static final Remedy[] REMEDIES={
      new Remedy("⌁","ငွေလွှဲပြီးပြီ","I sent money",
        "အချိန်မဆွဲဘဲ ဘဏ်/ငွေလွှဲဝန်ဆောင်မှုကို ဆက်သွယ်ပါ။","Act fast and contact the payment provider.",
        new String[]{"မိမိသိထားသော တရားဝင်ဖုန်းနံပါတ်/အက်ပ်မှ ဘဏ်ကို ချက်ချင်းဆက်သွယ်ပါ။","ငွေလွှဲမှတ်တမ်း၊ အချိန်၊ လက်ခံသူအချက်အလက်ကို လုံခြုံစွာ သိမ်းပါ။","ငွေပြန်ရရန် အခကြေးငွေကြိုတောင်းသောသူကို ထပ်မပေးပါနှင့်။","အခြေအနေအလိုက် တရားဝင်သတင်းပို့လမ်းကြောင်းကို ဆက်သွယ်ပါ။"},
        new String[]{"Contact your bank/payment provider using its verified app or number immediately.","Preserve transaction records and dates safely.","Never pay an extra 'recovery fee' to a stranger.","Use appropriate official reporting channels for your location."}),
      new Remedy("⚿","စကားဝှက်ပေါက်ကြားသွားပြီ","My password was exposed",
        "ယုံကြည်ရသောစက်မှ အကောင့်များကို ကာကွယ်ပါ။","Protect affected accounts from a trusted device.",
        new String[]{"သံသယရှိသော လင့်ခ်မှ မဟုတ်ဘဲ တရားဝင်အက်ပ်တွင် password ပြောင်းပါ။","အမည်မသိ login device/session များကို ထုတ်ပယ်ပါ။","တူညီသော password သုံးထားသည့် အခြားအကောင့်များကို ပြောင်းပါ။","2FA/passkey ဖွင့်ပြီး recovery email/phone ကို စစ်ပါ။"},
        new String[]{"Change passwords through the official app from a trusted device.","Sign out unknown sessions.","Change reused passwords across other accounts.","Enable passkeys/2FA and verify recovery methods."}),
      new Remedy("▣","OTP ပေးမိသွားပြီ","I shared a code",
        "အကောင့်ဝင်ရောက်ခွင့်ကို အမြန်ကာကွယ်ပါ။","Secure affected account access quickly.",
        new String[]{"သက်ဆိုင်ရာဝန်ဆောင်မှု၏ တရားဝင် support ကို ဆက်သွယ်ပါ။","ဝင်ရောက်ထားသောစက်များကို စစ်ပြီး အမည်မသိ session များ ထုတ်ပယ်ပါ။","password/2FA ကို အတည်ပြုပြင်ဆင်ပါ။","နောက်ထပ်ရောက်လာသော OTP များကို မည်သူ့ကိုမျှ မပေးပါနှင့်။"},
        new String[]{"Contact the provider via its official support channel.","Review active sessions and revoke unknown access.","Reset credentials and strengthen account verification.","Never share additional codes."}),
      new Remedy("◇","မသိသော app ထည့်မိပြီ","I installed an unknown app",
        "ဖုန်း၏ ခွင့်ပြုချက်နှင့် အကောင့်ကို ပြန်လည်စစ်ပါ။","Review device permissions and secure accounts.",
        new String[]{"သံသယရှိသော app ၏ ခွင့်ပြုချက်များကို စစ်ပါ။","သင့်တော်သလို app ဖယ်ရှားပြီး ယုံကြည်ရသော device protection ဖြင့် စစ်ပါ။","အကောင့်စကားဝှက်များကို လုံခြုံသည့် အခြားစက်မှ ပြောင်းပါ။","မသိသော payment နှင့် login ဖြစ်ရပ်များကို စောင့်ကြည့်ပါ။"},
        new String[]{"Review permissions granted to the suspicious app.","Remove it where safe and run trusted device protection.","Change important account passwords from another trusted device.","Monitor account and payment activity."}),
      new Remedy("♡","ခြိမ်းခြောက်ခံနေရသည်","I am being threatened",
        "သင့်ကိုယ်ပိုင်လုံခြုံရေးကို ဦးစားပေးပါ။","Your physical and personal safety comes first.",
        new String[]{"အန္တရာယ်ရှိနေပါက လုံခြုံရာသို့ ရွှေ့ပြီး ယုံကြည်ရသူထံ အကူအညီတောင်းပါ။","ခြိမ်းခြောက်စာများကို မလိုအပ်ဘဲ ထပ်မဆက်သွယ်ဘဲ လုံခြုံစွာ မှတ်တမ်းတင်ပါ။","ထပ်မံငွေမပို့ပါနှင့်။","သင့်ဒေသအလိုက် အတည်ပြုထားသော အကူအညီဝန်ဆောင်မှုကို ဆက်သွယ်ပါ။"},
        new String[]{"Move to safety and contact someone you trust if you are at risk.","Preserve threatening messages without continuing contact unnecessarily.","Do not send additional payments.","Seek verified local assistance appropriate to your circumstances."})
    };
}
