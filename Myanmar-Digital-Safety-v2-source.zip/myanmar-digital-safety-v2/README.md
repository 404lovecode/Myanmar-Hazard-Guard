# Myanmar Digital Safety · မြန်မာ ဒစ်ဂျစ်တယ် လုံခြုံရေး

**Free, Burmese-first, offline Android app** teaching everyday scam awareness and account protection. A **different Android package** (`com.myanmardigitalsafety`) from Myanmar Hazard Guard; both can remain installed on the same phone.

## What is included

- Cozy sage/cream native Android UI, custom shield launcher icon, Myanmar text by default, optional English toggle.
- 10 complete Burmese/English lessons about phishing, OTP fraud, fake jobs, payments, impersonation, untrusted APKs, secure logins, misinformation, privacy, and responding to scams.
- 8-question interactive scenario quiz with explanations; best score saved on-device.
- 5 step-by-step incident guides: sent money, shared password, shared OTP, installed an untrusted APK, or being threatened.
- Educational scam-warning checklist (NOT an automated scam detector).
- All contents work with **no Internet connection**. Optional vetted educational links open a separate browser only when tapped.
- **No network/SMS/location/contacts/camera/storage/call permissions.** No analytics, ads, account, subscription, external translation, uploaded messages, or cloud backend. Progress is stored locally using private Android preferences; uninstalling the app removes it.

## Safety limitations

This app is educational: **not** an antivirus, live fraud detection tool, emergency hotline, legal adviser, or an official reporting authority. Its advice is general and may need localization. A benign message can still contain warning signs and a malicious message might have none. Avoid entering or pasting real passwords, private chats, identity documents or financial information anywhere in the app.

Fraud advice is based on established consumer digital-security guidance (paraphrased in Burmese and English). Have bilingual reviewers validate the Burmese copy before mass distribution, and repeat device testing including older Android phones and Myanmar fonts.

Sources for user-initiated further reading:
- FTC: https://consumer.ftc.gov/articles/how-recognize-avoid-phishing-scams
- Google Accounts: https://support.google.com/accounts/answer/6294825
- CISA: https://www.cisa.gov/secure-our-world

## Build

JDK 17, Android SDK API 35 and Gradle 8.11.1 (Android Gradle Plugin 8.9.1): `gradle :app:assembleDebug` from project root. See GitHub Actions build workflow in the host branch.

Do not distribute the debug APK as if signed for production. Keep a private, backed-up release signing key before publishing to Play Store or another app store.

## v2 — optional phone-call and DNS ad protection

This independent Android app now includes a **Protection** tab, while retaining
all previous Burmese-first and English offline lessons, quiz and recovery guides.

### Incoming call screening (Android 10 and later)

- The user explicitly selects Myanmar Digital Safety as Android's call screening
  provider in the system role dialog. Without approval, no calls are screened.
- A local, user-managed list of scam phone numbers is automatically rejected
  when an incoming number matches. No external caller-reputation lookups,
  contact harvesting, SMS access, call recording or account are used.
- **Block all unsaved callers** is OPTIONAL, disabled by default, and shows an
  additional confirmation due to risk of missing employers, hospitals or banks.
- A manual trusted-number list overrides the blocklist and unsaved-caller mode.
- Android normally delivers **only numbers outside saved contacts** to screening
  apps without READ_CONTACTS permission. Restricted/unknown-presentation calls
  may not be delivered for screening. This is not a global Truecaller-style
  spam reputation database and cannot identify unknown scams on its own.
- Short codes (less than seven digits) are not added to the blocklist. 
- Block counts remain locally in SharedPreferences. Android may log rejected
  calls in the phone's usual system call log. No outgoing or emergency calls
  are intentionally intercepted.

### Optional DNS ad shield

- Starts ONLY after a prominent separate in-app privacy disclosure plus the
  Android VPN consent dialog. May require a system notification while active.
- Uses Android `VpnService`, with a route to the DNS virtual server **only**
  (`10.67.0.2/32`) and a small, transparent list of common ad/tracker domains.
  No device-wide traffic relay or interception of webpage content is built.
- Known ad domains are answered with NXDOMAIN locally. Other DNS queries are
  sent via **encrypted HTTPS DNS-over-HTTPS to Cloudflare**, explicitly named
  in the app. Cloudflare can see requested domain names. No user accounts,
  caller numbers, SMS or contacts are uploaded.
- Android supports **one VPN at a time**. Enabling the shield replaces the
  currently active VPN. Apps using their own DoH, the Android Private DNS
  setting, and first-party/YouTube ads can bypass DNS filtering. Not all ads
  are blockable and coverage varies by phone, network and Android version.
- When a DNS request cannot reach the HTTPS resolver, the service sends
  SERVFAIL rather than fabricating a successful lookup. If internet access
  breaks, press **Stop ad shield**. No stealth fallback to unencrypted DNS.
- This v2 VPN DNS proxy processes IPv4 UDP DNS. It does not implement IPv6,
  TCP DNS or non-DNS proxying. **Real-phone testing is required before relying
  on it**, especially on older OPPO/MIUI/OneUI Android variants.
- The 2 features are independently opt-in, and both can be disabled from the
  Protection tab. The app does NOT install as a system dialer.

### Permissions

- `INTERNET`, `ACCESS_NETWORK_STATE`: Optional encrypted DNS forwarding.
- `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_SPECIAL_USE`: Background VPN shield
  foreground notification on current Android versions.
- `POST_NOTIFICATIONS`: Notification permission for Android 13+; call screening
  and learning don't use it. The OS may display a VPN notice regardless.
- `BIND_VPN_SERVICE` and `BIND_SCREENING_SERVICE` restrict the services to
  Android OS callers: they are **service protection declarations**, not
  user-granted access to private data.
- No `READ_CONTACTS`, `READ_CALL_LOG`, `READ_SMS`, `CALL_PHONE`, location,
  microphone or camera permissions. No telemetry or analytics SDK.

### Distribution

Use signed **debug APKs for local testing only**. For Google Play distribution,
review the Android VpnService and foreground-service declarations, prominent
consent, verified real-device functionality, and Google Play policies.
Official docs:

- https://developer.android.com/develop/connectivity/telecom/dialer-app/screen-calls
- https://developer.android.com/develop/connectivity/vpn
- https://support.google.com/googleplay/android-developer/answer/12564964?hl=en
