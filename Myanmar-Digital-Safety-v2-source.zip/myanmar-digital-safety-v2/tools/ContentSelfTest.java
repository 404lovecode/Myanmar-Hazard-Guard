import com.myanmardigitalsafety.LearnData;
public final class ContentSelfTest {
  public static void main(String[] args) {
    if(LearnData.LESSONS.length<8 || LearnData.QUIZ.length<6 || LearnData.REMEDIES.length<4) throw new AssertionError("Content incomplete");
    for(LearnData.Lesson x:LearnData.LESSONS) {
      if(x.titleMy.length()<5 || x.titleEn.isEmpty() || x.redMy.length!=x.redEn.length || x.safeMy.length!=x.safeEn.length || x.redMy.length<3) throw new AssertionError("Lesson translations incomplete");
    }
    for(LearnData.Question x:LearnData.QUIZ) {
      if(x.answer<0 || x.answer>=x.optionsMy.length || x.optionsEn.length!=x.optionsMy.length || x.optionsMy.length!=3 || x.explainMy.isEmpty()) throw new AssertionError("Question invalid");
    }
    for(LearnData.Remedy x:LearnData.REMEDIES) if(x.stepsMy.length!=x.stepsEn.length || x.stepsMy.length<3)throw new AssertionError("Remedy incomplete");
    System.out.printf("Passed: %d lessons, %d quiz scenarios, %d recovery guides%n",LearnData.LESSONS.length,LearnData.QUIZ.length,LearnData.REMEDIES.length);
  }
}
