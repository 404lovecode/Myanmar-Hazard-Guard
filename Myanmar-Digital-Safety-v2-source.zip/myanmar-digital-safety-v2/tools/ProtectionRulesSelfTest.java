import com.myanmardigitalsafety.AdDomainRules;
import com.myanmardigitalsafety.PhoneBlockRules;
public final class ProtectionRulesSelfTest {
    private static void check(boolean x,String m){if(!x)throw new AssertionError(m);}
    public static void main(String[] args){
        check("+959123456789".equals(PhoneBlockRules.normalize("+95 (9) 123 456 789")),"E164");
        check(PhoneBlockRules.normalize("191").isEmpty(),"short emergency must not block");
        check(PhoneBlockRules.normalize("*123#").isEmpty(),"malformed number");
        String b=PhoneBlockRules.add("","+959123456789");
        check(PhoneBlockRules.shouldBlock("+959123456789",b,"",false),"listed caller blocked");
        check(!PhoneBlockRules.shouldBlock("+959123456789",b,b,true),"trusted override");
        check(!PhoneBlockRules.shouldBlock("+959999999999","","",false),"unknown mode off");
        check(PhoneBlockRules.shouldBlock("+959999999999","","",true),"unknown mode on");
        check(!PhoneBlockRules.shouldBlock("","","",true),"unreadable number allowed");
        check(AdDomainRules.shouldBlock("stats.doubleclick.net",""),"subdomain blocks");
        check(!AdDomainRules.shouldBlock("doubleclick.net.example.org",""),"no deceptive suffix");
        check(!AdDomainRules.shouldBlock("stats.doubleclick.net","doubleclick.net"),"allowlist override");
        check(!AdDomainRules.shouldBlock("news.bbc.com",""),"news unaffected");
        check(AdDomainRules.normalize("bad/path").isEmpty(),"invalid host");
        System.out.println("Call screening and DNS blocking rule tests passed");
    }
}
