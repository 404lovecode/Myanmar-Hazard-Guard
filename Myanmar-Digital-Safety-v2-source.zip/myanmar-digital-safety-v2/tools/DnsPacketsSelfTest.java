import com.myanmardigitalsafety.DnsPackets;
import java.io.ByteArrayOutputStream;
public class DnsPacketsSelfTest {
  static void check(boolean c,String s){if(!c)throw new AssertionError(s);}
  static void put(byte[] b,int p,int n){b[p]=(byte)(n>>>8);b[p+1]=(byte)n;}
  public static void main(String[] args)throws Exception {
    ByteArrayOutputStream q=new ByteArrayOutputStream();
    q.write(new byte[]{0x12,0x34,1,0,0,1,0,0,0,0,0,0});
    for(String s:"ad.doubleclick.net".split("\\.")) {q.write(s.length());q.write(s.getBytes("US-ASCII"));}
    q.write(new byte[]{0,0,1,0,1});byte[] d=q.toByteArray();
    byte[] p=new byte[28+d.length];p[0]=0x45;put(p,2,p.length);p[8]=64;p[9]=17;
    p[12]=10;p[13]=67;p[14]=0;p[15]=1;
    p[16]=10;p[17]=67;p[18]=0;p[19]=2;
    put(p,20,49520);put(p,22,53);put(p,24,8+d.length);System.arraycopy(d,0,p,28,d.length);
    DnsPackets.Question parsed=DnsPackets.parse(p,p.length);
    check(parsed!=null,"question parses");check("ad.doubleclick.net".equals(parsed.host),"host");
    byte[] block=DnsPackets.blockedDns(parsed),reply=DnsPackets.reply(parsed,block);
    check(reply.length==28+block.length,"length");
    check((block[3]&0xf)==3,"NXDOMAIN");check((reply[20]&255)==0 && (reply[21]&255)==53,"port");
    check(reply[12]==10&&reply[15]==2&&reply[19]==1,"IP swapped");
    check(DnsPackets.parse(reply,reply.length)==null,"response not query");
    p[0]=0x60;check(DnsPackets.parse(p,p.length)==null,"reject IPv6");
    System.out.println("IPv4 DNS query and blocked response packet tests passed");
  }
}
