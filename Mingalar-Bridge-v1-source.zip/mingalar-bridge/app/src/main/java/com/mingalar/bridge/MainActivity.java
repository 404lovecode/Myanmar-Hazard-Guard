package com.mingalar.bridge;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

public final class MainActivity extends Activity {
    private static final int BG=0xffF8F7F1, INK=0xff233B39, MUTED=0xff66817A;
    private static final int GREEN=0xff1D7468, DEEP=0xff165B52, MINT=0xffE5F4EA;
    private static final int WHITE=0xffFFFFFF, BORDER=0xffD9E7DD, SAND=0xffFFF0D8;
    private static final int CORAL=0xffC37440, LIGHT=0xffF0F5EE;
    private final ArrayList<Phrase> phrases=new ArrayList<>();
    private final ArrayList<Category> categories=new ArrayList<>();
    private final Set<String> favorites=new HashSet<>();
    private SharedPreferences store;
    private LinearLayout root, content, listHost;
    private TextToSpeech speech;
    private boolean speechReady=false;
    private String filter="all", query="";
    private int page=0, visibleCount=20, practiceIndex=0;

    private static final class Phrase {
        final String id,category,my,th,en;
        Phrase(JSONObject j) {
            id=j.optString("id"); category=j.optString("category");
            my=j.optString("my"); th=j.optString("th"); en=j.optString("en");
        }
    }
    private static final class Category {
        final String id,my,th,en,emoji;
        Category(JSONObject j) {
            id=j.optString("id");my=j.optString("my");th=j.optString("th");
            en=j.optString("en");emoji=j.optString("emoji");
        }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(DEEP);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        store=getSharedPreferences("mingalar_bridge_local_v1",MODE_PRIVATE);
        favorites.addAll(store.getStringSet("favorites",Collections.emptySet()));
        loadPhrases();
        speech=new TextToSpeech(this,status->{speechReady=status==TextToSpeech.SUCCESS;});
        render();
    }
    @Override protected void onDestroy() {
        if(speech!=null){speech.stop();speech.shutdown();speech=null;}
        super.onDestroy();
    }
    private int dp(float n){return Math.round(getResources().getDisplayMetrics().density*n);}
    private GradientDrawable bg(int color,int radius,int stroke) {
        GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));
        if(stroke!=0)d.setStroke(dp(1),stroke);
        return d;
    }
    private TextView text(String content,int size,int color,boolean bold) {
        TextView v=new TextView(this);v.setText(content);v.setTextSize(size);
        v.setTextColor(color);v.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);
        if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        v.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        v.setIncludeFontPadding(true);
        return v;
    }
    private LinearLayout vertical() {LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout horizontal() {LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private void addGap(LinearLayout parent,int px) {View v=new View(this);parent.addView(v,new LinearLayout.LayoutParams(1,dp(px)));}
    private LinearLayout card(int color) {
        LinearLayout v=vertical();v.setPadding(dp(17),dp(17),dp(17),dp(17));
        v.setBackground(bg(color,23,color==WHITE?BORDER:0));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(12);
        content.addView(v,lp);return v;
    }
    private void addText(LinearLayout target,String t,int sz,int color,boolean bold) {
        target.addView(text(t,sz,color,bold),new LinearLayout.LayoutParams(-1,-2));
    }
    private TextView button(String label,int fg,int background) {
        TextView v=text(label,14,fg,true);
        v.setGravity(Gravity.CENTER);v.setMinHeight(dp(49));
        v.setPadding(dp(14),dp(11),dp(14),dp(11));
        v.setBackground(bg(background,15,0));
        v.setClickable(true);v.setFocusable(true);
        return v;
    }
    private void loadPhrases() {
        try(InputStream in=getAssets().open("phrases.json"); ByteArrayOutputStream out=new ByteArrayOutputStream()) {
            byte[] b=new byte[4096];int len;
            while((len=in.read(b))>0)out.write(b,0,len);
            JSONObject all=new JSONObject(out.toString("UTF-8"));
            JSONArray cats=all.getJSONArray("categories");
            for(int i=0;i<cats.length();i++)categories.add(new Category(cats.getJSONObject(i)));
            JSONArray ps=all.getJSONArray("phrases");
            for(int i=0;i<ps.length();i++)phrases.add(new Phrase(ps.getJSONObject(i)));
        } catch(Exception e) {
            Toast.makeText(this,"Could not load offline phrases: "+e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }
    private void render() {
        root=vertical();root.setBackgroundColor(BG);
        setContentView(root);
        LinearLayout top=horizontal();top.setPadding(dp(20),dp(14),dp(20),dp(13));
        top.setBackgroundColor(DEEP);
        TextView logo=text("🌉",26,WHITE,true);top.addView(logo);
        LinearLayout heading=vertical();
        addText(heading,"Mingalar Bridge",21,WHITE,true);
        addText(heading,"မင်္ဂလာတံတား  ·  မြန်မာ  ไทย  English",11,0xffD9F4E6,false);
        LinearLayout.LayoutParams hLp=new LinearLayout.LayoutParams(0,-2,1);hLp.leftMargin=dp(12);
        top.addView(heading,hLp);
        TextView info=button("ⓘ",DEEP,MINT);info.setMinHeight(dp(44));info.setOnClickListener(v->showInfo());
        top.addView(info);root.addView(top);

        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setClipToPadding(false);
        content=vertical();content.setPadding(dp(17),dp(18),dp(17),dp(18));scroll.addView(content);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        if(page==0)home();else if(page==1)showFavorites();else practice();
        bottomNavigation();
    }
    private void bottomNavigation() {
        LinearLayout bar=horizontal();bar.setPadding(dp(10),dp(9),dp(10),dp(9));
        bar.setBackgroundColor(WHITE);
        String[] captions={"⌂  စကားစုများ", "♥  ကြိုက်နှစ်သက်", "▶  လေ့ကျင့်"};
        String[] hints={"Browse phrases","Saved favorites","Practice"};
        for(int i=0;i<3;i++) {
            final int destination=i;
            LinearLayout cell=vertical();cell.setGravity(Gravity.CENTER);
            cell.setPadding(dp(3),dp(7),dp(3),dp(8));
            cell.setBackground(bg(page==i?MINT:WHITE,15,0));
            TextView title=text(captions[i],12,page==i?DEEP:MUTED,true);
            title.setGravity(Gravity.CENTER);cell.addView(title);
            TextView sub=text(hints[i],10,page==i?GREEN:MUTED,false);
            sub.setGravity(Gravity.CENTER);cell.addView(sub);
            cell.setOnClickListener(v->{page=destination;render();});
            cell.setFocusable(true);cell.setContentDescription(hints[i]);
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);
            lp.leftMargin=dp(3);lp.rightMargin=dp(3);
            bar.addView(cell,lp);
        }
        root.addView(bar);
    }
    private void home() {
        LinearLayout welcome=card(MINT);
        addText(welcome,"မင်္ဂလာပါ!  👋",25,DEEP,true);addGap(welcome,5);
        addText(welcome,"Thai & English phrases for everyday life",15,INK,true);addGap(welcome,5);
        addText(welcome,"အင်တာနက်မလို • အခမဲ့ • ကြော်ငြာမရှိ",13,MUTED,false);addGap(welcome,12);
        LinearLayout stats=horizontal();
        TextView total=button("100 phrases",GREEN,WHITE);
        TextView count=button("♥ "+favorites.size()+" saved",GREEN,WHITE);
        LinearLayout.LayoutParams left=new LinearLayout.LayoutParams(0,-2,1);left.rightMargin=dp(8);
        stats.addView(total,left);stats.addView(count,new LinearLayout.LayoutParams(0,-2,1));welcome.addView(stats);

        TextView categoryHeading=text("နေ့စဉ်သုံးစကားစုများ  ·  Find a phrase",18,INK,true);
        content.addView(categoryHeading);addGap(content,10);
        EditText search=new EditText(this);
        search.setSingleLine(true);search.setTextSize(15);
        search.setTextColor(INK);search.setHintTextColor(MUTED);
        search.setHint("🔎  မြန်မာ • ไทย • English");
        search.setPadding(dp(17),dp(13),dp(17),dp(13));
        search.setBackground(bg(WHITE,18,BORDER));
        search.setText(query);
        search.addTextChangedListener(new TextWatcher(){
            @Override public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            @Override public void onTextChanged(CharSequence s,int st,int before,int count){query=s.toString();visibleCount=20;populateCards(false);}
            @Override public void afterTextChanged(Editable e){}
        });
        content.addView(search);addGap(content,13);
        HorizontalScrollView chips=new HorizontalScrollView(this);chips.setHorizontalScrollBarEnabled(false);
        LinearLayout chipRow=horizontal();
        addChip(chipRow,"all","🌍  အားလုံး");
        for(Category cat:categories)addChip(chipRow,cat.id,cat.emoji+"  "+cat.my);
        chips.addView(chipRow);content.addView(chips);addGap(content,13);
        listHost=vertical();content.addView(listHost);
        populateCards(false);
    }
    private void addChip(LinearLayout row,String id,String caption) {
        boolean selected=filter.equals(id);
        TextView chip=button(caption,selected?WHITE:DEEP,selected?GREEN:LIGHT);
        chip.setMinHeight(dp(44));
        chip.setOnClickListener(v->{filter=id;visibleCount=20;render();});
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,-2);lp.rightMargin=dp(8);
        row.addView(chip,lp);
    }
    private void showFavorites() {
        LinearLayout header=card(MINT);
        addText(header,"♥  မှတ်ထားသောစကားစုများ",22,DEEP,true);addGap(header,6);
        addText(header,favorites.size()+" favorite phrases · saved privately on your phone",13,MUTED,false);
        listHost=vertical();content.addView(listHost);populateCards(true);
    }
    private ArrayList<Phrase> filtered(boolean favoritesOnly) {
        ArrayList<Phrase> out=new ArrayList<>();String q=query.trim().toLowerCase(Locale.ROOT);
        for(Phrase p:phrases){
            if(favoritesOnly && !favorites.contains(p.id))continue;
            if(!favoritesOnly && !filter.equals("all") && !p.category.equals(filter))continue;
            if(!favoritesOnly && !q.isEmpty()) {
                if(!p.en.toLowerCase(Locale.ROOT).contains(q) &&
                    !p.my.toLowerCase(Locale.ROOT).contains(q) &&
                    !p.th.toLowerCase(Locale.ROOT).contains(q))continue;
            }
            out.add(p);
        }
        return out;
    }
    private void populateCards(boolean favoritesOnly) {
        if(listHost==null)return;
        listHost.removeAllViews();
        ArrayList<Phrase> found=filtered(favoritesOnly);
        TextView count=text(""+found.size()+" phrases  ·  အင်တာနက်မလို",12,MUTED,false);
        count.setPadding(dp(2),0,0,dp(11));listHost.addView(count);
        if(found.isEmpty()) {
            LinearLayout empty=vertical();empty.setBackground(bg(WHITE,22,BORDER));
            empty.setPadding(dp(23),dp(25),dp(23),dp(25));
            addText(empty,favoritesOnly?"ကြိုက်နှစ်သက်ရာ မရှိသေးပါ။":"ရှာဖွေမှုနှင့်ကိုက်ညီသော စကားစုမရှိပါ။",16,INK,true);
            addGap(empty,9);addText(empty,favoritesOnly?"Tap the heart on a phrase to save it here.":"Try a shorter search in Burmese, Thai or English.",13,MUTED,false);
            listHost.addView(empty);return;
        }
        int limit=Math.min(found.size(),favoritesOnly?found.size():visibleCount);
        for(int i=0;i<limit;i++)addPhraseCard(listHost,found.get(i),false);
        if(limit<found.size()) {
            TextView more=button("Show more phrases  ↓",WHITE,GREEN);
            more.setOnClickListener(v->{visibleCount+=20;populateCards(false);});listHost.addView(more);
        }
    }
    private Category categoryFor(String id) {
        for(Category cat:categories)if(cat.id.equals(id))return cat;
        return null;
    }
    private void addPhraseCard(LinearLayout host,Phrase phrase,boolean practiceMode) {
        LinearLayout body=vertical();body.setPadding(dp(16),dp(15),dp(16),dp(16));
        body.setBackground(bg(WHITE,21,BORDER));
        LinearLayout.LayoutParams cardLp=new LinearLayout.LayoutParams(-1,-2);
        cardLp.bottomMargin=dp(12);host.addView(body,cardLp);
        LinearLayout heading=horizontal();
        Category c=categoryFor(phrase.category);
        TextView label=text((c==null?"💬":c.emoji)+"  "+(c==null?"":c.en),12,GREEN,true);
        heading.addView(label,new LinearLayout.LayoutParams(0,-2,1));
        TextView heart=button(favorites.contains(phrase.id)?"♥":"♡",favorites.contains(phrase.id)?CORAL:GREEN,MINT);
        heart.setMinWidth(dp(48));heart.setMinHeight(dp(45));
        heart.setContentDescription(favorites.contains(phrase.id)?"Remove favorite":"Save favorite");
        heart.setOnClickListener(v->{
            if(!favorites.add(phrase.id))favorites.remove(phrase.id);
            store.edit().putStringSet("favorites",new HashSet<>(favorites)).apply();
            if(page==1)render();else {
                heart.setText(favorites.contains(phrase.id)?"♥":"♡");
                heart.setTextColor(favorites.contains(phrase.id)?CORAL:GREEN);
                heart.setContentDescription(favorites.contains(phrase.id)?"Remove favorite":"Save favorite");
            }
        });
        heading.addView(heart);body.addView(heading);addGap(body,9);
        addText(body,phrase.my,19,INK,true);addGap(body,7);
        addText(body,phrase.th,18,DEEP,true);addGap(body,7);
        addText(body,phrase.en,15,MUTED,false);addGap(body,14);
        LinearLayout actions=horizontal();
        String[] tags={"🔊  မြန်မာ","🔊  ไทย","🔊  English"};
        String[] texts={phrase.my,phrase.th,phrase.en};
        String[] langs={"my-MM","th-TH","en-US"};
        for(int i=0;i<3;i++) {
            final int j=i;
            TextView speak=button(tags[i],i==0?DEEP:GREEN,i==0?MINT:LIGHT);
            speak.setTextSize(12);speak.setPadding(dp(5),dp(11),dp(5),dp(11));
            speak.setOnClickListener(v->say(texts[j],langs[j]));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);
            if(i!=0)lp.leftMargin=dp(5);
            actions.addView(speak,lp);
        }
        body.addView(actions);
    }
    private void practice() {
        LinearLayout intro=card(MINT);
        addText(intro,"🎧  နားထောင်ပြီး လေ့ကျင့်ပါ",22,DEEP,true);addGap(intro,8);
        addText(intro,"Practice listening and repeating at your own pace.",14,MUTED,false);
        addGap(intro,9);addText(intro,"Select a speaker below to hear each language if your phone has an offline voice.",12,MUTED,false);
        if(phrases.isEmpty())return;
        Phrase next=phrases.get(Math.floorMod(practiceIndex,phrases.size()));
        addPhraseCard(content,next,true);
        TextView another=button("↻  နောက်ထပ်စကားစု  ·  Next phrase",WHITE,GREEN);
        another.setOnClickListener(v->{practiceIndex=(practiceIndex+17)%phrases.size();render();});
        content.addView(another);addGap(content,13);
        LinearLayout guide=card(SAND);
        addText(guide,"💡  Practice tip",15,DEEP,true);addGap(guide,6);
        addText(guide,"Listen, repeat aloud, then compare the Burmese, Thai and English meanings. For important conversations, ask a fluent speaker to confirm the wording.",13,INK,false);
    }
    private void say(String utterance,String tag) {
        if(speech==null || !speechReady){Toast.makeText(this,"Speech engine is not ready.",Toast.LENGTH_SHORT).show();return;}
        Locale locale=Locale.forLanguageTag(tag);
        int available=speech.isLanguageAvailable(locale);
        if(available<TextToSpeech.LANG_AVAILABLE){missingVoice(tag);return;}
        Voice offline=null;
        Set<Voice> availableVoices=speech.getVoices();
        if(availableVoices!=null){
            for(Voice voice:availableVoices){
                if(!voice.isNetworkConnectionRequired() &&
                    voice.getLocale()!=null && voice.getLocale().getLanguage().equals(locale.getLanguage())) {
                    offline=voice;
                    if(voice.getLocale().getCountry().equals(locale.getCountry()))break;
                }
            }
        }
        if(offline==null){missingVoice(tag);return;}
        int result=speech.setVoice(offline);
        if(result==TextToSpeech.ERROR){missingVoice(tag);return;}
        speech.setSpeechRate(0.92f);
        int speak=speech.speak(utterance,TextToSpeech.QUEUE_FLUSH,null,"mingalar-"+System.nanoTime());
        if(speak==TextToSpeech.ERROR)Toast.makeText(this,"Speech was not available for this phrase.",Toast.LENGTH_SHORT).show();
    }
    private void missingVoice(String lang) {
        String name=lang.startsWith("my")?"Burmese (Myanmar)":lang.startsWith("th")?"Thai":"English";
        new AlertDialog.Builder(this).setTitle("Offline speech voice not installed")
            .setMessage("The "+name+" offline voice is unavailable in your current Android text-to-speech engine. Text phrases still work offline. Burmese speech support varies by device.\n\nInstall a compatible offline language voice in Android Text-to-Speech settings if one is offered.")
            .setPositiveButton("Speech settings",(d,w)->openTtsSettings())
            .setNegativeButton("Close",null).show();
    }
    private void openTtsSettings(){
        try {startActivity(new Intent("com.android.settings.TTS_SETTINGS"));}
        catch(Exception e){Toast.makeText(this,"Open Settings > Accessibility > Text-to-speech output",Toast.LENGTH_LONG).show();}
    }
    private void showInfo() {
        new AlertDialog.Builder(this).setTitle("Mingalar Bridge · About")
            .setMessage("100 practical Burmese–Thai–English phrases.\n\n✓ Free forever\n✓ All phrases and favorites work offline\n✓ No ads, trackers or internet permission\n✓ Favorites remain on this phone\n\nSpeech requires a compatible *offline* language voice installed on Android; not all devices support Burmese.\n\nPhrases are educational examples, not a substitute for professional interpretation or confirmed safety instructions. Community translation review is recommended before wide distribution.")
            .setPositiveButton("Got it",null)
            .setNeutralButton("Voice settings",(d,w)->openTtsSettings()).show();
    }
}
