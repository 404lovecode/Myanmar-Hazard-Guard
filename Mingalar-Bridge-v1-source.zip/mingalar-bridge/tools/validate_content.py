import json, pathlib
f=pathlib.Path('app/src/main/assets/phrases.json')
d=json.loads(f.read_text(encoding='utf-8'))
assert len(d['categories'])==10
assert len(d['phrases'])==100
ids=set(); cats={x['id'] for x in d['categories']}
assert len(cats)==10
for phrase in d['phrases']:
    assert phrase['id'] not in ids
    ids.add(phrase['id'])
    assert phrase['category'] in cats
    for lang in ('my','th','en'):
        assert len(phrase[lang].strip())>=2
        assert len(phrase[lang])<240
        assert '\t' not in phrase[lang]
assert sum(x['category']=='emergency' for x in d['phrases'])==10
print('PASS: 100 unique Burmese / Thai / English phrases in 10 topics; emergency and data integrity checks passed.')
