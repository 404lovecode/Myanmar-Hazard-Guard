# Mingalar Bridge · မင်္ဂလာတံတား

Offline-first Burmese–Thai–English Android phrasebook, with 100 common phrases, 10 topics, searchable text in all three languages, favorites stored locally, and spoken example buttons.

## Core user experience

- Burmese-first presentation with Thai and English alongside each phrase; buttons are large and readable.
- 100 built-in practical phrases, available offline; 10 categories for greetings, communication, transport, health, work, shopping, housing, services, emergency and family.
- Search all three languages. Mark phrases as favorites; offline local-only storage. Tap a category to filter. Practice mode cycles through phrases.
- Tap the speaker buttons for Thai, English or Burmese. This uses Android's own TextToSpeech engine. **Speech is offline ONLY if a suitable offline voice pack is installed on the phone; Burmese voice support varies by device**. The app does not fake audio or stream TTS.
- No login, ads, location, analytics, subscriptions, or network permissions. App requests no Android permissions.
- Educational phrasebook, not a certified interpreter. Critical medical, legal, immigration and safety communication needs human confirmation.

## Build

JDK 17, Android SDK 35, Gradle 8.11.1, Android Gradle Plugin 8.9.1.

Run `python3 tools/validate_content.py` then `gradle --no-daemon :app:assembleDebug`.

## Translation QA

These are curated starter examples. **Before community-wide publication, have native Burmese and Thai speakers review every phrase** for register, nuance, honorifics and emergency safety. English text is provided to disambiguate meaning. Thai polite particles may differ by speaker.

## Device support

Android 8.0+, portrait or landscape. Audio availability depends on installed Android TTS engines and offline language data. You can open TTS settings from the app if a voice is unavailable.
